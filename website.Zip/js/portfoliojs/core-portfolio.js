/**
 * PC 최적화 핵심 포트폴리오 관리 시스템
 * 파일: core-portfolio.js
 * 역할: 데이터 관리, 계산, 기본 로직
 */

class CorePortfolioManager {
    constructor() {
        this.isInitialized = false;
        this.updateInterval = null;
        
        // PC 전용 설정
        this.config = {
            minWidth: 1024,
            refreshRate: 3000,
            maxHistoryItems: 1000,
            gridColumns: {
                wide: 4,      // 1920px+
                standard: 3,  // 1366px+
                compact: 2    // 1024px+
            }
        };
        
        // 포트폴리오 핵심 데이터
        this.portfolioData = {
            totalValue: 125847.92,
            totalReturn: 18.45,
            dailyChange: 2.34,
            totalCost: 106450.00,
            unrealizedPnL: 19397.92,
            realizedPnL: 4280.15,
            
            holdings: [
                {
                    id: 'btc-001',
                    symbol: 'BTC',
                    name: 'Bitcoin',
                    amount: 2.15847,
                    avgPrice: 28450.50,
                    currentPrice: 45280.75,
                    value: 97720.84,
                    percentage: 77.65,
                    return: 59.12,
                    dayChange: 3.24,
                    allocation: 'core',
                    riskLevel: 'medium'
                },
                {
                    id: 'eth-001',
                    symbol: 'ETH',
                    name: 'Ethereum',
                    amount: 8.9234,
                    avgPrice: 1680.25,
                    currentPrice: 2285.40,
                    value: 20398.67,
                    percentage: 16.21,
                    return: 36.02,
                    dayChange: 1.87,
                    allocation: 'growth',
                    riskLevel: 'medium'
                },
                {
                    id: 'bnb-001',
                    symbol: 'BNB',
                    name: 'BNB',
                    amount: 12.4567,
                    avgPrice: 245.80,
                    currentPrice: 315.60,
                    value: 3930.50,
                    percentage: 3.12,
                    return: 28.40,
                    dayChange: -0.45,
                    allocation: 'utility',
                    riskLevel: 'low'
                },
                {
                    id: 'ada-001',
                    symbol: 'ADA',
                    name: 'Cardano',
                    amount: 5420.75,
                    avgPrice: 0.385,
                    currentPrice: 0.478,
                    value: 2591.12,
                    percentage: 2.06,
                    return: 24.16,
                    dayChange: 0.92,
                    allocation: 'speculation',
                    riskLevel: 'high'
                },
                {
                    id: 'sol-001',
                    symbol: 'SOL',
                    name: 'Solana',
                    amount: 24.8901,
                    avgPrice: 45.20,
                    currentPrice: 62.85,
                    value: 1564.79,
                    percentage: 1.24,
                    return: 39.05,
                    dayChange: 4.12,
                    allocation: 'growth',
                    riskLevel: 'high'
                }
            ],
            
            trades: [
                {
                    id: 'trade-001',
                    timestamp: '2025-06-18T14:35:22',
                    symbol: 'BTC',
                    type: 'buy',
                    amount: 0.0856,
                    price: 45280.75,
                    total: 3876.02,
                    fee: 11.63,
                    pnl: null,
                    status: 'filled',
                    strategy: 'manual'
                },
                {
                    id: 'trade-002',
                    timestamp: '2025-06-18T13:22:15',
                    symbol: 'ETH',
                    type: 'sell',
                    amount: 0.5000,
                    price: 2285.40,
                    total: 1142.70,
                    fee: 3.43,
                    pnl: 156.80,
                    status: 'filled',
                    strategy: 'profit-taking'
                },
                {
                    id: 'trade-003',
                    timestamp: '2025-06-18T11:45:33',
                    symbol: 'SOL',
                    type: 'buy',
                    amount: 5.0000,
                    price: 62.85,
                    total: 314.25,
                    fee: 0.94,
                    pnl: null,
                    status: 'filled',
                    strategy: 'auto-grid'
                }
            ],
            
            rebalancing: {
                lastCheck: Date.now() - 86400000,
                suggestions: [],
                targetAllocation: {
                    'BTC': 70.0,
                    'ETH': 20.0,
                    'Others': 10.0
                },
                deviation: 7.65
            }
        };
        
        // 성과 지표
        this.metrics = {
            totalReturn: 18.45,
            annualizedReturn: 32.8,
            monthlyReturn: 4.2,
            maxDrawdown: -12.5,
            sharpeRatio: 1.85,
            sortinoRatio: 2.41,
            volatility: 24.5,
            winRate: 74.3,
            profitFactor: 2.8,
            totalTrades: 247,
            avgHoldingPeriod: 7.4,
            totalFees: 425.80
        };
        
        // 리스크 지표
        this.riskMetrics = {
            var95: -2.8,
            var99: -4.2,
            concentrationRisk: 'HIGH',
            liquidityRisk: 'LOW',
            exposureByRisk: {
                low: 3.12,
                medium: 93.86,
                high: 3.30
            }
        };
        
        // 현재 설정
        this.settings = {
            period: '30d',
            sort: 'value',
            filter: 'all',
            autoRefresh: true,
            currency: 'USD'
        };
    }
    
    /**
     * 초기화
     */
    initialize() {
        if (this.isInitialized) {
            console.warn('CorePortfolioManager already initialized');
            return;
        }
        
        console.log('🚀 Initializing Core Portfolio Manager...');
        
        // PC 환경 체크
        if (window.innerWidth < this.config.minWidth) {
            console.warn(`⚠️ Optimized for PC screens (${this.config.minWidth}px+)`);
        }
        
        // 초기 데이터 로드
        this.loadPortfolioData();
        
        // 자동 업데이트 시작
        this.startAutoUpdate();
        
        this.isInitialized = true;
        console.log('✅ Core Portfolio Manager initialized');
        
        return this;
    }
    
    /**
     * 포트폴리오 데이터 로드
     */
    loadPortfolioData() {
        console.log('💼 Loading portfolio data...');
        
        // 실시간 가격 업데이트
        this.updatePrices();
        this.calculateMetrics();
        this.checkRebalanceNeeded();
        
        return this.portfolioData;
    }
    
    /**
     * 실시간 가격 업데이트
     */
    updatePrices() {
        this.portfolioData.holdings.forEach(holding => {
            const volatility = this.getAssetVolatility(holding.symbol);
            const change = (Math.random() - 0.5) * volatility * 0.02;
            
            const oldPrice = holding.currentPrice;
            holding.currentPrice *= (1 + change);
            holding.dayChange = ((holding.currentPrice - oldPrice) / oldPrice) * 100;
            holding.value = holding.amount * holding.currentPrice;
            holding.return = ((holding.currentPrice - holding.avgPrice) / holding.avgPrice) * 100;
        });
        
        // 포트폴리오 총합 재계산
        this.recalculatePortfolioTotals();
        
        return this.portfolioData.holdings;
    }
    
    /**
     * 자산별 변동성 반환
     */
    getAssetVolatility(symbol) {
        const volatilityMap = {
            'BTC': 1.0,
            'ETH': 1.2,
            'BNB': 1.5,
            'ADA': 2.0,
            'SOL': 2.5
        };
        return volatilityMap[symbol] || 1.0;
    }
    
    /**
     * 포트폴리오 총합 재계산
     */
    recalculatePortfolioTotals() {
        const totalValue = this.portfolioData.holdings.reduce((sum, h) => sum + h.value, 0);
        const totalCost = this.portfolioData.totalCost;
        
        this.portfolioData.totalValue = totalValue;
        this.portfolioData.totalReturn = ((totalValue - totalCost) / totalCost) * 100;
        this.portfolioData.unrealizedPnL = totalValue - totalCost;
        
        // 비율 재계산
        this.portfolioData.holdings.forEach(holding => {
            holding.percentage = (holding.value / totalValue) * 100;
        });
        
        // 일일 변화 계산
        const dailyChange = this.portfolioData.holdings.reduce((sum, h) => {
            return sum + (h.value * h.dayChange / 100);
        }, 0);
        
        this.portfolioData.dailyChange = (dailyChange / totalValue) * 100;
        
        return this.portfolioData;
    }
    
    /**
     * 성과 지표 계산
     */
    calculateMetrics() {
        const holdings = this.portfolioData.holdings;
        const trades = this.portfolioData.trades;
        
        // 승률 계산
        const profitableTrades = trades.filter(t => t.pnl && t.pnl > 0).length;
        this.metrics.winRate = trades.length > 0 ? (profitableTrades / trades.length) * 100 : 0;
        
        // 평균 수익/손실
        const profits = trades.filter(t => t.pnl && t.pnl > 0).map(t => t.pnl);
        const losses = trades.filter(t => t.pnl && t.pnl < 0).map(t => t.pnl);
        
        this.metrics.avgWin = profits.length > 0 ? 
            profits.reduce((a, b) => a + b, 0) / profits.length : 0;
        this.metrics.avgLoss = losses.length > 0 ? 
            losses.reduce((a, b) => a + b, 0) / losses.length : 0;
        
        // 수익 인수
        const totalProfit = Math.abs(profits.reduce((a, b) => a + b, 0));
        const totalLoss = Math.abs(losses.reduce((a, b) => a + b, 0));
        this.metrics.profitFactor = totalLoss > 0 ? totalProfit / totalLoss : 0;
        
        // 변동성 계산
        const returns = holdings.map(h => h.return);
        const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
        const variance = returns.reduce((a, r) => a + Math.pow(r - avgReturn, 2), 0) / returns.length;
        this.metrics.volatility = Math.sqrt(variance);
        
        // 샤프 비율 (위험 무료 수익률 3% 가정)
        const riskFreeRate = 3.0;
        this.metrics.sharpeRatio = this.metrics.volatility > 0 ? 
            (this.portfolioData.totalReturn - riskFreeRate) / this.metrics.volatility : 0;
        
        // 총 수익률 업데이트
        this.metrics.totalReturn = this.portfolioData.totalReturn;
        
        return this.metrics;
    }
    
    /**
     * 리스크 지표 계산
     */
    calculateRiskMetrics() {
        const holdings = this.portfolioData.holdings;
        
        // 집중도 위험
        const maxAllocation = Math.max(...holdings.map(h => h.percentage));
        if (maxAllocation > 70) {
            this.riskMetrics.concentrationRisk = 'HIGH';
        } else if (maxAllocation > 50) {
            this.riskMetrics.concentrationRisk = 'MEDIUM';
        } else {
            this.riskMetrics.concentrationRisk = 'LOW';
        }
        
        // 위험도별 노출
        let lowRisk = 0, mediumRisk = 0, highRisk = 0;
        holdings.forEach(h => {
            switch (h.riskLevel) {
                case 'low': lowRisk += h.percentage; break;
                case 'medium': mediumRisk += h.percentage; break;
                case 'high': highRisk += h.percentage; break;
            }
        });
        
        this.riskMetrics.exposureByRisk = {
            low: lowRisk,
            medium: mediumRisk,
            high: highRisk
        };
        
        return this.riskMetrics;
    }
    
    /**
     * 거래 실행
     */
    executeTrade(symbol, action, amount, price) {
        const total = amount * price;
        const fee = total * 0.001;
        
        // 새 거래 내역 생성
        const newTrade = {
            id: `trade-${Date.now()}`,
            timestamp: new Date().toISOString(),
            symbol: symbol,
            type: action,
            amount: amount,
            price: price,
            total: total,
            fee: fee,
            pnl: null,
            status: 'filled',
            strategy: 'manual'
        };
        
        // 거래 내역에 추가
        this.portfolioData.trades.unshift(newTrade);
        
        // 포지션 업데이트
        const holding = this.portfolioData.holdings.find(h => h.symbol === symbol);
        if (holding) {
            if (action === 'buy') {
                const oldValue = holding.amount * holding.avgPrice;
                const newValue = amount * price;
                holding.avgPrice = (oldValue + newValue) / (holding.amount + amount);
                holding.amount += amount;
            } else {
                holding.amount = Math.max(0, holding.amount - amount);
                
                // 매도 시 P&L 계산
                newTrade.pnl = (price - holding.avgPrice) * amount;
                this.portfolioData.realizedPnL += newTrade.pnl;
            }
            
            holding.value = holding.amount * holding.currentPrice;
        }
        
        // 포트폴리오 재계산
        this.recalculatePortfolioTotals();
        this.calculateMetrics();
        
        console.log(`✅ Trade executed: ${action} ${amount} ${symbol} at $${price}`);
        
        return newTrade;
    }
    
    /**
     * 리밸런싱 분석
     */
    analyzeRebalancing() {
        const target = this.portfolioData.rebalancing.targetAllocation;
        const current = {};
        
        // 현재 배분 계산
        this.portfolioData.holdings.forEach(holding => {
            if (target[holding.symbol]) {
                current[holding.symbol] = holding.percentage;
            } else {
                current['Others'] = (current['Others'] || 0) + holding.percentage;
            }
        });
        
        // 편차 계산 및 제안 생성
        const suggestions = [];
        
        Object.keys(target).forEach(asset => {
            const targetPercent = target[asset];
            const currentPercent = current[asset] || 0;
            const deviation = Math.abs(targetPercent - currentPercent);
            
            if (deviation > 5) {
                const action = currentPercent < targetPercent ? 'BUY' : 'SELL';
                const amount = (this.portfolioData.totalValue * (targetPercent - currentPercent)) / 100;
                
                suggestions.push({
                    asset: asset,
                    action: action,
                    currentPercent: currentPercent.toFixed(1),
                    targetPercent: targetPercent.toFixed(1),
                    deviation: deviation.toFixed(1),
                    amount: Math.abs(amount),
                    priority: deviation > 10 ? 'HIGH' : 'MEDIUM'
                });
            }
        });
        
        // 우선순위 정렬
        suggestions.sort((a, b) => b.deviation - a.deviation);
        
        this.portfolioData.rebalancing.suggestions = suggestions;
        this.portfolioData.rebalancing.lastCheck = Date.now();
        
        return suggestions;
    }
    
    /**
     * 리밸런싱 필요 여부 체크
     */
    checkRebalanceNeeded() {
        const lastCheck = this.portfolioData.rebalancing.lastCheck;
        const now = Date.now();
        const hoursSinceCheck = (now - lastCheck) / (1000 * 60 * 60);
        
        // 24시간마다 자동 체크
        if (hoursSinceCheck >= 24) {
            const suggestions = this.analyzeRebalancing();
            
            if (suggestions.length > 0) {
                console.log('⚖️ Rebalancing opportunities detected');
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 포트폴리오 새로고침
     */
    refreshPortfolio() {
        console.log('🔄 Refreshing portfolio data...');
        
        this.loadPortfolioData();
        
        console.log('✅ Portfolio data refreshed');
        
        return this.portfolioData;
    }
    
    /**
     * 자동 업데이트 시작
     */
    startAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        
        if (this.settings.autoRefresh) {
            this.updateInterval = setInterval(() => {
                this.updatePrices();
                this.calculateMetrics();
            }, this.config.refreshRate);
            
            console.log(`🔄 Auto-update started (${this.config.refreshRate}ms interval)`);
        }
    }
    
    /**
     * 자동 업데이트 중지
     */
    stopAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
            console.log('⏹️ Auto-update stopped');
        }
    }
    
    /**
     * 설정 업데이트
     */
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
        
        // 자동 새로고침 설정 변경 시
        if (newSettings.autoRefresh !== undefined) {
            if (newSettings.autoRefresh) {
                this.startAutoUpdate();
            } else {
                this.stopAutoUpdate();
            }
        }
        
        console.log('⚙️ Settings updated:', newSettings);
        
        return this.settings;
    }
    
    /**
     * 데이터 내보내기
     */
    exportData(format = 'json') {
        const exportData = {
            portfolio: this.portfolioData,
            metrics: this.metrics,
            riskMetrics: this.riskMetrics,
            settings: this.settings,
            timestamp: new Date().toISOString()
        };
        
        if (format === 'csv') {
            // CSV 형태로 거래 내역 내보내기
            const headers = ['Date', 'Time', 'Symbol', 'Type', 'Amount', 'Price', 'Total', 'Fee', 'P&L'];
            const csvData = this.portfolioData.trades.map(trade => {
                const date = new Date(trade.timestamp);
                return [
                    date.toISOString().split('T')[0],
                    date.toTimeString().split(' ')[0],
                    trade.symbol,
                    trade.type,
                    trade.amount,
                    trade.price,
                    trade.total,
                    trade.fee,
                    trade.pnl || ''
                ];
            });
            
            const csvContent = [headers.join(','), ...csvData.map(row => row.join(','))].join('\n');
            
            // 파일 다운로드
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `portfolio-trades-${new Date().toISOString().split('T')[0]}.csv`;
            link.click();
            URL.revokeObjectURL(link.href);
            
            console.log('📥 CSV exported successfully');
        } else {
            console.log('📊 Portfolio data:', exportData);
        }
        
        return exportData;
    }
    
    /**
     * 상태 정보 반환
     */
    getState() {
        return {
            isInitialized: this.isInitialized,
            screenWidth: window.innerWidth,
            totalValue: this.portfolioData.totalValue,
            totalReturn: this.portfolioData.totalReturn,
            holdingsCount: this.portfolioData.holdings.length,
            tradesCount: this.portfolioData.trades.length,
            autoRefresh: this.settings.autoRefresh,
            lastUpdate: new Date().toISOString()
        };
    }
    
    /**
     * 정리
     */
    cleanup() {
        this.stopAutoUpdate();
        
        this.portfolioData = null;
        this.metrics = null;
        this.riskMetrics = null;
        
        this.isInitialized = false;
        
        console.log('🧹 Core Portfolio Manager cleaned up');
    }
}

// 유틸리티 함수들
const PortfolioUtils = {
    formatCurrency: (value) => `$${value.toLocaleString(undefined, {minimumFractionDigits: 2})}`,
    formatPercentage: (value) => `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`,
    formatNumber: (value) => value.toLocaleString(),
    
    calculateReturn: (current, initial) => ((current - initial) / initial) * 100,
    
    getAssetColor: (symbol) => {
        const colorMap = {
            'BTC': '#f7931a',
            'ETH': '#627eea', 
            'BNB': '#f3ba2f',
            'ADA': '#0033ad',
            'SOL': '#00d4ff'
        };
        return colorMap[symbol] || '#6b7280';
    },
    
    getRiskColor: (riskLevel) => {
        const colors = {
            low: '#26a69a',
            medium: '#ff9800', 
            high: '#ef5350'
        };
        return colors[riskLevel] || '#6b7280';
    }
};

// 전역 접근
if (typeof window !== 'undefined') {
    window.CorePortfolioManager = CorePortfolioManager;
    window.PortfolioUtils = PortfolioUtils;
}

console.log('✅ Core Portfolio Manager v1.0 - Loaded Successfully');