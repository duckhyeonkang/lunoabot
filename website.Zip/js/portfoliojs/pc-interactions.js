/**
 * PC 최적화 인터랙션 시스템 - 완전판
 * 파일: pc-interactions.js
 * 역할: 키보드, 마우스, UI 인터랙션 및 고급 UX
 */

var PCInteractionSystem = function(portfolioManager, chartSystem) {
    this.portfolioManager = portfolioManager;
    this.chartSystem = chartSystem;
    this.isInitialized = false;
    
    // PC 전용 설정
    this.config = {
        minWidth: 1024,
        animations: {
            duration: 300,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        },
        debounceDelay: 300,
        tooltipDelay: 500,
        notificationDuration: 3000
    };
    
    // 상태 관리
    this.state = {
        activeTooltip: null,
        activeContextMenu: null,
        activeDialog: null,
        searchTerm: '',
        sortBy: 'value',
        filterBy: 'all',
        currentView: 'detailed'
    };
    
    // 이벤트 리스너 저장소
    this.eventListeners = [];
    
    // 키보드 단축키 맵
    this.shortcuts = {
        'ctrl+r': this.refreshPortfolio.bind(this),
        'ctrl+e': this.exportTrades.bind(this),
        'ctrl+f': this.focusSearch.bind(this),
        'ctrl+1': this.switchChart.bind(this, '24h'),
        'ctrl+2': this.switchChart.bind(this, '7d'),
        'ctrl+3': this.switchChart.bind(this, '30d'),
        'escape': this.closeAllDialogs.bind(this)
    };
};

/**
 * 초기화
 */
PCInteractionSystem.prototype.initialize = function() {
    if (this.isInitialized) {
        console.warn('PCInteractionSystem already initialized');
        return;
    }
    
    console.log('🎮 Initializing PC Interaction System...');
    
    // PC 환경 체크
    if (window.innerWidth < this.config.minWidth) {
        console.warn('⚠️ Optimized for PC screens (' + this.config.minWidth + 'px+)');
        this.showMobileWarning();
    }
    
    // 이벤트 리스너 설정
    this.setupKeyboardShortcuts();
    this.setupMouseInteractions();
    this.setupBasicControls();
    this.setupAdvancedUI();
    
    // UI 렌더링
    this.renderHoldingsTable();
    this.renderTradesTable();
    this.renderMetricsGrid();
    
    this.isInitialized = true;
    console.log('✅ PC Interaction System initialized');
    
    return this;
};

/**
 * 키보드 단축키 설정
 */
PCInteractionSystem.prototype.setupKeyboardShortcuts = function() {
    var self = this;
    
    var keydownHandler = function(e) {
        var key = '';
        
        if (e.ctrlKey || e.metaKey) key += 'ctrl+';
        if (e.shiftKey) key += 'shift+';
        if (e.altKey) key += 'alt+';
        
        if (e.key === 'Escape') {
            key += 'escape';
        } else {
            key += e.key.toLowerCase();
        }
        
        if (self.shortcuts[key]) {
            e.preventDefault();
            self.shortcuts[key]();
        }
    };
    
    document.addEventListener('keydown', keydownHandler);
    this.eventListeners.push({ element: document, event: 'keydown', handler: keydownHandler });
    
    console.log('⌨️ Keyboard shortcuts enabled');
};

/**
 * 마우스 인터랙션 설정
 */
PCInteractionSystem.prototype.setupMouseInteractions = function() {
    var self = this;
    
    // 마우스 오버 효과
    var mouseoverHandler = function(e) {
        var holdingItem = e.target.closest('.holding-item');
        var tradeItem = e.target.closest('.trade-item');
        var metricCard = e.target.closest('.metric-card');
        
        if (holdingItem) {
            self.showHoldingTooltip(holdingItem, e);
        } else if (tradeItem) {
            self.showTradeTooltip(tradeItem, e);
        } else if (metricCard) {
            self.showMetricTooltip(metricCard, e);
        }
    };
    
    var mouseoutHandler = function(e) {
        var item = e.target.closest('.holding-item, .trade-item, .metric-card');
        if (item) {
            self.hideTooltip();
        }
    };
    
    // 우클릭 컨텍스트 메뉴
    var contextmenuHandler = function(e) {
        var holdingItem = e.target.closest('.holding-item');
        if (holdingItem) {
            e.preventDefault();
            self.showContextMenu(e.pageX, e.pageY, holdingItem);
        }
    };
    
    // 클릭으로 컨텍스트 메뉴 닫기
    var clickHandler = function(e) {
        if (!e.target.closest('.context-menu')) {
            self.hideContextMenu();
        }
    };
    
    document.addEventListener('mouseover', mouseoverHandler);
    document.addEventListener('mouseout', mouseoutHandler);
    document.addEventListener('contextmenu', contextmenuHandler);
    document.addEventListener('click', clickHandler);
    
    this.eventListeners.push(
        { element: document, event: 'mouseover', handler: mouseoverHandler },
        { element: document, event: 'mouseout', handler: mouseoutHandler },
        { element: document, event: 'contextmenu', handler: contextmenuHandler },
        { element: document, event: 'click', handler: clickHandler }
    );
    
    console.log('🖱️ Mouse interactions enabled');
};

/**
 * 기본 컨트롤 설정
 */
PCInteractionSystem.prototype.setupBasicControls = function() {
    var self = this;
    
    // 새로고침 버튼
    var refreshBtn = document.getElementById('refresh-portfolio');
    if (refreshBtn) {
        var refreshHandler = function() { self.refreshPortfolio(); };
        refreshBtn.addEventListener('click', refreshHandler);
        this.eventListeners.push({ element: refreshBtn, event: 'click', handler: refreshHandler });
    }
    
    // 검색 입력
    var searchInput = document.getElementById('holdings-search');
    if (searchInput) {
        var searchHandler = this.debounce(function(e) {
            self.handleSearch(e.target.value);
        }, this.config.debounceDelay);
        
        searchInput.addEventListener('input', searchHandler);
        this.eventListeners.push({ element: searchInput, event: 'input', handler: searchHandler });
    }
    
    // 정렬 선택
    var sortSelect = document.getElementById('holdings-sort');
    if (sortSelect) {
        var sortHandler = function(e) { self.handleSort(e.target.value); };
        sortSelect.addEventListener('change', sortHandler);
        this.eventListeners.push({ element: sortSelect, event: 'change', handler: sortHandler });
    }
    
    // 필터 선택
    var filterSelect = document.getElementById('trade-filter');
    if (filterSelect) {
        var filterHandler = function(e) { self.handleFilter(e.target.value); };
        filterSelect.addEventListener('change', filterHandler);
        this.eventListeners.push({ element: filterSelect, event: 'change', handler: filterHandler });
    }
    
    // 거래 내보내기
    var exportBtn = document.getElementById('export-trades');
    if (exportBtn) {
        var exportHandler = function() { self.exportTrades(); };
        exportBtn.addEventListener('click', exportHandler);
        this.eventListeners.push({ element: exportBtn, event: 'click', handler: exportHandler });
    }
    
    // 리밸런싱 실행
    var rebalanceBtn = document.getElementById('run-rebalance');
    if (rebalanceBtn) {
        var rebalanceHandler = function() { self.runRebalanceAnalysis(); };
        rebalanceBtn.addEventListener('click', rebalanceHandler);
        this.eventListeners.push({ element: rebalanceBtn, event: 'click', handler: rebalanceHandler });
    }
    
    // 자동 새로고침 토글
    var autoRefreshToggle = document.getElementById('auto-refresh-toggle');
    if (autoRefreshToggle) {
        var toggleHandler = function(e) { self.handleAutoRefreshToggle(e.target.checked); };
        autoRefreshToggle.addEventListener('change', toggleHandler);
        this.eventListeners.push({ element: autoRefreshToggle, event: 'change', handler: toggleHandler });
    }
    
    console.log('🎛️ Basic controls setup complete');
};

/**
 * 고급 UI 설정
 */
PCInteractionSystem.prototype.setupAdvancedUI = function() {
    var self = this;
    
    // 매수/매도 버튼 위임
    var tradeHandler = function(e) {
        if (e.target.classList.contains('action-btn')) {
            var action = e.target.classList.contains('buy') ? 'buy' : 'sell';
            var holdingItem = e.target.closest('.holding-item');
            if (holdingItem) {
                var symbol = holdingItem.querySelector('.holding-symbol').textContent;
                self.showTradeDialog(symbol, action);
            }
        }
    };
    
    document.addEventListener('click', tradeHandler);
    this.eventListeners.push({ element: document, event: 'click', handler: tradeHandler });
    
    // 윈도우 리사이즈 핸들러
    var resizeHandler = this.debounce(function() {
        if (window.innerWidth >= self.config.minWidth) {
            self.handleResize();
        }
    }, this.config.debounceDelay);
    
    window.addEventListener('resize', resizeHandler);
    this.eventListeners.push({ element: window, event: 'resize', handler: resizeHandler });
    
    console.log('🚀 Advanced UI setup complete');
};

/**
 * 보유 자산 테이블 렌더링
 */
PCInteractionSystem.prototype.renderHoldingsTable = function() {
    var container = document.getElementById('holdings-list');
    if (!container) return;
    
    var holdings = this.getSortedHoldings();
    
    container.innerHTML = '';
    
    // PC 전용 테이블 헤더
    var header = document.createElement('div');
    header.className = 'holdings-header';
    header.style.cssText = 
        'display: grid;' +
        'grid-template-columns: 2fr 1fr 1fr 1fr 1fr 1fr 120px;' +
        'gap: 16px;' +
        'padding: 12px 16px;' +
        'background: #2a2b38;' +
        'border-radius: 8px 8px 0 0;' +
        'border: 1px solid #3a3b47;' +
        'border-bottom: none;' +
        'font-size: 11px;' +
        'font-weight: 600;' +
        'color: #878993;' +
        'text-transform: uppercase;' +
        'letter-spacing: 0.5px;';
    
    header.innerHTML = 
        '<div>Asset</div>' +
        '<div>Amount</div>' +
        '<div>Value</div>' +
        '<div>Allocation</div>' +
        '<div>Return</div>' +
        '<div>24h Change</div>' +
        '<div>Actions</div>';
    
    container.appendChild(header);
    
    // 보유 자산 행들
    for (var i = 0; i < holdings.length; i++) {
        var holding = holdings[i];
        var item = this.createHoldingRow(holding, i, holdings.length);
        container.appendChild(item);
    }
    
    console.log('📊 Holdings table rendered: ' + holdings.length + ' assets');
};

/**
 * 보유 자산 행 생성
 */
PCInteractionSystem.prototype.createHoldingRow = function(holding, index, total) {
    var item = document.createElement('div');
    item.className = 'holding-item';
    item.dataset.symbol = holding.symbol;
    item.style.cssText = 
        'display: grid;' +
        'grid-template-columns: 2fr 1fr 1fr 1fr 1fr 1fr 120px;' +
        'gap: 16px;' +
        'padding: 16px;' +
        'background: #1a1b23;' +
        'border: 1px solid #3a3b47;' +
        'border-top: ' + (index === 0 ? '1px solid #3a3b47' : 'none') + ';' +
        'transition: all 0.2s ease;' +
        'cursor: pointer;';
    
    if (index === total - 1) {
        item.style.borderRadius = '0 0 8px 8px';
    }
    
    var assetColor = this.getAssetColor(holding.symbol);
    var returnColor = holding.return >= 0 ? '#26a69a' : '#ef5350';
    var changeColor = holding.dayChange >= 0 ? '#26a69a' : '#ef5350';
    
    item.innerHTML = 
        '<div style="display: flex; align-items: center; gap: 12px;">' +
            '<div style="' +
                'width: 32px;' +
                'height: 32px;' +
                'border-radius: 50%;' +
                'background: ' + assetColor + ';' +
                'display: flex;' +
                'align-items: center;' +
                'justify-content: center;' +
                'font-weight: 700;' +
                'font-size: 12px;' +
                'color: #ffffff;' +
            '">' + holding.symbol[0] + '</div>' +
            '<div>' +
                '<div class="holding-symbol" style="' +
                    'font-size: 14px;' +
                    'font-weight: 600;' +
                    'color: #ffffff;' +
                    'margin-bottom: 2px;' +
                '">' + holding.symbol + '</div>' +
                '<div class="holding-name" style="' +
                    'font-size: 11px;' +
                    'color: #878993;' +
                '">' + holding.name + '</div>' +
            '</div>' +
        '</div>' +
        '<div style="font-size: 13px; color: #ffffff; font-weight: 500;">' + 
            holding.amount.toFixed(4) + 
        '</div>' +
        '<div style="font-size: 14px; color: #ffffff; font-weight: 600;">$' + 
            holding.value.toLocaleString(undefined, {minimumFractionDigits: 2}) + 
        '</div>' +
        '<div style="font-size: 13px; color: #ffffff; font-weight: 500;">' + 
            holding.percentage.toFixed(1) + '% ' +
        '</div>' +
        '<div style="font-size: 13px; color: ' + returnColor + '; font-weight: 600;">' + 
            (holding.return >= 0 ? '+' : '') + holding.return.toFixed(1) + '%' +
        '</div>' +
        '<div style="font-size: 13px; color: ' + changeColor + '; font-weight: 600;">' + 
            (holding.dayChange >= 0 ? '+' : '') + holding.dayChange.toFixed(2) + '%' +
        '</div>' +
        '<div style="display: flex; gap: 6px;">' +
            '<button class="action-btn buy" style="' +
                'flex: 1;' +
                'padding: 6px 8px;' +
                'background: #26a69a;' +
                'color: #ffffff;' +
                'border: none;' +
                'border-radius: 4px;' +
                'font-size: 11px;' +
                'font-weight: 600;' +
                'cursor: pointer;' +
                'transition: all 0.2s ease;' +
            '">BUY</button>' +
            '<button class="action-btn sell" style="' +
                'flex: 1;' +
                'padding: 6px 8px;' +
                'background: #ef5350;' +
                'color: #ffffff;' +
                'border: none;' +
                'border-radius: 4px;' +
                'font-size: 11px;' +
                'font-weight: 600;' +
                'cursor: pointer;' +
                'transition: all 0.2s ease;' +
            '">SELL</button>' +
        '</div>';
    
    // PC 호버 효과
    var self = this;
    item.addEventListener('mouseenter', function() {
        this.style.background = '#242530';
        this.style.transform = 'translateY(-1px)';
        this.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.2)';
    });
    
    item.addEventListener('mouseleave', function() {
        this.style.background = '#1a1b23';
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = 'none';
    });
    
    return item;
};

/**
 * 거래 내역 테이블 렌더링
 */
PCInteractionSystem.prototype.renderTradesTable = function() {
    var container = document.getElementById('trades-list');
    if (!container) return;
    
    var trades = this.getFilteredTrades();
    
    container.innerHTML = '';
    
    // PC 전용 테이블 헤더
    var header = document.createElement('div');
    header.className = 'trades-header';
    header.style.cssText = 
        'display: grid;' +
        'grid-template-columns: 1fr 80px 80px 100px 100px 100px 80px 100px 1fr;' +
        'gap: 12px;' +
        'padding: 12px 16px;' +
        'background: #2a2b38;' +
        'border-radius: 8px 8px 0 0;' +
        'border: 1px solid #3a3b47;' +
        'border-bottom: none;' +
        'font-size: 11px;' +
        'font-weight: 600;' +
        'color: #878993;' +
        'text-transform: uppercase;' +
        'letter-spacing: 0.5px;';
    
    header.innerHTML = 
        '<div>Time</div>' +
        '<div>Symbol</div>' +
        '<div>Type</div>' +
        '<div>Amount</div>' +
        '<div>Price</div>' +
        '<div>Total</div>' +
        '<div>Fee</div>' +
        '<div>P&L</div>' +
        '<div>Strategy</div>';
    
    container.appendChild(header);
    
    // 거래 내역 행들
    for (var i = 0; i < trades.length; i++) {
        var trade = trades[i];
        var item = this.createTradeRow(trade, i, trades.length);
        container.appendChild(item);
    }
    
    console.log('📈 Trades table rendered: ' + trades.length + ' trades');
};

/**
 * 거래 내역 행 생성
 */
PCInteractionSystem.prototype.createTradeRow = function(trade, index, total) {
    var item = document.createElement('div');
    item.className = 'trade-item';
    item.dataset.tradeId = trade.id;
    item.style.cssText = 
        'display: grid;' +
        'grid-template-columns: 1fr 80px 80px 100px 100px 100px 80px 100px 1fr;' +
        'gap: 12px;' +
        'padding: 12px 16px;' +
        'background: #1a1b23;' +
        'border: 1px solid #3a3b47;' +
        'border-top: ' + (index === 0 ? '1px solid #3a3b47' : 'none') + ';' +
        'transition: all 0.2s ease;' +
        'font-size: 12px;' +
        'align-items: center;';
    
    if (index === total - 1) {
        item.style.borderRadius = '0 0 8px 8px';
    }
    
    var tradeTime = new Date(trade.timestamp).toLocaleTimeString('en-US', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    var typeColor = trade.type === 'buy' ? '#26a69a' : '#ef5350';
    var pnlColor = trade.pnl ? (trade.pnl >= 0 ? '#26a69a' : '#ef5350') : '#878993';
    var assetColor = this.getAssetColor(trade.symbol);
    
    item.innerHTML = 
        '<div style="color: #ffffff; font-weight: 500;">' + tradeTime + '</div>' +
        '<div style="' +
            'color: #ffffff;' +
            'font-weight: 600;' +
            'display: flex;' +
            'align-items: center;' +
            'gap: 4px;' +
        '">' +
            '<div style="' +
                'width: 6px;' +
                'height: 6px;' +
                'border-radius: 50%;' +
                'background: ' + assetColor + ';' +
            '"></div>' +
            trade.symbol +
        '</div>' +
        '<div style="' +
            'color: ' + typeColor + ';' +
            'font-weight: 600;' +
            'text-transform: uppercase;' +
        '">' + trade.type + '</div>' +
        '<div style="color: #ffffff;">' + trade.amount.toFixed(4) + '</div>' +
        '<div style="color: #ffffff;">$' + trade.price.toLocaleString() + '</div>' +
        '<div style="color: #ffffff; font-weight: 500;">$' + trade.total.toFixed(2) + '</div>' +
        '<div style="color: #878993;">$' + trade.fee.toFixed(2) + '</div>' +
        '<div style="color: ' + pnlColor + '; font-weight: 600;">' + 
            (trade.pnl ? (trade.pnl >= 0 ? '+' : '') + trade.pnl.toFixed(2) : '--') + 
        '</div>' +
        '<div style="' +
            'color: #878993;' +
            'font-size: 10px;' +
            'text-transform: capitalize;' +
        '">' + trade.strategy.replace('-', ' ') + '</div>';
    
    // PC 호버 효과
    item.addEventListener('mouseenter', function() {
        this.style.background = '#242530';
    });
    
    item.addEventListener('mouseleave', function() {
        this.style.background = '#1a1b23';
    });
    
    return item;
};

/**
 * 성과 지표 그리드 렌더링
 */
PCInteractionSystem.prototype.renderMetricsGrid = function() {
    var container = document.getElementById('metrics-grid');
    if (!container) return;
    
    var metrics = [
        { label: 'Total Return', value: this.portfolioManager.metrics.totalReturn, format: 'percentage', color: 'auto' },
        { label: 'Annualized Return', value: this.portfolioManager.metrics.annualizedReturn, format: 'percentage', color: 'auto' },
        { label: 'Monthly Return', value: this.portfolioManager.metrics.monthlyReturn, format: 'percentage', color: 'auto' },
        { label: 'Max Drawdown', value: this.portfolioManager.metrics.maxDrawdown, format: 'percentage', color: 'negative' },
        { label: 'Sharpe Ratio', value: this.portfolioManager.metrics.sharpeRatio, format: 'decimal', color: 'neutral' },
        { label: 'Sortino Ratio', value: this.portfolioManager.metrics.sortinoRatio, format: 'decimal', color: 'neutral' },
        { label: 'Volatility', value: this.portfolioManager.metrics.volatility, format: 'percentage', color: 'neutral' },
        { label: 'Win Rate', value: this.portfolioManager.metrics.winRate, format: 'percentage', color: 'neutral' },
        { label: 'Profit Factor', value: this.portfolioManager.metrics.profitFactor, format: 'decimal', color: 'neutral' },
        { label: 'Total Trades', value: this.portfolioManager.metrics.totalTrades, format: 'number', color: 'neutral' },
        { label: 'Avg Hold Period', value: this.portfolioManager.metrics.avgHoldingPeriod, format: 'days', color: 'neutral' },
        { label: 'Total Fees', value: this.portfolioManager.metrics.totalFees, format: 'currency', color: 'negative' }
    ];
    
    container.innerHTML = '';
    
    for (var i = 0; i < metrics.length; i++) {
        var metric = metrics[i];
        var card = this.createMetricCard(metric);
        container.appendChild(card);
    }
    
    console.log('📊 Metrics grid rendered: ' + metrics.length + ' metrics');
};

/**
 * 성과 지표 카드 생성
 */
PCInteractionSystem.prototype.createMetricCard = function(metric) {
    var card = document.createElement('div');
    card.className = 'metric-card';
    card.dataset.metric = metric.label;
    card.style.cssText = 
        'background: #2a2b38;' +
        'border: 1px solid #3a3b47;' +
        'border-radius: 8px;' +
        'padding: 16px;' +
        'display: flex;' +
        'flex-direction: column;' +
        'gap: 8px;' +
        'transition: all 0.2s ease;' +
        'cursor: pointer;';
    
    var label = document.createElement('div');
    label.style.cssText = 
        'font-size: 11px;' +
        'color: #878993;' +
        'text-transform: uppercase;' +
        'letter-spacing: 0.5px;' +
        'font-weight: 500;';
    label.textContent = metric.label;
    
    var value = document.createElement('div');
    var formattedValue = this.formatMetricValue(metric.value, metric.format);
    var valueColor = this.getMetricColor(metric.value, metric.color);
    
    value.style.cssText = 
        'font-size: 18px;' +
        'font-weight: 700;' +
        'color: ' + valueColor + ';';
    value.textContent = formattedValue;
    
    card.appendChild(label);
    card.appendChild(value);
    
    // PC 호버 효과
    card.addEventListener('mouseenter', function() {
        this.style.background = '#3a3b47';
        this.style.transform = 'translateY(-2px)';
        this.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.2)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.background = '#2a2b38';
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = 'none';
    });
    
    return card;
};

/**
 * 거래 다이얼로그 표시
 */
PCInteractionSystem.prototype.showTradeDialog = function(symbol, action) {
    // 기존 다이얼로그 제거
    this.closeAllDialogs();
    
    var holding = this.portfolioManager.portfolioData.holdings.find(function(h) {
        return h.symbol === symbol;
    });
    
    if (!holding) return;
    
    // 오버레이 생성
    var overlay = document.createElement('div');
    overlay.id = 'trade-dialog';
    overlay.className = 'dialog-overlay';
    overlay.style.cssText = 
        'position: fixed;' +
        'top: 0;' +
        'left: 0;' +
        'right: 0;' +
        'bottom: 0;' +
        'background: rgba(0, 0, 0, 0.7);' +
        'display: flex;' +
        'align-items: center;' +
        'justify-content: center;' +
        'z-index: 10000;' +
        'backdrop-filter: blur(4px);';
    
    // 다이얼로그 생성
    var dialog = document.createElement('div');
    dialog.style.cssText = 
        'background: #1a1b23;' +
        'border: 1px solid #3a3b47;' +
        'border-radius: 12px;' +
        'padding: 24px;' +
        'width: 400px;' +
        'max-width: 90vw;' +
        'box-shadow: 0 16px 48px rgba(0, 0, 0, 0.4);';
    
    var actionColor = action === 'buy' ? '#26a69a' : '#ef5350';
    var assetColor = this.getAssetColor(symbol);
    
    dialog.innerHTML = 
        '<div style="' +
            'display: flex;' +
            'align-items: center;' +
            'gap: 12px;' +
            'margin-bottom: 20px;' +
        '">' +
            '<div style="' +
                'width: 40px;' +
                'height: 40px;' +
                'border-radius: 50%;' +
                'background: ' + assetColor + ';' +
                'display: flex;' +
                'align-items: center;' +
                'justify-content: center;' +
                'font-weight: 700;' +
                'color: #ffffff;' +
            '">' + symbol[0] + '</div>' +
            '<div>' +
                '<div style="' +
                    'font-size: 18px;' +
                    'font-weight: 700;' +
                    'color: #ffffff;' +
                '">' + action.toUpperCase() + ' ' + symbol + '</div>' +
                '<div style="' +
                    'font-size: 12px;' +
                    'color: #878993;' +
                '">Current Price: $' + holding.currentPrice.toLocaleString() + '</div>' +
            '</div>' +
        '</div>' +
        
        '<div style="margin-bottom: 16px;">' +
            '<label style="' +
                'display: block;' +
                'font-size: 12px;' +
                'font-weight: 600;' +
                'color: #ffffff;' +
                'margin-bottom: 6px;' +
                'text-transform: uppercase;' +
                'letter-spacing: 0.5px;' +
            '">Amount</label>' +
            '<input type="number" id="trade-amount" placeholder="0.0000" style="' +
                'width: 100%;' +
                'padding: 12px;' +
                'background: #2a2b38;' +
                'border: 1px solid #3a3b47;' +
                'border-radius: 6px;' +
                'color: #ffffff;' +
                'font-size: 14px;' +
                'box-sizing: border-box;' +
            '" step="0.0001" min="0"' + 
            (action === 'sell' ? ' max="' + holding.amount + '"' : '') + '>' +
        '</div>' +
        
        '<div style="' +
            'display: grid;' +
            'grid-template-columns: 1fr 1fr;' +
            'gap: 8px;' +
            'margin-bottom: 20px;' +
            'padding: 12px;' +
            'background: #2a2b38;' +
            'border-radius: 6px;' +
            'font-size: 12px;' +
        '">' +
            '<div style="color: #878993;">Estimated Total:</div>' +
            '<div id="estimated-total" style="color: #ffffff; font-weight: 600;">$0.00</div>' +
            '<div style="color: #878993;">Fee (0.1%):</div>' +
            '<div id="estimated-fee" style="color: #878993;">$0.00</div>' +
            (action === 'sell' ? 
                '<div style="color: #878993;">Available:</div>' +
                '<div style="color: #ffffff;">' + holding.amount.toFixed(4) + ' ' + symbol + '</div>'
            : '') +
        '</div>' +
        
        '<div style="' +
            'display: flex;' +
            'gap: 12px;' +
            'justify-content: flex-end;' +
        '">' +
            '<button id="cancel-trade" style="' +
                'padding: 10px 20px;' +
                'background: transparent;' +
                'border: 1px solid #3a3b47;' +
                'border-radius: 6px;' +
                'color: #ffffff;' +
                'font-size: 14px;' +
                'font-weight: 600;' +
                'cursor: pointer;' +
                'transition: all 0.2s ease;' +
            '">Cancel</button>' +
            '<button id="confirm-trade" style="' +
                'padding: 10px 20px;' +
                'background: ' + actionColor + ';' +
                'border: none;' +
                'border-radius: 6px;' +
                'color: #ffffff;' +
                'font-size: 14px;' +
                'font-weight: 600;' +
                'cursor: pointer;' +
                'transition: all 0.2s ease;' +
            '">' + action.toUpperCase() + '</button>' +
        '</div>';
    
    // 실시간 계산 설정
    this.setupTradeDialogCalculation(dialog, holding);
    
    // 이벤트 리스너 설정
    this.setupTradeDialogEvents(dialog, overlay, symbol, action, holding);
    
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    
    // 포커스
    var amountInput = dialog.querySelector('#trade-amount');
    if (amountInput) {
        amountInput.focus();
    }
    
    this.state.activeDialog = overlay;
};

/**
 * 거래 다이얼로그 계산 설정
 */
PCInteractionSystem.prototype.setupTradeDialogCalculation = function(dialog, holding) {
    var amountInput = dialog.querySelector('#trade-amount');
    var estimatedTotal = dialog.querySelector('#estimated-total');
    var estimatedFee = dialog.querySelector('#estimated-fee');
    
    if (!amountInput || !estimatedTotal || !estimatedFee) return;
    
    var updateCalculation = function() {
        var amount = parseFloat(amountInput.value) || 0;
        var total = amount * holding.currentPrice;
        var fee = total * 0.001;
        
        estimatedTotal.textContent = '$' + total.toFixed(2);
        estimatedFee.textContent = '$' + fee.toFixed(2);
    };
    
    amountInput.addEventListener('input', updateCalculation);
};

/**
 * 거래 다이얼로그 이벤트 설정
 */
PCInteractionSystem.prototype.setupTradeDialogEvents = function(dialog, overlay, symbol, action, holding) {
    var self = this;
    
    var cancelBtn = dialog.querySelector('#cancel-trade');
    var confirmBtn = dialog.querySelector('#confirm-trade');
    var amountInput = dialog.querySelector('#trade-amount');
    
    // 취소 버튼
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            self.closeAllDialogs();
        });
    }
    
    // 확인 버튼
    if (confirmBtn) {
        confirmBtn.addEventListener('click', function() {
            var amount = parseFloat(amountInput.value);
            if (amount && amount > 0) {
                self.executeTrade(symbol, action, amount, holding.currentPrice);
                self.closeAllDialogs();
            }
        });
    }
    
    // ESC 키로 닫기
    var escapeHandler = function(e) {
        if (e.key === 'Escape') {
            self.closeAllDialogs();
        }
    };
    overlay.addEventListener('keydown', escapeHandler);
    
    // 오버레이 클릭으로 닫기
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            self.closeAllDialogs();
        }
    });
};

/**
 * 거래 실행
 */
PCInteractionSystem.prototype.executeTrade = function(symbol, action, amount, price) {
    var trade = this.portfolioManager.executeTrade(symbol, action, amount, price);
    
    if (trade) {
        // UI 업데이트
        this.renderHoldingsTable();
        this.renderTradesTable();
        this.renderMetricsGrid();
        
        // 차트 업데이트
        if (this.chartSystem) {
            this.chartSystem.updateChartData();
        }
        
        // 성공 알림
        this.showNotification(
            action.toUpperCase() + ' order executed: ' + amount.toFixed(4) + ' ' + symbol,
            'success'
        );
    }
};

/**
 * 툴팁 표시
 */
PCInteractionSystem.prototype.showHoldingTooltip = function(holdingItem, event) {
    this.hideTooltip();
    
    var symbol = holdingItem.querySelector('.holding-symbol').textContent;
    var holding = this.portfolioManager.portfolioData.holdings.find(function(h) {
        return h.symbol === symbol;
    });
    
    if (!holding) return;
    
    var tooltip = document.createElement('div');
    tooltip.id = 'holding-tooltip';
    tooltip.style.cssText = 
        'position: absolute;' +
        'background: #1a1b23;' +
        'border: 1px solid #3a3b47;' +
        'border-radius: 8px;' +
        'padding: 12px;' +
        'font-size: 12px;' +
        'color: #ffffff;' +
        'z-index: 1000;' +
        'pointer-events: none;' +
        'box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);' +
        'opacity: 0;' +
        'transition: opacity 0.2s ease;';
    
    tooltip.innerHTML = 
        '<div style="font-weight: 600; margin-bottom: 6px;">' + holding.name + ' (' + holding.symbol + ')</div>' +
        '<div style="color: #878993; margin-bottom: 4px;">Average Price: $' + holding.avgPrice.toLocaleString() + '</div>' +
        '<div style="color: #878993; margin-bottom: 4px;">Current Price: $' + holding.currentPrice.toLocaleString() + '</div>' +
        '<div style="color: #878993; margin-bottom: 4px;">Risk Level: ' + holding.riskLevel.toUpperCase() + '</div>' +
        '<div style="color: #878993;">Allocation: ' + holding.allocation + '</div>';
    
    document.body.appendChild(tooltip);
    
    // 위치 조정
    var self = this;
    setTimeout(function() {
        var rect = holdingItem.getBoundingClientRect();
        tooltip.style.left = (rect.right + 10) + 'px';
        tooltip.style.top = rect.top + 'px';
        tooltip.style.opacity = '1';
    }, 10);
    
    this.state.activeTooltip = tooltip;
};

/**
 * 툴팁 숨기기
 */
PCInteractionSystem.prototype.hideTooltip = function() {
    if (this.state.activeTooltip) {
        this.state.activeTooltip.style.opacity = '0';
        var tooltip = this.state.activeTooltip;
        setTimeout(function() {
            if (tooltip.parentNode) {
                tooltip.parentNode.removeChild(tooltip);
            }
        }, 200);
        this.state.activeTooltip = null;
    }
};

/**
 * 컨텍스트 메뉴 표시
 */
PCInteractionSystem.prototype.showContextMenu = function(x, y, holdingItem) {
    this.hideContextMenu();
    
    var symbol = holdingItem.querySelector('.holding-symbol').textContent;
    var self = this;
    
    var contextMenu = document.createElement('div');
    contextMenu.id = 'context-menu';
    contextMenu.className = 'context-menu';
    contextMenu.style.cssText = 
        'position: absolute;' +
        'left: ' + x + 'px;' +
        'top: ' + y + 'px;' +
        'background: #1a1b23;' +
        'border: 1px solid #3a3b47;' +
        'border-radius: 8px;' +
        'padding: 8px 0;' +
        'font-size: 12px;' +
        'color: #ffffff;' +
        'z-index: 10000;' +
        'box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);' +
        'min-width: 150px;';
    
    var menuItems = [
        { text: 'Buy ' + symbol, action: function() { self.showTradeDialog(symbol, 'buy'); } },
        { text: 'Sell ' + symbol, action: function() { self.showTradeDialog(symbol, 'sell'); } },
        { text: 'View Details', action: function() { self.showAssetDetails(symbol); } },
        { text: 'Price Alert', action: function() { self.showPriceAlert(symbol); } },
        { text: 'Remove from Portfolio', action: function() { self.removeAsset(symbol); } }
    ];
    
    for (var i = 0; i < menuItems.length; i++) {
        var item = menuItems[i];
        var menuItem = document.createElement('div');
        menuItem.style.cssText = 
            'padding: 8px 16px;' +
            'cursor: pointer;' +
            'transition: background 0.2s ease;';
        menuItem.textContent = item.text;
        
        menuItem.addEventListener('mouseenter', function() {
            this.style.background = '#3a3b47';
        });
        
        menuItem.addEventListener('mouseleave', function() {
            this.style.background = 'transparent';
        });
        
        (function(action) {
            menuItem.addEventListener('click', function() {
                action();
                self.hideContextMenu();
            });
        })(item.action);
        
        contextMenu.appendChild(menuItem);
    }
    
    document.body.appendChild(contextMenu);
    this.state.activeContextMenu = contextMenu;
};

/**
 * 컨텍스트 메뉴 숨기기
 */
PCInteractionSystem.prototype.hideContextMenu = function() {
    if (this.state.activeContextMenu) {
        if (this.state.activeContextMenu.parentNode) {
            this.state.activeContextMenu.parentNode.removeChild(this.state.activeContextMenu);
        }
        this.state.activeContextMenu = null;
    }
};

/**
 * 모든 다이얼로그 닫기
 */
PCInteractionSystem.prototype.closeAllDialogs = function() {
    if (this.state.activeDialog) {
        if (this.state.activeDialog.parentNode) {
            this.state.activeDialog.parentNode.removeChild(this.state.activeDialog);
        }
        this.state.activeDialog = null;
    }
    
    this.hideTooltip();
    this.hideContextMenu();
};

/**
 * 알림 표시
 */
PCInteractionSystem.prototype.showNotification = function(message, type) {
    type = type || 'info';
    
    var notification = document.createElement('div');
    notification.style.cssText = 
        'position: fixed;' +
        'top: 20px;' +
        'right: 20px;' +
        'background: ' + (type === 'success' ? '#26a69a' : type === 'error' ? '#ef5350' : '#2196f3') + ';' +
        'color: #ffffff;' +
        'padding: 16px 20px;' +
        'border-radius: 8px;' +
        'font-size: 14px;' +
        'font-weight: 500;' +
        'z-index: 10001;' +
        'box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);' +
        'transform: translateX(100%);' +
        'transition: transform 0.3s ease;' +
        'max-width: 300px;';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // 슬라이드 인
    setTimeout(function() {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // 자동 제거
    setTimeout(function() {
        notification.style.transform = 'translateX(100%)';
        setTimeout(function() {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, this.config.notificationDuration);
};

/**
 * 모바일 경고 표시
 */
PCInteractionSystem.prototype.showMobileWarning = function() {
    var warning = document.createElement('div');
    warning.style.cssText = 
        'position: fixed;' +
        'top: 0;' +
        'left: 0;' +
        'right: 0;' +
        'background: #ff9800;' +
        'color: #ffffff;' +
        'padding: 12px;' +
        'text-align: center;' +
        'font-size: 14px;' +
        'font-weight: 600;' +
        'z-index: 10000;';
    warning.textContent = '⚠️ This portfolio is optimized for desktop viewing (1024px+)';
    
    document.body.appendChild(warning);
    
    setTimeout(function() {
        if (warning.parentNode) {
            warning.parentNode.removeChild(warning);
        }
    }, 5000);
};

/**
 * 단축키 액션들
 */
PCInteractionSystem.prototype.refreshPortfolio = function() {
    this.portfolioManager.refreshPortfolio();
    this.renderHoldingsTable();
    this.renderTradesTable();
    this.renderMetricsGrid();
    
    if (this.chartSystem) {
        this.chartSystem.updateChartData();
    }
    
    this.showNotification('Portfolio refreshed successfully', 'success');
};

PCInteractionSystem.prototype.exportTrades = function() {
    this.portfolioManager.exportData('csv');
    this.showNotification('Trade history exported successfully', 'success');
};

PCInteractionSystem.prototype.focusSearch = function() {
    var searchInput = document.getElementById('holdings-search');
    if (searchInput) {
        searchInput.focus();
        searchInput.select();
    }
};

PCInteractionSystem.prototype.switchChart = function(period) {
    if (this.chartSystem) {
        this.chartSystem.updateChartPeriod(period);
    }
};

/**
 * 이벤트 핸들러들
 */
PCInteractionSystem.prototype.handleSearch = function(searchTerm) {
    this.state.searchTerm = searchTerm;
    this.renderHoldingsTable();
};

PCInteractionSystem.prototype.handleSort = function(sortBy) {
    this.state.sortBy = sortBy;
    this.renderHoldingsTable();
};

PCInteractionSystem.prototype.handleFilter = function(filterBy) {
    this.state.filterBy = filterBy;
    this.renderTradesTable();
};

PCInteractionSystem.prototype.handleAutoRefreshToggle = function(enabled) {
    this.portfolioManager.updateSettings({ autoRefresh: enabled });
};

PCInteractionSystem.prototype.handleResize = function() {
    this.hideTooltip();
    this.hideContextMenu();
    
    // 테이블 재렌더링
    this.renderHoldingsTable();
    this.renderTradesTable();
    this.renderMetricsGrid();
};

/**
 * 유틸리티 함수들
 */
PCInteractionSystem.prototype.getSortedHoldings = function() {
    var holdings = this.portfolioManager.portfolioData.holdings.slice();
    var searchTerm = this.state.searchTerm.toLowerCase();
    
    // 검색 필터
    if (searchTerm) {
        holdings = holdings.filter(function(holding) {
            return holding.symbol.toLowerCase().includes(searchTerm) || 
                   holding.name.toLowerCase().includes(searchTerm);
        });
    }
    
    // 정렬
    switch (this.state.sortBy) {
        case 'value':
            holdings.sort(function(a, b) { return b.value - a.value; });
            break;
        case 'percentage':
            holdings.sort(function(a, b) { return b.percentage - a.percentage; });
            break;
        case 'return':
            holdings.sort(function(a, b) { return b.return - a.return; });
            break;
        case 'dayChange':
            holdings.sort(function(a, b) { return b.dayChange - a.dayChange; });
            break;
    }
    
    return holdings;
};

PCInteractionSystem.prototype.getFilteredTrades = function() {
    var trades = this.portfolioManager.portfolioData.trades.slice();
    
    // 필터링
    if (this.state.filterBy !== 'all') {
        if (this.state.filterBy === 'buy') {
            trades = trades.filter(function(trade) { return trade.type === 'buy'; });
        } else if (this.state.filterBy === 'sell') {
            trades = trades.filter(function(trade) { return trade.type === 'sell'; });
        } else if (this.state.filterBy === 'auto') {
            trades = trades.filter(function(trade) { return trade.strategy.includes('auto'); });
        }
    }
    
    return trades;
};

PCInteractionSystem.prototype.formatMetricValue = function(value, format) {
    switch (format) {
        case 'percentage':
            return (value >= 0 ? '+' : '') + value.toFixed(2) + '%';
        case 'decimal':
            return value.toFixed(2);
        case 'currency':
            return '$' + value.toFixed(2);
        case 'days':
            return value.toFixed(1) + ' days';
        case 'number':
            return value.toString();
        default:
            return value.toString();
    }
};

PCInteractionSystem.prototype.getMetricColor = function(value, colorType) {
    switch (colorType) {
        case 'auto':
            return value >= 0 ? '#26a69a' : '#ef5350';
        case 'positive':
            return '#26a69a';
        case 'negative':
            return '#ef5350';
        case 'neutral':
        default:
            return '#ffffff';
    }
};

PCInteractionSystem.prototype.getAssetColor = function(symbol) {
    var colorMap = {
        'BTC': '#f7931a',
        'ETH': '#627eea',
        'BNB': '#f3ba2f',
        'ADA': '#0033ad',
        'SOL': '#00d4ff'
    };
    return colorMap[symbol] || '#6b7280';
};

PCInteractionSystem.prototype.debounce = function(func, wait) {
    var timeout;
    return function() {
        var context = this;
        var args = arguments;
        var later = function() {
            timeout = null;
            func.apply(context, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};

/**
 * 추가 액션들 (컨텍스트 메뉴용)
 */
PCInteractionSystem.prototype.showAssetDetails = function(symbol) {
    var holding = this.portfolioManager.portfolioData.holdings.find(function(h) {
        return h.symbol === symbol;
    });
    
    if (holding) {
        console.log('📊 Showing details for ' + symbol + ':', holding);
        this.showNotification('Asset details for ' + symbol + ' - Feature coming soon!', 'info');
    }
};

PCInteractionSystem.prototype.showPriceAlert = function(symbol) {
    var holding = this.portfolioManager.portfolioData.holdings.find(function(h) {
        return h.symbol === symbol;
    });
    
    if (holding) {
        var targetPrice = prompt(
            'Set price alert for ' + symbol + '\nCurrent price: $' + holding.currentPrice.toLocaleString() + '\n\nEnter target price:'
        );
        
        if (targetPrice && !isNaN(targetPrice)) {
            this.showNotification(
                'Price alert set for ' + symbol + ' at $' + parseFloat(targetPrice).toLocaleString(),
                'success'
            );
            console.log('🔔 Price alert set: ' + symbol + ' at $' + targetPrice);
        }
    }
};

PCInteractionSystem.prototype.removeAsset = function(symbol) {
    var confirmed = confirm('Are you sure you want to remove ' + symbol + ' from your portfolio?');
    
    if (confirmed) {
        this.portfolioManager.portfolioData.holdings = this.portfolioManager.portfolioData.holdings.filter(function(h) {
            return h.symbol !== symbol;
        });
        
        this.portfolioManager.recalculatePortfolioTotals();
        this.renderHoldingsTable();
        this.renderMetricsGrid();
        
        if (this.chartSystem) {
            this.chartSystem.updateChartData();
        }
        
        this.showNotification(symbol + ' removed from portfolio', 'success');
        console.log('🗑️ Asset removed: ' + symbol);
    }
};

PCInteractionSystem.prototype.runRebalanceAnalysis = function() {
    console.log('⚖️ Running rebalance analysis...');
    
    var btn = document.getElementById('run-rebalance');
    if (btn) {
        btn.textContent = 'Analyzing...';
        btn.disabled = true;
    }
    
    var self = this;
    setTimeout(function() {
        var suggestions = self.portfolioManager.analyzeRebalancing();
        self.renderRebalanceSuggestions(suggestions);
        
        if (btn) {
            btn.textContent = 'Run Analysis';
            btn.disabled = false;
        }
        
        self.showNotification('Rebalance analysis completed', 'success');
        console.log('✅ Rebalance analysis completed');
    }, 2000);
};

PCInteractionSystem.prototype.renderRebalanceSuggestions = function(suggestions) {
    var container = document.getElementById('rebalance-suggestions');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (!suggestions || suggestions.length === 0) {
        container.innerHTML = 
            '<div style="' +
                'text-align: center;' +
                'padding: 32px;' +
                'color: #26a69a;' +
                'font-size: 14px;' +
            '">' +
                '✅ Portfolio is well balanced!<br>' +
                '<span style="font-size: 12px; color: #878993;">' +
                    'No rebalancing needed at this time.' +
                '</span>' +
            '</div>';
        return;
    }
    
    for (var i = 0; i < suggestions.length; i++) {
        var suggestion = suggestions[i];
        var item = document.createElement('div');
        item.style.cssText = 
            'background: #2a2b38;' +
            'border: 1px solid #3a3b47;' +
            'border-radius: 8px;' +
            'padding: 16px;' +
            'margin-bottom: 12px;' +
            'transition: all 0.2s ease;';
        
        var priorityColor = suggestion.priority === 'HIGH' ? '#ef5350' : '#ff9800';
        var actionColor = suggestion.action === 'BUY' ? '#26a69a' : '#ef5350';
        
        item.innerHTML = 
            '<div style="' +
                'display: flex;' +
                'justify-content: space-between;' +
                'align-items: flex-start;' +
                'margin-bottom: 8px;' +
            '">' +
                '<div style="' +
                    'font-size: 14px;' +
                    'font-weight: 600;' +
                    'color: #ffffff;' +
                '">' + suggestion.asset + ' Rebalancing</div>' +
                '<div style="' +
                    'font-size: 10px;' +
                    'padding: 2px 6px;' +
                    'background: ' + priorityColor + '20;' +
                    'color: ' + priorityColor + ';' +
                    'border-radius: 4px;' +
                    'font-weight: 600;' +
                '">' + suggestion.priority + '</div>' +
            '</div>' +
            
            '<div style="' +
                'font-size: 12px;' +
                'color: #878993;' +
                'margin-bottom: 12px;' +
            '">' +
                'Current: ' + suggestion.currentPercent + '% → Target: ' + suggestion.targetPercent + '%' +
                ' (Deviation: ' + suggestion.deviation + '%)' +
            '</div>' +
            
            '<div style="' +
                'display: flex;' +
                'justify-content: space-between;' +
                'align-items: center;' +
            '">' +
                '<div style="' +
                    'font-size: 14px;' +
                    'font-weight: 600;' +
                    'color: ' + actionColor + ';' +
                '">' + suggestion.action + ' $' + suggestion.amount.toFixed(2) + '</div>' +
                '<button style="' +
                    'padding: 6px 12px;' +
                    'background: ' + actionColor + ';' +
                    'color: #ffffff;' +
                    'border: none;' +
                    'border-radius: 4px;' +
                    'font-size: 11px;' +
                    'font-weight: 600;' +
                    'cursor: pointer;' +
                    'transition: all 0.2s ease;' +
                '">Execute</button>' +
            '</div>';
        
        // PC 호버 효과
        item.addEventListener('mouseenter', function() {
            this.style.background = '#3a3b47';
            this.style.transform = 'translateY(-1px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.background = '#2a2b38';
            this.style.transform = 'translateY(0)';
        });
        
        container.appendChild(item);
    }
};

/**
 * 상태 정보 반환
 */
PCInteractionSystem.prototype.getState = function() {
    return {
        isInitialized: this.isInitialized,
        screenWidth: window.innerWidth,
        state: this.state,
        eventListeners: this.eventListeners.length,
        lastUpdate: new Date().toISOString()
    };
};

/**
 * 정리
 */
PCInteractionSystem.prototype.cleanup = function() {
    // 모든 이벤트 리스너 제거
    for (var i = 0; i < this.eventListeners.length; i++) {
        var listener = this.eventListeners[i];
        listener.element.removeEventListener(listener.event, listener.handler);
    }
    this.eventListeners = [];
    
    // 모든 다이얼로그 닫기
    this.closeAllDialogs();
    
    this.isInitialized = false;
    
    console.log('🧹 PC Interaction System cleaned up');
};

// 전역 접근
if (typeof window !== 'undefined') {
    window.PCInteractionSystem = PCInteractionSystem;
}

console.log('✅ PC Interaction System v1.0 - Loaded Successfully');