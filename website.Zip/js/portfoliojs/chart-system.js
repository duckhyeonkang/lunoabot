/**
 * PC 최적화 차트 렌더링 시스템 - 완전판
 * 파일: chart-system.js
 * 역할: 전문가급 차트 렌더링 및 시각화 (모든 기능 복구)
 */

var ChartRenderingSystem = function(portfolioManager) {
    this.portfolioManager = portfolioManager;
    this.chartInstances = {};
    this.isInitialized = false;
    
    // PC 전용 차트 설정
    this.chartConfig = {
        minWidth: 1024,
        heights: {
            ultraWide: 400,  // 2560px+
            wide: 350,       // 1920px+
            standard: 320,   // 1366px+
            compact: 280     // 1024px+
        },
        colors: {
            primary: '#26a69a',
            secondary: '#42a5f5',
            success: '#26a69a',
            danger: '#ef5350',
            warning: '#ff9800',
            info: '#2196f3',
            dark: '#1a1b23',
            light: '#ffffff'
        },
        animations: {
            duration: 600,
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        }
    };
    
    // 차트 데이터 캐시
    this.chartData = {
        performance: null,
        allocation: null,
        correlation: null,
        drawdown: null
    };
};

/**
 * 초기화
 */
ChartRenderingSystem.prototype.initialize = function() {
    if (this.isInitialized) {
        console.warn('ChartRenderingSystem already initialized');
        return;
    }
    
    console.log('📈 Initializing Chart Rendering System...');
    
    // 차트 데이터 생성
    this.generateAllChartData();
    
    // 뷰포트 기반 렌더링 최적화
    this.setupViewportOptimization();
    
    this.isInitialized = true;
    console.log('✅ Chart Rendering System initialized');
    
    return this;
};

/**
 * PC 화면 크기에 따른 차트 높이 반환
 */
ChartRenderingSystem.prototype.getChartHeight = function() {
    var width = window.innerWidth;
    
    if (width >= 2560) return this.chartConfig.heights.ultraWide;
    if (width >= 1920) return this.chartConfig.heights.wide;
    if (width >= 1366) return this.chartConfig.heights.standard;
    return this.chartConfig.heights.compact;
};

/**
 * 모든 차트 데이터 생성
 */
ChartRenderingSystem.prototype.generateAllChartData = function() {
    this.chartData = {
        performance: this.generatePerformanceData(),
        allocation: this.generateAllocationData(),
        correlation: this.generateCorrelationData(),
        drawdown: this.generateDrawdownData()
    };
    
    return this.chartData;
};

/**
 * 성과 차트 데이터 생성
 */
ChartRenderingSystem.prototype.generatePerformanceData = function(period) {
    period = period || '30d';
    var days = period === '24h' ? 1 : period === '7d' ? 7 : 30;
    var data = [];
    var value = this.portfolioManager.portfolioData.totalCost;
    
    for (var i = days; i >= 0; i--) {
        var date = new Date();
        date.setDate(date.getDate() - i);
        
        // 시뮬레이션: 점진적 성장 (약간의 상승 편향)
        var dailyReturn = (Math.random() - 0.4) * 0.03;
        value *= (1 + dailyReturn);
        
        data.push({
            date: date.toISOString().split('T')[0],
            time: date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
            value: Math.round(value * 100) / 100,
            return: ((value - this.portfolioManager.portfolioData.totalCost) / this.portfolioManager.portfolioData.totalCost) * 100
        });
    }
    
    return data;
};

/**
 * 자산 배분 차트 데이터 생성
 */
ChartRenderingSystem.prototype.generateAllocationData = function() {
    var self = this;
    return this.portfolioManager.portfolioData.holdings.map(function(holding) {
        return {
            symbol: holding.symbol,
            name: holding.name,
            value: holding.value,
            percentage: holding.percentage,
            color: self.getAssetColor(holding.symbol),
            allocation: holding.allocation,
            riskLevel: holding.riskLevel
        };
    });
};

/**
 * 상관관계 매트릭스 데이터 생성
 */
ChartRenderingSystem.prototype.generateCorrelationData = function() {
    var symbols = this.portfolioManager.portfolioData.holdings.map(function(h) { return h.symbol; });
    var matrix = [];
    
    for (var i = 0; i < symbols.length; i++) {
        var row = [];
        for (var j = 0; j < symbols.length; j++) {
            if (i === j) {
                row.push(1.0);
            } else {
                // 시뮬레이션: 실제로는 가격 데이터에서 계산
                row.push(Math.random() * 0.6 + 0.2);
            }
        }
        matrix.push(row);
    }
    
    return { symbols: symbols, matrix: matrix };
};

/**
 * 낙폭 차트 데이터 생성
 */
ChartRenderingSystem.prototype.generateDrawdownData = function() {
    var performanceData = this.chartData.performance || this.generatePerformanceData();
    var peak = performanceData[0].value;
    
    return performanceData.map(function(point) {
        if (point.value > peak) {
            peak = point.value;
        }
        var drawdown = ((point.value - peak) / peak) * 100;
        return {
            date: point.date,
            drawdown: Math.min(0, drawdown)
        };
    });
};

/**
 * 모든 차트 렌더링
 */
ChartRenderingSystem.prototype.renderAllCharts = function() {
    console.log('🎨 Rendering all charts...');
    
    this.renderAllocationChart();
    this.renderPerformanceChart();
    this.renderCorrelationMatrix();
    this.renderDrawdownChart();
    
    console.log('✅ All charts rendered');
};

/**
 * 자산 배분 도넛 차트 렌더링
 */
ChartRenderingSystem.prototype.renderAllocationChart = function() {
    var container = document.getElementById('allocation-chart');
    if (!container) return;
    
    var chartHeight = this.getChartHeight();
    var allocationData = this.chartData.allocation || this.generateAllocationData();
    
    container.innerHTML = '';
    container.style.cssText = 
        'display: flex;' +
        'flex-direction: column;' +
        'align-items: center;' +
        'justify-content: center;' +
        'height: ' + chartHeight + 'px;' +
        'position: relative;' +
        'background: linear-gradient(135deg, #1a1b23 0%, #2a2b38 100%);' +
        'border-radius: 12px;' +
        'border: 1px solid #3a3b47;' +
        'overflow: hidden;';
    
    // 도넛 차트 컨테이너
    var donutContainer = document.createElement('div');
    donutContainer.style.cssText = 
        'width: 200px;' +
        'height: 200px;' +
        'border-radius: 50%;' +
        'position: relative;' +
        'display: flex;' +
        'align-items: center;' +
        'justify-content: center;' +
        'box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);';
    
    // 도넛 차트 생성 (CSS conic-gradient 사용)
    var gradientStops = [];
    var currentPercent = 0;
    
    for (var i = 0; i < allocationData.length; i++) {
        var item = allocationData[i];
        var startPercent = currentPercent;
        var endPercent = currentPercent + item.percentage;
        
        gradientStops.push(item.color + ' ' + startPercent + '% ' + endPercent + '%');
        currentPercent = endPercent;
    }
    
    donutContainer.style.background = 'conic-gradient(' + gradientStops.join(', ') + ')';
    
    // 중앙 홀
    var centerHole = document.createElement('div');
    centerHole.style.cssText = 
        'width: 120px;' +
        'height: 120px;' +
        'background: #1a1b23;' +
        'border-radius: 50%;' +
        'display: flex;' +
        'flex-direction: column;' +
        'align-items: center;' +
        'justify-content: center;' +
        'box-shadow: inset 0 4px 16px rgba(0, 0, 0, 0.4);';
    
    // 총 가치 표시
    var totalValue = document.createElement('div');
    totalValue.style.cssText = 
        'font-size: 16px;' +
        'font-weight: 700;' +
        'color: #ffffff;' +
        'margin-bottom: 4px;';
    totalValue.textContent = '$' + (this.portfolioManager.portfolioData.totalValue / 1000).toFixed(1) + 'K';
    
    var totalLabel = document.createElement('div');
    totalLabel.style.cssText = 
        'font-size: 11px;' +
        'color: #878993;' +
        'text-transform: uppercase;' +
        'letter-spacing: 0.5px;';
    totalLabel.textContent = 'Total Value';
    
    centerHole.appendChild(totalValue);
    centerHole.appendChild(totalLabel);
    donutContainer.appendChild(centerHole);
    container.appendChild(donutContainer);
    
    // 범례 렌더링
    this.renderAllocationLegend(allocationData);
    
    this.chartInstances['allocation-chart'] = true;
};

/**
 * 자산 배분 범례 렌더링
 */
ChartRenderingSystem.prototype.renderAllocationLegend = function(allocationData) {
    var legend = document.getElementById('allocation-legend');
    if (!legend) return;
    
    legend.innerHTML = '';
    legend.style.cssText = 
        'display: grid;' +
        'grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));' +
        'gap: 12px;' +
        'padding: 16px;' +
        'background: #2a2b38;' +
        'border-radius: 8px;' +
        'border: 1px solid #3a3b47;';
    
    for (var i = 0; i < allocationData.length; i++) {
        var item = allocationData[i];
        var legendItem = document.createElement('div');
        legendItem.style.cssText = 
            'display: flex;' +
            'align-items: center;' +
            'gap: 8px;' +
            'padding: 8px;' +
            'border-radius: 6px;' +
            'transition: all 0.2s ease;' +
            'cursor: pointer;';
        
        legendItem.innerHTML = 
            '<div style="' +
                'width: 12px;' +
                'height: 12px;' +
                'border-radius: 50%;' +
                'background: ' + item.color + ';' +
                'flex-shrink: 0;' +
            '"></div>' +
            '<div style="flex: 1;">' +
                '<div style="' +
                    'font-size: 13px;' +
                    'font-weight: 600;' +
                    'color: #ffffff;' +
                    'margin-bottom: 2px;' +
                '">' + item.symbol + '</div>' +
                '<div style="' +
                    'font-size: 11px;' +
                    'color: #878993;' +
                '">' + item.percentage.toFixed(1) + '% • $' + (item.value / 1000).toFixed(1) + 'K</div>' +
            '</div>';
        
        // PC 호버 효과
        legendItem.addEventListener('mouseenter', function() {
            this.style.background = '#3a3b47';
            this.style.transform = 'translateY(-1px)';
        });
        
        legendItem.addEventListener('mouseleave', function() {
            this.style.background = 'transparent';
            this.style.transform = 'translateY(0)';
        });
        
        legend.appendChild(legendItem);
    }
};

/**
 * 수익률 차트 렌더링
 */
ChartRenderingSystem.prototype.renderPerformanceChart = function(period) {
    var container = document.getElementById('performance-chart');
    if (!container) return;
    
    period = period || '30d';
    var chartHeight = this.getChartHeight();
    var performanceData = this.generatePerformanceData(period);
    
    container.innerHTML = '';
    container.style.cssText = 
        'height: ' + chartHeight + 'px;' +
        'background: linear-gradient(135deg, #1a1b23 0%, #2a2b38 100%);' +
        'border-radius: 12px;' +
        'border: 1px solid #3a3b47;' +
        'position: relative;' +
        'overflow: hidden;';
    
    // 차트 배경
    var chartArea = document.createElement('div');
    chartArea.style.cssText = 
        'width: 100%;' +
        'height: 100%;' +
        'position: relative;' +
        'background: ' +
            'linear-gradient(90deg, transparent 0%, rgba(38, 166, 154, 0.1) 50%, transparent 100%), ' +
            'repeating-linear-gradient(' +
                '0deg, ' +
                'transparent, ' +
                'transparent 20px, ' +
                'rgba(255, 255, 255, 0.02) 20px, ' +
                'rgba(255, 255, 255, 0.02) 21px' +
            ');';
    
    // 차트 헤더 정보
    var chartHeader = document.createElement('div');
    chartHeader.style.cssText = 
        'position: absolute;' +
        'top: 16px;' +
        'left: 16px;' +
        'right: 16px;' +
        'display: flex;' +
        'justify-content: space-between;' +
        'align-items: center;' +
        'z-index: 2;';
    
    var returnInfo = document.createElement('div');
    var currentReturn = this.portfolioManager.portfolioData.totalReturn;
    var dailyChange = this.portfolioManager.portfolioData.dailyChange;
    
    returnInfo.innerHTML = 
        '<div style="' +
            'font-size: 24px;' +
            'font-weight: 700;' +
            'color: ' + (currentReturn >= 0 ? '#26a69a' : '#ef5350') + ';' +
            'margin-bottom: 4px;' +
        '">' + (currentReturn >= 0 ? '+' : '') + currentReturn.toFixed(2) + '%</div>' +
        '<div style="' +
            'font-size: 12px;' +
            'color: #878993;' +
            'text-transform: uppercase;' +
            'letter-spacing: 0.5px;' +
            'margin-bottom: 8px;' +
        '">Total Return</div>' +
        '<div style="' +
            'font-size: 14px;' +
            'color: ' + (dailyChange >= 0 ? '#26a69a' : '#ef5350') + ';' +
            'font-weight: 500;' +
        '">' + (dailyChange >= 0 ? '+' : '') + dailyChange.toFixed(2) + '% Today</div>';
    
    // 기간 선택 버튼
    var timeframeButtons = document.createElement('div');
    timeframeButtons.style.cssText = 'display: flex; gap: 8px;';
    
    var periods = ['24h', '7d', '30d'];
    var self = this;
    
    for (var i = 0; i < periods.length; i++) {
        var timeframe = periods[i];
        var btn = document.createElement('button');
        btn.className = 'timeframe-btn' + (timeframe === period ? ' active' : '');
        btn.dataset.period = timeframe;
        btn.textContent = timeframe;
        btn.style.cssText = 
            'padding: 6px 12px;' +
            'background: ' + (timeframe === period ? '#26a69a' : 'transparent') + ';' +
            'border: 1px solid ' + (timeframe === period ? '#26a69a' : '#3a3b47') + ';' +
            'border-radius: 4px;' +
            'color: #ffffff;' +
            'font-size: 11px;' +
            'font-weight: 600;' +
            'cursor: pointer;' +
            'transition: all 0.2s ease;';
        
        btn.addEventListener('click', function(e) {
            var newPeriod = e.target.dataset.period;
            
            // 모든 버튼 비활성화
            var allBtns = document.querySelectorAll('.timeframe-btn');
            for (var j = 0; j < allBtns.length; j++) {
                allBtns[j].classList.remove('active');
                allBtns[j].style.background = 'transparent';
                allBtns[j].style.borderColor = '#3a3b47';
            }
            
            // 클릭된 버튼 활성화
            e.target.classList.add('active');
            e.target.style.background = '#26a69a';
            e.target.style.borderColor = '#26a69a';
            
            // 차트 재렌더링
            self.renderPerformanceChart(newPeriod);
        });
        
        timeframeButtons.appendChild(btn);
    }
    
    chartHeader.appendChild(returnInfo);
    chartHeader.appendChild(timeframeButtons);
    
    // 차트 라인 시뮬레이션
    var chartLine = document.createElement('div');
    chartLine.style.cssText = 
        'position: absolute;' +
        'bottom: 40px;' +
        'left: 40px;' +
        'right: 40px;' +
        'height: 2px;' +
        'background: linear-gradient(90deg, #26a69a 0%, #42a5f5 100%);' +
        'border-radius: 2px;' +
        'box-shadow: 0 0 20px rgba(38, 166, 154, 0.4);';
    
    // 차트 데이터 포인트들
    for (var i = 0; i < performanceData.length; i++) {
        if (i % Math.ceil(performanceData.length / 7) === 0) {
            var point = performanceData[i];
            var dot = document.createElement('div');
            dot.style.cssText = 
                'position: absolute;' +
                'width: 6px;' +
                'height: 6px;' +
                'background: #26a69a;' +
                'border: 2px solid #1a1b23;' +
                'border-radius: 50%;' +
                'top: ' + (Math.random() * 60 + 20) + '%;' +
                'left: ' + ((i / (performanceData.length - 1)) * 100) + '%;' +
                'transform: translate(-50%, -50%);' +
                'box-shadow: 0 0 12px rgba(38, 166, 154, 0.6);';
            
            // 툴팁 정보
            dot.title = point.date + ': $' + point.value.toLocaleString();
            
            chartArea.appendChild(dot);
        }
    }
    
    chartArea.appendChild(chartHeader);
    chartArea.appendChild(chartLine);
    container.appendChild(chartArea);
    
    this.chartInstances['performance-chart'] = true;
};

/**
 * 상관관계 매트릭스 렌더링
 */
ChartRenderingSystem.prototype.renderCorrelationMatrix = function() {
    var container = document.getElementById('correlation-matrix');
    if (!container) return;
    
    var correlationData = this.chartData.correlation || this.generateCorrelationData();
    
    container.innerHTML = '';
    container.style.cssText = 
        'padding: 16px;' +
        'background: #2a2b38;' +
        'border-radius: 8px;' +
        'border: 1px solid #3a3b47;';
    
    // 제목
    var title = document.createElement('div');
    title.style.cssText = 
        'font-size: 14px;' +
        'font-weight: 600;' +
        'color: #ffffff;' +
        'margin-bottom: 12px;';
    title.textContent = 'Asset Correlation Matrix';
    
    // 매트릭스 그리드
    var matrix = document.createElement('div');
    matrix.style.cssText = 
        'display: grid;' +
        'grid-template-columns: repeat(' + (correlationData.symbols.length + 1) + ', 1fr);' +
        'gap: 2px;';
    
    // 빈 셀 (좌상단)
    var emptyCell = document.createElement('div');
    matrix.appendChild(emptyCell);
    
    // 헤더 행
    for (var i = 0; i < correlationData.symbols.length; i++) {
        var symbol = correlationData.symbols[i];
        var cell = document.createElement('div');
        cell.style.cssText = 
            'padding: 4px;' +
            'text-align: center;' +
            'font-size: 10px;' +
            'font-weight: 600;' +
            'color: #ffffff;' +
            'background: #3a3b47;' +
            'border-radius: 2px;';
        cell.textContent = symbol;
        matrix.appendChild(cell);
    }
    
    // 데이터 행들
    for (var i = 0; i < correlationData.symbols.length; i++) {
        var symbol1 = correlationData.symbols[i];
        
        // 행 헤더
        var rowHeader = document.createElement('div');
        rowHeader.style.cssText = 
            'padding: 4px;' +
            'text-align: center;' +
            'font-size: 10px;' +
            'font-weight: 600;' +
            'color: #ffffff;' +
            'background: #3a3b47;' +
            'border-radius: 2px;';
        rowHeader.textContent = symbol1;
        matrix.appendChild(rowHeader);
        
        // 상관관계 값들
        for (var j = 0; j < correlationData.matrix[i].length; j++) {
            var correlation = correlationData.matrix[i][j];
            var cell = document.createElement('div');
            var intensity = Math.abs(correlation);
            var color = correlation > 0.5 ? '#26a69a' : correlation < -0.5 ? '#ef5350' : '#6b7280';
            var opacity = Math.floor(intensity * 255).toString(16);
            if (opacity.length === 1) opacity = '0' + opacity;
            
            cell.style.cssText = 
                'padding: 4px;' +
                'text-align: center;' +
                'font-size: 9px;' +
                'color: #ffffff;' +
                'background: ' + color + opacity + '40;' +
                'border-radius: 2px;' +
                'transition: all 0.2s ease;' +
                'cursor: pointer;';
            cell.textContent = correlation.toFixed(2);
            
            // 호버 효과
            cell.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.1)';
                this.style.zIndex = '10';
            });
            
            cell.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
                this.style.zIndex = '1';
            });
            
            matrix.appendChild(cell);
        }
    }
    
    container.appendChild(title);
    container.appendChild(matrix);
    
    this.chartInstances['correlation-matrix'] = true;
};

/**
 * 낙폭 차트 렌더링
 */
ChartRenderingSystem.prototype.renderDrawdownChart = function() {
    var container = document.getElementById('drawdown-chart');
    if (!container) return;
    
    var chartHeight = Math.floor(this.getChartHeight() * 0.7);
    var drawdownData = this.chartData.drawdown || this.generateDrawdownData();
    
    container.innerHTML = '';
    container.style.cssText = 
        'height: ' + chartHeight + 'px;' +
        'background: #2a2b38;' +
        'border-radius: 8px;' +
        'border: 1px solid #3a3b47;' +
        'position: relative;' +
        'overflow: hidden;';
    
    // 헤더
    var header = document.createElement('div');
    header.style.cssText = 
        'padding: 12px 16px;' +
        'border-bottom: 1px solid #3a3b47;' +
        'display: flex;' +
        'justify-content: space-between;' +
        'align-items: center;';
    
    var title = document.createElement('div');
    title.style.cssText = 
        'font-size: 14px;' +
        'font-weight: 600;' +
        'color: #ffffff;';
    title.textContent = 'Drawdown Analysis';
    
    var maxDrawdown = document.createElement('div');
    maxDrawdown.style.cssText = 
        'font-size: 12px;' +
        'color: #ef5350;' +
        'font-weight: 500;';
    maxDrawdown.textContent = 'Max: ' + this.portfolioManager.metrics.maxDrawdown.toFixed(1) + '%';
    
    header.appendChild(title);
    header.appendChild(maxDrawdown);
    
    // 차트 영역
    var chartArea = document.createElement('div');
    chartArea.style.cssText = 
        'height: calc(100% - 45px);' +
        'position: relative;' +
        'background: repeating-linear-gradient(' +
            '0deg, ' +
            'transparent, ' +
            'transparent 15px, ' +
            'rgba(255, 255, 255, 0.02) 15px, ' +
            'rgba(255, 255, 255, 0.02) 16px' +
        ');';
    
    // 낙폭 영역 시뮬레이션
    var drawdownArea = document.createElement('div');
    drawdownArea.style.cssText = 
        'position: absolute;' +
        'bottom: 50%;' +
        'left: 10%;' +
        'right: 10%;' +
        'height: 30%;' +
        'background: linear-gradient(180deg, transparent 0%, rgba(239, 83, 80, 0.2) 100%);' +
        'border-top: 2px solid #ef5350;' +
        'border-radius: 4px 4px 0 0;';
    
    // 낙폭 라인
    var drawdownLine = document.createElement('div');
    drawdownLine.style.cssText = 
        'position: absolute;' +
        'top: 0;' +
        'left: 0;' +
        'right: 0;' +
        'height: 2px;' +
        'background: #ef5350;' +
        'box-shadow: 0 0 10px rgba(239, 83, 80, 0.5);';
    
    drawdownArea.appendChild(drawdownLine);
    chartArea.appendChild(drawdownArea);
    container.appendChild(header);
    container.appendChild(chartArea);
    
    this.chartInstances['drawdown-chart'] = true;
};

/**
 * 차트 기간 업데이트
 */
ChartRenderingSystem.prototype.updateChartPeriod = function(period) {
    console.log('📊 Updating chart period: ' + period);
    
    // 성과 차트 데이터 재생성
    this.chartData.performance = this.generatePerformanceData(period);
    this.chartData.drawdown = this.generateDrawdownData();
    
    // 성과 차트 및 낙폭 차트 재렌더링
    this.renderPerformanceChart(period);
    this.renderDrawdownChart();
};

/**
 * 차트 데이터 업데이트
 */
ChartRenderingSystem.prototype.updateChartData = function() {
    console.log('🔄 Updating chart data...');
    
    // 새로운 데이터 생성
    this.generateAllChartData();
    
    // 모든 차트 재렌더링
    this.renderAllCharts();
    
    console.log('✅ Chart data updated');
};

/**
 * 뷰포트 기반 렌더링 최적화
 */
ChartRenderingSystem.prototype.setupViewportOptimization = function() {
    if (!window.IntersectionObserver) {
        console.warn('⚠️ IntersectionObserver not supported');
        return;
    }
    
    var self = this;
    var observer = new IntersectionObserver(function(entries) {
        for (var i = 0; i < entries.length; i++) {
            var entry = entries[i];
            if (entry.isIntersecting) {
                var chartId = entry.target.id;
                if (chartId && !self.chartInstances[chartId]) {
                    self.renderChart(chartId);
                }
            }
        }
    });
    
    // 모든 차트 컨테이너 관찰
    var chartElements = document.querySelectorAll('[id*="chart"], [id*="matrix"]');
    for (var i = 0; i < chartElements.length; i++) {
        observer.observe(chartElements[i]);
    }
    
    console.log('👁️ Viewport optimization enabled');
};

/**
 * 개별 차트 렌더링
 */
ChartRenderingSystem.prototype.renderChart = function(chartId) {
    switch (chartId) {
        case 'allocation-chart':
            this.renderAllocationChart();
            break;
        case 'performance-chart':
            this.renderPerformanceChart();
            break;
        case 'correlation-matrix':
            this.renderCorrelationMatrix();
            break;
        case 'drawdown-chart':
            this.renderDrawdownChart();
            break;
        default:
            console.warn('Unknown chart ID: ' + chartId);
    }
};

/**
 * 차트 테마 변경
 */
ChartRenderingSystem.prototype.changeTheme = function(theme) {
    console.log('🎨 Changing chart theme: ' + theme);
    
    if (theme === 'light') {
        this.chartConfig.colors.dark = '#ffffff';
        this.chartConfig.colors.light = '#000000';
    } else {
        this.chartConfig.colors.dark = '#1a1b23';
        this.chartConfig.colors.light = '#ffffff';
    }
    
    // 모든 차트 재렌더링
    this.renderAllCharts();
};

/**
 * 차트 내보내기 (이미지)
 */
ChartRenderingSystem.prototype.exportChart = function(chartId, format) {
    format = format || 'png';
    var container = document.getElementById(chartId);
    if (!container) return;
    
    console.log('📸 Exporting chart: ' + chartId + ' as ' + format);
    
    // 실제 구현에서는 html2canvas 등 사용
    console.log('Chart export feature - Would use html2canvas in production');
};

/**
 * 자산 색상 반환
 */
ChartRenderingSystem.prototype.getAssetColor = function(symbol) {
    var colorMap = {
        'BTC': '#f7931a',
        'ETH': '#627eea',
        'BNB': '#f3ba2f',
        'ADA': '#0033ad',
        'SOL': '#00d4ff'
    };
    return colorMap[symbol] || '#6b7280';
};

/**
 * 상태 정보 반환
 */
ChartRenderingSystem.prototype.getState = function() {
    return {
        isInitialized: this.isInitialized,
        chartInstances: Object.keys(this.chartInstances),
        chartHeight: this.getChartHeight(),
        screenWidth: window.innerWidth,
        lastUpdate: new Date().toISOString()
    };
};

/**
 * 정리
 */
ChartRenderingSystem.prototype.cleanup = function() {
    this.chartInstances = {};
    this.chartData = null;
    this.isInitialized = false;
    
    console.log('🧹 Chart Rendering System cleaned up');
};

// 차트 유틸리티 함수들
var ChartUtils = {
    /**
     * 반응형 폰트 크기 계산
     */
    getResponsiveFontSize: function(baseSize) {
        baseSize = baseSize || 14;
        var width = window.innerWidth;
        if (width >= 2560) return baseSize + 2;
        if (width >= 1920) return baseSize + 1;
        if (width >= 1366) return baseSize;
        return baseSize - 1;
    },
    
    /**
     * 색상 투명도 추가
     */
    addOpacity: function(color, opacity) {
        var opacityHex = Math.floor(opacity * 255).toString(16);
        if (opacityHex.length === 1) opacityHex = '0' + opacityHex;
        return color + opacityHex;
    },
    
    /**
     * 애니메이션 생성
     */
    createAnimation: function(element, property, from, to, duration) {
        duration = duration || 600;
        var start = performance.now();
        
        function animate(currentTime) {
            var elapsed = currentTime - start;
            var progress = Math.min(elapsed / duration, 1);
            
            // 이징 함수 (cubic-bezier)
            var eased = progress < 0.5 
                ? 4 * progress * progress * progress 
                : 1 - Math.pow(-2 * progress + 2, 3) / 2;
            
            var value = from + (to - from) * eased;
            element.style[property] = value + 'px';
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        }
        
        requestAnimationFrame(animate);
    },
    
    /**
     * 그라디언트 생성
     */
    createGradient: function(colors, direction) {
        direction = direction || '90deg';
        return 'linear-gradient(' + direction + ', ' + colors.join(', ') + ')';
    },
    
    /**
     * 차트 포인트 계산
     */
    calculatePoint: function(value, min, max, containerSize) {
        return ((value - min) / (max - min)) * containerSize;
    },
    
    /**
     * 숫자 포맷팅 (차트용)
     */
    formatChartNumber: function(value) {
        if (value >= 1000000) {
            return (value / 1000000).toFixed(1) + 'M';
        } else if (value >= 1000) {
            return (value / 1000).toFixed(1) + 'K';
        }
        return value.toFixed(0);
    },
    
    /**
     * 차트 색상 팔레트
     */
    getColorPalette: function() {
        return [
            '#f7931a', // BTC Orange
            '#627eea', // ETH Blue
            '#f3ba2f', // BNB Yellow
            '#0033ad', // ADA Blue
            '#00d4ff', // SOL Cyan
            '#26a69a', // Success Green
            '#ef5350', // Danger Red
            '#ff9800', // Warning Orange
            '#2196f3', // Info Blue
            '#9c27b0'  // Purple
        ];
    },
    
    /**
     * 반응형 여백 계산
     */
    getResponsivePadding: function() {
        var width = window.innerWidth;
        if (width >= 2560) return 24;
        if (width >= 1920) return 20;
        if (width >= 1366) return 16;
        return 12;
    }
};

// 차트 성능 모니터
var ChartPerformanceMonitor = {
    renderTimes: [],
    startTime: null,
    currentChart: null,
    
    startRender: function(chartId) {
        this.startTime = performance.now();
        this.currentChart = chartId;
    },
    
    endRender: function() {
        if (this.startTime && this.currentChart) {
            var renderTime = performance.now() - this.startTime;
            this.renderTimes.push({
                chart: this.currentChart,
                time: renderTime,
                timestamp: Date.now()
            });
            
            console.log('⚡ ' + this.currentChart + ' rendered in ' + renderTime.toFixed(2) + 'ms');
            
            // 최근 10개 기록만 유지
            if (this.renderTimes.length > 10) {
                this.renderTimes = this.renderTimes.slice(-10);
            }
        }
    },
    
    getAverageRenderTime: function(chartId) {
        var chartTimes = this.renderTimes.filter(function(r) { return r.chart === chartId; });
        if (chartTimes.length === 0) return 0;
        
        var total = chartTimes.reduce(function(sum, r) { return sum + r.time; }, 0);
        return total / chartTimes.length;
    },
    
    getPerformanceReport: function() {
        var totalTime = this.renderTimes.reduce(function(sum, r) { return sum + r.time; }, 0);
        var avgTime = this.renderTimes.length > 0 ? totalTime / this.renderTimes.length : 0;
        var charts = [];
        var chartMap = {};
        
        for (var i = 0; i < this.renderTimes.length; i++) {
            var chart = this.renderTimes[i].chart;
            if (!chartMap[chart]) {
                chartMap[chart] = true;
                charts.push(chart);
            }
        }
        
        return {
            totalRenders: this.renderTimes.length,
            averageTime: avgTime,
            charts: charts,
            lastRender: this.renderTimes.length > 0 ? this.renderTimes[this.renderTimes.length - 1] : null
        };
    }
};

// 차트 이벤트 시스템
var ChartEventSystem = function() {
    this.listeners = {};
};

/**
 * 이벤트 리스너 등록
 */
ChartEventSystem.prototype.on = function(event, callback) {
    if (!this.listeners[event]) {
        this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
};

/**
 * 이벤트 발생
 */
ChartEventSystem.prototype.emit = function(event, data) {
    if (this.listeners[event]) {
        for (var i = 0; i < this.listeners[event].length; i++) {
            this.listeners[event][i](data);
        }
    }
};

/**
 * 이벤트 리스너 제거
 */
ChartEventSystem.prototype.off = function(event, callback) {
    if (this.listeners[event]) {
        this.listeners[event] = this.listeners[event].filter(function(cb) {
            return cb !== callback;
        });
    }
};

/**
 * 모든 리스너 제거
 */
ChartEventSystem.prototype.removeAllListeners = function() {
    this.listeners = {};
};

// 전역 차트 이벤트 시스템
var chartEvents = new ChartEventSystem();

// 차트 반응형 핸들러
var ChartResponsiveHandler = {
    debounceTimer: null,
    chartSystem: null,
    
    init: function(chartSystem) {
        this.chartSystem = chartSystem;
        var self = this;
        
        window.addEventListener('resize', function() {
            clearTimeout(self.debounceTimer);
            self.debounceTimer = setTimeout(function() {
                self.handleResize();
            }, 300);
        });
        
        console.log('📱 Chart responsive handler initialized');
    },
    
    handleResize: function() {
        if (this.chartSystem && this.chartSystem.isInitialized) {
            console.log('📐 Handling chart resize...');
            
            // 화면 크기가 PC 최적화 범위 내인지 확인
            if (window.innerWidth >= 1024) {
                this.chartSystem.renderAllCharts();
                chartEvents.emit('resize', {
                    width: window.innerWidth,
                    height: window.innerHeight,
                    chartHeight: this.chartSystem.getChartHeight()
                });
            }
        }
    }
};

// PC 전용 차트 최적화
var PCChartOptimizer = {
    /**
     * 고해상도 디스플레이 감지
     */
    isHighDPI: function() {
        return window.devicePixelRatio > 1;
    },
    
    /**
     * GPU 가속 사용 가능 여부
     */
    hasGPUAcceleration: function() {
        var canvas = document.createElement('canvas');
        var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
        return !!gl;
    },
    
    /**
     * 최적 렌더링 설정 반환
     */
    getOptimalSettings: function() {
        var width = window.innerWidth;
        var memory = navigator.deviceMemory || 4;
        var highDPI = this.isHighDPI();
        var hasGPU = this.hasGPUAcceleration();
        
        return {
            quality: width >= 2560 && memory >= 8 ? 'ultra' : width >= 1920 ? 'high' : 'standard',
            animations: memory >= 4,
            antialiasing: highDPI && hasGPU,
            maxDataPoints: memory >= 8 ? 1000 : 500,
            refreshRate: memory >= 8 ? 60 : 30
        };
    },
    
    /**
     * 성능 최적화 적용
     */
    applyOptimizations: function(chartSystem) {
        var settings = this.getOptimalSettings();
        
        console.log('🚀 Applying PC chart optimizations:', settings);
        
        // CSS 하드웨어 가속 활성화
        var chartElements = document.querySelectorAll('[id*="chart"]');
        for (var i = 0; i < chartElements.length; i++) {
            chartElements[i].style.transform = 'translateZ(0)';
            chartElements[i].style.willChange = 'transform';
        }
        
        // 고품질 설정에서만 복잡한 애니메이션 사용
        if (settings.quality === 'ultra') {
            document.body.classList.add('ultra-quality-charts');
        }
        
        return settings;
    }
};

// 전역 접근
if (typeof window !== 'undefined') {
    window.ChartRenderingSystem = ChartRenderingSystem;
    window.ChartUtils = ChartUtils;
    window.ChartPerformanceMonitor = ChartPerformanceMonitor;
    window.ChartEventSystem = ChartEventSystem;
    window.chartEvents = chartEvents;
    window.ChartResponsiveHandler = ChartResponsiveHandler;
    window.PCChartOptimizer = PCChartOptimizer;
}

console.log('✅ Chart Rendering System v1.0 - Loaded Successfully');