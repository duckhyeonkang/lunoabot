/**
 * Chart Manager (Fixed for LightweightCharts v5.0.7)
 * Handles creation and management of multiple chart panels
 */

class ChartManager {
    constructor() {
        // Chart instances
        this.mainChart = null;
        this.volumeChart = null;
        this.rsiChart = null;
        this.macdChart = null;
        
        // Chart series
        this.candleSeries = null;
        this.volumeSeries = null;
        this.rsiSeries = null;
        this.macdSeries = null;
        this.signalSeries = null;
        this.histogramSeries = null;
        
        // Indicators
        this.indicators = {
            bb: { upper: null, middle: null, lower: null },
            ma: null,
            vwma: null,
            ema: null
        };
        
        // 지표 표시 상태
        this.indicatorVisible = {
            bb: true,
            ma: true,
            vwma: false,
            ema: false
        };
        
        // Chart data cache
        this.cachedChartData = [];
        
        // Current symbol and timeframe
        this.currentSymbol = 'BTCUSDT';
        this.currentTimeframe = '1h';
        
        // Indicator settings
        this.indicatorSettings = this.getDefaultIndicatorSettings();
        
        // Initialization flag
        this.isInitialized = false;
    }
    
    /**
     * Get default indicator settings
     */
    getDefaultIndicatorSettings() {
        return {
            rsi: {
                period: 14,
                source: 'close',
                color: '#2962ff',
                lineWidth: 2,
                upperLevel: 70,
                lowerLevel: 30,
                showLevels: true
            },
            macd: {
                fastPeriod: 12,
                slowPeriod: 26,
                signalPeriod: 9,
                source: 'close',
                macdColor: '#2962ff',
                signalColor: '#ff6b35',
                histogramColor: '#26a69a'
            },
            bb: {
                period: 20,
                stdDev: 2,
                source: 'close',
                upperColor: '#9c27b0',
                middleColor: '#9c27b0',
                lowerColor: '#9c27b0',
                showFill: false
            },
            ma: {
                period: 20,
                type: 'SMA',
                source: 'close',
                color: '#26a69a',
                lineWidth: 2
            },
            vwma: {
                period: 20,
                color: '#ff9800',
                lineWidth: 2
            },
            ema: {
                period: 20,
                source: 'close',
                color: '#e91e63',
                lineWidth: 2
            }
        };
    }
    
    /**
     * Initialize all charts
     */
    async initialize() {
        if (this.isInitialized) {
            console.warn('ChartManager already initialized');
            return true;
        }
        
        console.log('📊 Initializing ChartManager...');
        
        if (typeof LightweightCharts === 'undefined') {
            console.error('❌ LightweightCharts library not loaded');
            return false;
        }
        
        try {
            this.createCharts();
            this.createSeries();
            this.addDefaultIndicators();
            this.addRSILevels();
            this.isInitialized = true;
            
            console.log('✅ ChartManager initialized successfully');
            return true;
        } catch (error) {
            console.error('❌ ChartManager initialization failed:', error);
            return false;
        }
    }
    
    /**
     * Create all chart instances
     */
    createCharts() {
        const mainContainer = document.getElementById('main-chart-container');
        const volumeContainer = document.getElementById('volume-chart-container');
        const rsiContainer = document.getElementById('rsi-chart-container');
        const macdContainer = document.getElementById('macd-chart-container');
        
        if (!mainContainer || !volumeContainer || !rsiContainer || !macdContainer) {
            throw new Error('Chart containers not found in DOM');
        }
        
        const chartOptions = {
            layout: {
                background: { color: '#131722' },
                textColor: '#d1d4dc',
            },
            grid: {
                vertLines: { color: '#1e222d' },
                horzLines: { color: '#1e222d' },
            },
            crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
            rightPriceScale: { borderColor: '#2B2B43' },
            timeScale: {
                borderColor: '#2B2B43',
                timeVisible: true,
                secondsVisible: false,
            },
            handleScroll: {
                mouseWheel: true,
                pressedMouseMove: true,
            },
            handleScale: {
                axisPressedMouseMove: true,
                mouseWheel: true,
                pinch: true,
            },
        };
        
        // Create main chart
        this.mainChart = LightweightCharts.createChart(mainContainer, {
            ...chartOptions,
            width: mainContainer.clientWidth,
            height: mainContainer.clientHeight,
            watermark: {
                visible: false,
            },
        });
        
        // Create volume chart
        this.volumeChart = LightweightCharts.createChart(volumeContainer, {
            ...chartOptions,
            width: volumeContainer.clientWidth,
            height: volumeContainer.clientHeight,
            watermark: {
                visible: false,
            },
        });
        
        // Create RSI chart
        this.rsiChart = LightweightCharts.createChart(rsiContainer, {
            ...chartOptions,
            width: rsiContainer.clientWidth,
            height: rsiContainer.clientHeight,
            watermark: {
                visible: false,
            },
        });
        
        // Create MACD chart
        this.macdChart = LightweightCharts.createChart(macdContainer, {
            ...chartOptions,
            width: macdContainer.clientWidth,
            height: macdContainer.clientHeight,
            watermark: {
                visible: false,
            },
        });
        
        console.log('✅ All charts created successfully');
    }
    
    /**
     * Create series for all charts using v5.0.7 API
     */
    createSeries() {
        // Candlestick series for main chart
        this.candleSeries = this.mainChart.addSeries(LightweightCharts.CandlestickSeries, {
            upColor: '#26a69a',
            downColor: '#ef5350',
            borderVisible: false,
            wickUpColor: '#26a69a',
            wickDownColor: '#ef5350',
        });
        
        // Volume series
        this.volumeSeries = this.volumeChart.addSeries(LightweightCharts.HistogramSeries, {
            color: '#26a69a',
            priceFormat: { type: 'volume' },
        });
        
        // RSI series
        this.rsiSeries = this.rsiChart.addSeries(LightweightCharts.LineSeries, {
            color: this.indicatorSettings.rsi.color,
            lineWidth: this.indicatorSettings.rsi.lineWidth,
        });
        
        // MACD series
        this.macdSeries = this.macdChart.addSeries(LightweightCharts.LineSeries, {
            color: this.indicatorSettings.macd.macdColor,
            lineWidth: 2,
        });
        
        this.signalSeries = this.macdChart.addSeries(LightweightCharts.LineSeries, {
            color: this.indicatorSettings.macd.signalColor,
            lineWidth: 2,
        });
        
        this.histogramSeries = this.macdChart.addSeries(LightweightCharts.HistogramSeries, {
            color: this.indicatorSettings.macd.histogramColor,
        });
        
        console.log('✅ All series created successfully');
    }
    
    /**
     * Add RSI level lines (overbought/oversold)
     */
    addRSILevels() {
        if (!this.indicatorSettings.rsi.showLevels || !this.rsiChart) return;
        
        try {
            // Overbought line (70)
            const overboughtSeries = this.rsiChart.addSeries(LightweightCharts.LineSeries, {
                color: '#ef535080',
                lineWidth: 1,
                lineStyle: LightweightCharts.LineStyle.Dashed,
                lastValueVisible: false,
                priceLineVisible: false,
            });
            
            // Oversold line (30)
            const oversoldSeries = this.rsiChart.addSeries(LightweightCharts.LineSeries, {
                color: '#26a69a80',
                lineWidth: 1,
                lineStyle: LightweightCharts.LineStyle.Dashed,
                lastValueVisible: false,
                priceLineVisible: false,
            });
            
            // Set constant level data
            const currentTime = Math.floor(Date.now() / 1000);
            const futureTime = currentTime + (365 * 24 * 60 * 60); // 1 year future
            
            overboughtSeries.setData([
                { time: currentTime - (365 * 24 * 60 * 60), value: this.indicatorSettings.rsi.upperLevel },
                { time: futureTime, value: this.indicatorSettings.rsi.upperLevel }
            ]);
            
            oversoldSeries.setData([
                { time: currentTime - (365 * 24 * 60 * 60), value: this.indicatorSettings.rsi.lowerLevel },
                { time: futureTime, value: this.indicatorSettings.rsi.lowerLevel }
            ]);
            
            console.log('✅ RSI levels added');
        } catch (error) {
            console.warn('⚠️ Failed to add RSI levels:', error);
        }
    }
    
    /**
     * Add default indicators (Bollinger Bands and Moving Average)
     */
    addDefaultIndicators() {
        console.log('📊 Adding default indicators...');
        
        // Bollinger Bands
        this.indicators.bb = {
            upper: this.mainChart.addSeries(LightweightCharts.LineSeries, {
                color: this.indicatorSettings.bb.upperColor,
                lineWidth: 1,
            }),
            middle: this.mainChart.addSeries(LightweightCharts.LineSeries, {
                color: this.indicatorSettings.bb.middleColor,
                lineWidth: 2,
            }),
            lower: this.mainChart.addSeries(LightweightCharts.LineSeries, {
                color: this.indicatorSettings.bb.lowerColor,
                lineWidth: 1,
            })
        };
        
        // Moving Average
        this.indicators.ma = this.mainChart.addSeries(LightweightCharts.LineSeries, {
            color: this.indicatorSettings.ma.color,
            lineWidth: this.indicatorSettings.ma.lineWidth,
        });
        
        console.log('✅ Default indicators added');
    }
    
    /**
     * Load and set chart data
     */
    setChartData(chartData) {
        if (!chartData || chartData.length === 0) {
            console.warn('⚠️ No chart data provided');
            return;
        }
        
        this.cachedChartData = chartData;
        
        // Set main chart data
        if (this.candleSeries) {
            this.candleSeries.setData(chartData);
        }
        
        // Set volume data
        if (this.volumeSeries) {
            const volumeData = chartData.map(item => ({
                time: item.time,
                value: item.volume,
                color: item.close > item.open ? '#26a69a80' : '#ef535080'
            }));
            this.volumeSeries.setData(volumeData);
        }
        
        // Calculate and set indicators
        this.updateAllIndicators();
        
        console.log(`✅ Chart data set: ${chartData.length} candles`);
    }
    
    /**
     * Update a single candle (real-time update)
     */
    updateCandle(candleData) {
        if (!candleData) return;
        
        // Update main chart
        if (this.candleSeries) {
            this.candleSeries.update(candleData);
        }
        
        // Update volume
        if (this.volumeSeries) {
            const volumeData = {
                time: candleData.time,
                value: candleData.volume,
                color: candleData.close > candleData.open ? '#26a69a80' : '#ef535080'
            };
            this.volumeSeries.update(volumeData);
        }
        
        // Update cached data
        if (this.cachedChartData.length > 0) {
            const lastCached = this.cachedChartData[this.cachedChartData.length - 1];
            if (lastCached.time === candleData.time) {
                this.cachedChartData[this.cachedChartData.length - 1] = candleData;
            } else {
                this.cachedChartData.push(candleData);
                if (this.cachedChartData.length > 1000) {
                    this.cachedChartData.shift();
                }
            }
            
            // Update indicators in real-time
            this.updateIndicatorsRealtime();
        }
    }
    
    /**
     * Update all indicators with current cached data
     */
    updateAllIndicators() {
        if (!this.cachedChartData || this.cachedChartData.length === 0) {
            console.warn('⚠️ No cached data for indicator calculation');
            return;
        }
        
        // RSI
        if (this.rsiSeries) {
            const rsiData = TechnicalIndicators.calculateRSI(this.cachedChartData, this.indicatorSettings.rsi.period);
            this.rsiSeries.setData(rsiData);
        }
        
        // MACD
        if (this.macdSeries && this.signalSeries && this.histogramSeries) {
            const macdData = TechnicalIndicators.calculateMACD(this.cachedChartData);
            this.macdSeries.setData(macdData.macd);
            this.signalSeries.setData(macdData.signal);
            this.histogramSeries.setData(macdData.histogram);
        }
        
        // Bollinger Bands (표시 상태 확인)
        if (this.indicators.bb && this.indicators.bb.upper && this.indicatorVisible.bb) {
            const bbData = TechnicalIndicators.calculateBollingerBands(
                this.cachedChartData, 
                this.indicatorSettings.bb.period, 
                this.indicatorSettings.bb.stdDev
            );
            this.indicators.bb.upper.setData(bbData.upper);
            this.indicators.bb.middle.setData(bbData.middle);
            this.indicators.bb.lower.setData(bbData.lower);
        }
        
        // Moving Average (표시 상태 확인)
        if (this.indicators.ma && this.indicatorVisible.ma) {
            const maData = TechnicalIndicators.calculateMA(this.cachedChartData, this.indicatorSettings.ma.period);
            this.indicators.ma.setData(maData);
        }
        
        // VWMA
        if (this.indicators.vwma && this.indicatorVisible.vwma) {
            const vwmaData = TechnicalIndicators.calculateVWMA(this.cachedChartData, this.indicatorSettings.vwma.period);
            this.indicators.vwma.setData(vwmaData);
        }
        
        // EMA
        if (this.indicators.ema && this.indicatorVisible.ema) {
            const emaData = TechnicalIndicators.calculateEMA(this.cachedChartData, this.indicatorSettings.ema.period);
            this.indicators.ema.setData(emaData);
        }
        
        console.log('✅ All indicators updated');
    }
    
    /**
     * Update indicators in real-time (last values only)
     */
    updateIndicatorsRealtime() {
        if (!this.cachedChartData || this.cachedChartData.length < 50) return;
        
        // RSI real-time update
        if (this.rsiSeries && this.cachedChartData.length > this.indicatorSettings.rsi.period) {
            const rsiData = TechnicalIndicators.calculateRSI(this.cachedChartData, this.indicatorSettings.rsi.period);
            if (rsiData.length > 0) {
                const lastRSI = rsiData[rsiData.length - 1];
                this.rsiSeries.update(lastRSI);
            }
        }
        
        // MACD real-time update
        if (this.macdSeries && this.signalSeries && this.histogramSeries && this.cachedChartData.length > 26) {
            const macdData = TechnicalIndicators.calculateMACD(this.cachedChartData);
            if (macdData.macd.length > 0) {
                const lastMACD = macdData.macd[macdData.macd.length - 1];
                this.macdSeries.update(lastMACD);
                
                if (macdData.signal.length > 0) {
                    const lastSignal = macdData.signal[macdData.signal.length - 1];
                    this.signalSeries.update(lastSignal);
                }
                
                if (macdData.histogram.length > 0) {
                    const lastHist = macdData.histogram[macdData.histogram.length - 1];
                    this.histogramSeries.update(lastHist);
                }
            }
        }
        
        // Bollinger Bands real-time update (표시 상태 확인)
        if (this.indicators.bb && this.indicators.bb.upper && this.indicatorVisible.bb && this.cachedChartData.length > this.indicatorSettings.bb.period) {
            const bbData = TechnicalIndicators.calculateBollingerBands(
                this.cachedChartData, 
                this.indicatorSettings.bb.period, 
                this.indicatorSettings.bb.stdDev
            );
            if (bbData.upper.length > 0) {
                const lastUpper = bbData.upper[bbData.upper.length - 1];
                const lastMiddle = bbData.middle[bbData.middle.length - 1];
                const lastLower = bbData.lower[bbData.lower.length - 1];
                
                this.indicators.bb.upper.update(lastUpper);
                this.indicators.bb.middle.update(lastMiddle);
                this.indicators.bb.lower.update(lastLower);
            }
        }
        
        // MA real-time update (표시 상태 확인)
        if (this.indicators.ma && this.indicatorVisible.ma && this.cachedChartData.length > this.indicatorSettings.ma.period) {
            const maData = TechnicalIndicators.calculateMA(this.cachedChartData, this.indicatorSettings.ma.period);
            if (maData.length > 0) {
                const lastMA = maData[maData.length - 1];
                this.indicators.ma.update(lastMA);
            }
        }
        
        // VWMA real-time update
        if (this.indicators.vwma && this.indicatorVisible.vwma && this.cachedChartData.length > this.indicatorSettings.vwma.period) {
            const vwmaData = TechnicalIndicators.calculateVWMA(this.cachedChartData, this.indicatorSettings.vwma.period);
            if (vwmaData.length > 0) {
                const lastVWMA = vwmaData[vwmaData.length - 1];
                this.indicators.vwma.update(lastVWMA);
            }
        }
        
        // EMA real-time update
        if (this.indicators.ema && this.indicatorVisible.ema && this.cachedChartData.length > this.indicatorSettings.ema.period) {
            const emaData = TechnicalIndicators.calculateEMA(this.cachedChartData, this.indicatorSettings.ema.period);
            if (emaData.length > 0) {
                const lastEMA = emaData[emaData.length - 1];
                this.indicators.ema.update(lastEMA);
            }
        }
    }
    
    /**
     * Get chart configurations for synchronization
     */
    getChartConfigs() {
        return [
            { chart: this.mainChart, container: document.getElementById('main-chart-container'), name: 'main' },
            { chart: this.volumeChart, container: document.getElementById('volume-chart-container'), name: 'volume' },
            { chart: this.rsiChart, container: document.getElementById('rsi-chart-container'), name: 'rsi' },
            { chart: this.macdChart, container: document.getElementById('macd-chart-container'), name: 'macd' }
        ];
    }
    
    /**
     * Handle window resize
     */
    handleResize() {
        const containers = [
            document.getElementById('main-chart-container'),
            document.getElementById('volume-chart-container'),
            document.getElementById('rsi-chart-container'),
            document.getElementById('macd-chart-container')
        ];
        
        const charts = [this.mainChart, this.volumeChart, this.rsiChart, this.macdChart];
        
        charts.forEach((chart, index) => {
            if (chart && containers[index]) {
                try {
                    chart.applyOptions({
                        width: containers[index].clientWidth,
                        height: containers[index].clientHeight
                    });
                } catch (error) {
                    console.warn(`⚠️ Resize failed for chart ${index}:`, error);
                }
            }
        });
        
        console.log('📐 Charts resized');
    }
    
    /**
     * Update watermarks for all charts
     */
    updateWatermarks(symbol) {
        this.currentSymbol = symbol;
        
        const charts = [
            { chart: this.mainChart, text: symbol },
            { chart: this.volumeChart, text: 'Volume' },
            { chart: this.rsiChart, text: 'RSI' },
            { chart: this.macdChart, text: 'MACD' }
        ];
        
        charts.forEach(({ chart, text }) => {
            if (chart) {
                try {
                    chart.applyOptions({
                        watermark: { text: text }
                    });
                } catch (error) {
                    console.warn('⚠️ Failed to update watermark:', error);
                }
            }
        });
        
        console.log('✅ Watermarks updated');
    }
    
    /**
     * 🎛️ 볼린저밴드 토글 기능 개선 (상태 관리 포함)
     */
    toggleBollingerBands() {
        if (!this.mainChart) {
            console.warn('⚠️ Main chart not available');
            return false;
        }
        
        // 현재 표시 상태 토글
        this.indicatorVisible.bb = !this.indicatorVisible.bb;
        
        if (!this.indicatorVisible.bb) {
            // 숨기기
            try {
                if (this.indicators.bb.upper) {
                    this.indicators.bb.upper.setData([]);
                }
                if (this.indicators.bb.middle) {
                    this.indicators.bb.middle.setData([]);
                }
                if (this.indicators.bb.lower) {
                    this.indicators.bb.lower.setData([]);
                }
                
                console.log('📊 Bollinger Bands hidden');
                return false;
            } catch (error) {
                console.error('❌ Error hiding Bollinger Bands:', error);
                this.indicatorVisible.bb = true; // 에러 시 상태 복원
                return true;
            }
        } else {
            // 표시하기
            try {
                // 시리즈가 없으면 생성
                if (!this.indicators.bb.upper || !this.indicators.bb.middle || !this.indicators.bb.lower) {
                    this.indicators.bb = {
                        upper: this.mainChart.addSeries(LightweightCharts.LineSeries, {
                            color: this.indicatorSettings.bb.upperColor,
                            lineWidth: 1,
                        }),
                        middle: this.mainChart.addSeries(LightweightCharts.LineSeries, {
                            color: this.indicatorSettings.bb.middleColor,
                            lineWidth: 2,
                        }),
                        lower: this.mainChart.addSeries(LightweightCharts.LineSeries, {
                            color: this.indicatorSettings.bb.lowerColor,
                            lineWidth: 1,
                        })
                    };
                }
                
                // 데이터가 있으면 설정
                if (this.cachedChartData.length > 0) {
                    const bbData = TechnicalIndicators.calculateBollingerBands(
                        this.cachedChartData, 
                        this.indicatorSettings.bb.period, 
                        this.indicatorSettings.bb.stdDev
                    );
                    this.indicators.bb.upper.setData(bbData.upper);
                    this.indicators.bb.middle.setData(bbData.middle);
                    this.indicators.bb.lower.setData(bbData.lower);
                }
                
                console.log('📊 Bollinger Bands shown');
                return true;
            } catch (error) {
                console.error('❌ Error showing Bollinger Bands:', error);
                this.indicatorVisible.bb = false; // 에러 시 상태 복원
                return false;
            }
        }
    }
    
    /**
     * 🎛️ 이동평균선 토글 기능 개선 (상태 관리 포함)
     */
    toggleMovingAverage() {
        if (!this.mainChart) {
            console.warn('⚠️ Main chart not available');
            return false;
        }
        
        // 현재 표시 상태 토글
        this.indicatorVisible.ma = !this.indicatorVisible.ma;
        
        if (!this.indicatorVisible.ma) {
            // 숨기기
            try {
                if (this.indicators.ma) {
                    this.indicators.ma.setData([]);
                }
                console.log('📊 Moving Average hidden');
                return false;
            } catch (error) {
                console.error('❌ Error hiding Moving Average:', error);
                this.indicatorVisible.ma = true; // 에러 시 상태 복원
                return true;
            }
        } else {
            // 표시하기
            try {
                // 시리즈가 없으면 생성
                if (!this.indicators.ma) {
                    this.indicators.ma = this.mainChart.addSeries(LightweightCharts.LineSeries, {
                        color: this.indicatorSettings.ma.color,
                        lineWidth: this.indicatorSettings.ma.lineWidth,
                    });
                }
                
                // 데이터가 있으면 설정
                if (this.cachedChartData.length > 0) {
                    const maData = TechnicalIndicators.calculateMA(this.cachedChartData, this.indicatorSettings.ma.period);
                    this.indicators.ma.setData(maData);
                }
                
                console.log('📊 Moving Average shown');
                return true;
            } catch (error) {
                console.error('❌ Error showing Moving Average:', error);
                this.indicatorVisible.ma = false; // 에러 시 상태 복원
                return false;
            }
        }
    }
    
    /**
     * Clean up all chart resources
     */
    cleanup() {
        // Remove all charts
        if (this.mainChart) {
            this.mainChart.remove();
            this.mainChart = null;
        }
        
        if (this.volumeChart) {
            this.volumeChart.remove();
            this.volumeChart = null;
        }
        
        if (this.rsiChart) {
            this.rsiChart.remove();
            this.rsiChart = null;
        }
        
        if (this.macdChart) {
            this.macdChart.remove();
            this.macdChart = null;
        }
        
        // Clear references
        this.candleSeries = null;
        this.volumeSeries = null;
        this.rsiSeries = null;
        this.macdSeries = null;
        this.signalSeries = null;
        this.histogramSeries = null;
        
        this.indicators = {
            bb: { upper: null, middle: null, lower: null },
            ma: null,
            vwma: null,
            ema: null
        };
        
        this.cachedChartData = [];
        this.isInitialized = false;
        
        console.log('🧹 ChartManager cleaned up');
    }
    
    /**
     * Get current status
     */
    getStatus() {
        return {
            isInitialized: this.isInitialized,
            currentSymbol: this.currentSymbol,
            currentTimeframe: this.currentTimeframe,
            cachedDataLength: this.cachedChartData.length,
            chartsCreated: {
                main: !!this.mainChart,
                volume: !!this.volumeChart,
                rsi: !!this.rsiChart,
                macd: !!this.macdChart
            },
            seriesCreated: {
                candle: !!this.candleSeries,
                volume: !!this.volumeSeries,
                rsi: !!this.rsiSeries,
                macd: !!this.macdSeries
            },
            indicatorsActive: {
                bb: this.indicatorVisible.bb,
                ma: this.indicatorVisible.ma,
                vwma: this.indicatorVisible.vwma,
                ema: this.indicatorVisible.ema
            }
        };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChartManager;
} else {
    window.ChartManager = ChartManager;
}

// 🌍 글로벌 토글 함수 등록
window.toggleBollingerBands = function() {
    if (window.chartManager && window.chartManager.toggleBollingerBands) {
        const isVisible = window.chartManager.toggleBollingerBands();
        console.log(`Bollinger Bands: ${isVisible ? 'ON' : 'OFF'}`);
        return isVisible;
    } else {
        console.warn('⚠️ ChartManager not available');
        return false;
    }
};

window.toggleMovingAverage = function() {
    if (window.chartManager && window.chartManager.toggleMovingAverage) {
        const isVisible = window.chartManager.toggleMovingAverage();
        console.log(`Moving Average: ${isVisible ? 'ON' : 'OFF'}`);
        return isVisible;
    } else {
        console.warn('⚠️ ChartManager not available');
        return false;
    }
};