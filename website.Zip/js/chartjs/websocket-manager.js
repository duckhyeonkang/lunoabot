/**
 * WebSocket Manager for Real-time Data
 * Handles Binance WebSocket connections for live market data
 */

class WebSocketManager {
    constructor() {
        this.klineWS = null;
        this.tickerWS = null;
        this.isConnected = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 3000;
        this.lastPingTime = 0;
        this.updateThrottle = 100; // Default throttle in ms
        this.lastUpdateTime = 0;
        
        // 성능 최적화를 위한 메시지 큐 추가
        this.messageQueue = [];
        this.isProcessingQueue = false;
        
        // Event handlers
        this.onKlineUpdate = null;
        this.onTickerUpdate = null;
        this.onConnectionChange = null;
        this.onError = null;
        
        this.currentSymbol = 'BTCUSDT';
        this.currentTimeframe = '1h';
    }
    
    /**
     * Set event handlers
     * @param {Object} handlers - Object containing event handler functions
     */
    setEventHandlers(handlers) {
        this.onKlineUpdate = handlers.onKlineUpdate || null;
        this.onTickerUpdate = handlers.onTickerUpdate || null;
        this.onConnectionChange = handlers.onConnectionChange || null;
        this.onError = handlers.onError || null;
    }
    
    /**
     * Set update throttle
     * @param {number} throttle - Throttle time in milliseconds
     */
    setUpdateThrottle(throttle) {
        this.updateThrottle = throttle;
        console.log(`⚡ Update throttle set to: ${throttle}ms`);
    }
    
    /**
     * Connect to real-time WebSocket streams
     * @param {string} symbol - Trading symbol (e.g., 'BTCUSDT')
     * @param {string} timeframe - Timeframe (e.g., '1h', '5m')
     */
    connect(symbol, timeframe) {
        console.log('🚀 Starting WebSocket connections...');
        
        this.currentSymbol = symbol;
        this.currentTimeframe = timeframe;
        this.reconnectAttempts = 0;
        
        this.connectKlineStream();
        this.connectTickerStream();
    }
    
    /**
     * Connect to Kline (candlestick) WebSocket stream
     */
    connectKlineStream() {
        const intervalMap = {
            '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m',
            '1h': '1h', '4h': '4h', '1d': '1d'
        };
        
        const interval = intervalMap[this.currentTimeframe] || '1h';
        const symbol = this.currentSymbol.toLowerCase();
        const klineUrl = `wss://stream.binance.com:9443/ws/${symbol}@kline_${interval}`;
        
        console.log(`📡 Connecting to Kline stream: ${klineUrl}`);
        
        this.klineWS = new WebSocket(klineUrl);
        
        this.klineWS.onopen = () => {
            console.log('✅ Kline WebSocket connected');
            this.isConnected = true;
            this.reconnectAttempts = 0;
            this.notifyConnectionChange(true);
        };
        
        this.klineWS.onmessage = (event) => {
            this.handleKlineMessage(event);
        };
        
        this.klineWS.onerror = (error) => {
            console.error('❌ Kline WebSocket error:', error);
            this.isConnected = false;
            this.notifyConnectionChange(false);
            if (this.onError) {
                this.onError('kline', error);
            }
        };
        
        this.klineWS.onclose = (event) => {
            console.log('🔌 Kline WebSocket closed:', event.code, event.reason);
            this.isConnected = false;
            this.notifyConnectionChange(false);
            
            if (this.reconnectAttempts < this.maxReconnectAttempts) {
                this.scheduleReconnect('kline');
            } else {
                console.error('❌ Max reconnection attempts reached for Kline');
                if (this.onError) {
                    this.onError('kline', 'Max reconnection attempts reached');
                }
            }
        };
    }
    
    /**
     * Connect to Ticker WebSocket stream
     */
    connectTickerStream() {
        const symbol = this.currentSymbol.toLowerCase();
        const tickerUrl = `wss://stream.binance.com:9443/ws/${symbol}@ticker`;
        
        console.log(`📡 Connecting to Ticker stream: ${tickerUrl}`);
        
        this.tickerWS = new WebSocket(tickerUrl);
        
        this.tickerWS.onopen = () => {
            console.log('✅ Ticker WebSocket connected');
        };
        
        this.tickerWS.onmessage = (event) => {
            this.handleTickerMessage(event);
        };
        
        this.tickerWS.onerror = (error) => {
            console.error('❌ Ticker WebSocket error:', error);
            if (this.onError) {
                this.onError('ticker', error);
            }
        };
        
        this.tickerWS.onclose = (event) => {
            console.log('🔌 Ticker WebSocket closed:', event.code, event.reason);
            
            if (this.reconnectAttempts < this.maxReconnectAttempts) {
                this.scheduleReconnect('ticker');
            }
        };
    }
    
    /**
     * Handle Kline WebSocket messages
     * @param {MessageEvent} event - WebSocket message event
     */
    handleKlineMessage(event) {
        try {
            const data = JSON.parse(event.data);
            if (!data.k) return;
            
            const now = Date.now();
            
            // Apply throttling
            if (now - this.lastUpdateTime < this.updateThrottle) {
                return;
            }
            
            const kline = data.k;
            
            const candleData = {
                time: Math.floor(kline.t / 1000),
                open: parseFloat(kline.o),
                high: parseFloat(kline.h),
                low: parseFloat(kline.l),
                close: parseFloat(kline.c),
                volume: parseFloat(kline.v),
                isClosed: kline.x // Whether this kline is closed
            };
            
            // Calculate ping time
            if (this.lastPingTime > 0) {
                const ping = now - this.lastPingTime;
                this.notifyPingUpdate(ping);
            }
            this.lastPingTime = now;
            
            // Notify kline update
            if (this.onKlineUpdate) {
                this.onKlineUpdate(candleData);
            }
            
            this.lastUpdateTime = now;
            
        } catch (error) {
            console.error('❌ Kline message processing error:', error);
            if (this.onError) {
                this.onError('kline_processing', error);
            }
        }
    }
    
    /**
     * Handle Ticker WebSocket messages
     * @param {MessageEvent} event - WebSocket message event
     */
    handleTickerMessage(event) {
        try {
            const ticker = JSON.parse(event.data);
            
            const tickerData = {
                symbol: ticker.s,
                price: parseFloat(ticker.c),
                change: parseFloat(ticker.p),
                changePercent: parseFloat(ticker.P),
                volume: parseFloat(ticker.v),
                high: parseFloat(ticker.h),
                low: parseFloat(ticker.l),
                open: parseFloat(ticker.o)
            };
            
            // Notify ticker update
            if (this.onTickerUpdate) {
                this.onTickerUpdate(tickerData);
            }
            
        } catch (error) {
            console.error('❌ Ticker message processing error:', error);
            if (this.onError) {
                this.onError('ticker_processing', error);
            }
        }
    }
    
    /**
     * Schedule reconnection attempt
     * @param {string} type - Type of connection ('kline' or 'ticker')
     */
    scheduleReconnect(type) {
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * this.reconnectAttempts;
        
        console.log(`🔄 Scheduling ${type} reconnection attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
        
        setTimeout(() => {
            if (type === 'kline') {
                this.connectKlineStream();
            } else if (type === 'ticker') {
                this.connectTickerStream();
            }
        }, delay);
    }
    
    /**
     * Notify connection status change
     * @param {boolean} connected - Connection status
     */
    notifyConnectionChange(connected) {
        if (this.onConnectionChange) {
            this.onConnectionChange(connected);
        }
    }
    
    /**
     * Notify ping time update
     * @param {number} ping - Ping time in milliseconds
     */
    notifyPingUpdate(ping) {
        // This could be extended to have its own callback
        // For now, it's handled as part of the connection change
    }
    
    /**
     * Disconnect all WebSocket connections
     */
    disconnect() {
        console.log('🛑 Disconnecting WebSocket connections...');
        
        if (this.klineWS) {
            this.klineWS.close();
            this.klineWS = null;
        }
        
        if (this.tickerWS) {
            this.tickerWS.close();
            this.tickerWS = null;
        }
        
        this.isConnected = false;
        this.notifyConnectionChange(false);
        
        console.log('✅ WebSocket connections closed');
    }
    
    /**
     * Change symbol and reconnect
     * @param {string} symbol - New trading symbol
     */
    changeSymbol(symbol) {
        if (symbol === this.currentSymbol) return;
        
        console.log(`💱 Changing symbol from ${this.currentSymbol} to ${symbol}`);
        
        this.disconnect();
        
        setTimeout(() => {
            this.connect(symbol, this.currentTimeframe);
        }, 100);
    }
    
    /**
     * Change timeframe and reconnect
     * @param {string} timeframe - New timeframe
     */
    changeTimeframe(timeframe) {
        if (timeframe === this.currentTimeframe) return;
        
        console.log(`⏱️ Changing timeframe from ${this.currentTimeframe} to ${timeframe}`);
        
        this.disconnect();
        
        setTimeout(() => {
            this.connect(this.currentSymbol, timeframe);
        }, 100);
    }
    
    /**
     * Get connection status
     * @returns {Object} - Connection status information
     */
    getStatus() {
        return {
            isConnected: this.isConnected,
            currentSymbol: this.currentSymbol,
            currentTimeframe: this.currentTimeframe,
            reconnectAttempts: this.reconnectAttempts,
            updateThrottle: this.updateThrottle,
            klineConnected: this.klineWS && this.klineWS.readyState === WebSocket.OPEN,
            tickerConnected: this.tickerWS && this.tickerWS.readyState === WebSocket.OPEN
        };
    }
    
    /**
     * Test connection with ping
     * @returns {Promise} - Promise that resolves with ping time
     */
    async testConnection() {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            
            try {
                // Simple test to check if we can create a WebSocket
                const testWS = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@ticker');
                
                testWS.onopen = () => {
                    const pingTime = Date.now() - startTime;
                    testWS.close();
                    resolve(pingTime);
                };
                
                testWS.onerror = (error) => {
                    testWS.close();
                    reject(error);
                };
                
                // Timeout after 5 seconds
                setTimeout(() => {
                    testWS.close();
                    reject(new Error('Connection test timeout'));
                }, 5000);
                
            } catch (error) {
                reject(error);
            }
        });
    }
    
    /**
     * Get WebSocket statistics
     * @returns {Object} - Statistics about the WebSocket connections
     */
    getStatistics() {
        return {
            totalReconnectAttempts: this.reconnectAttempts,
            isConnected: this.isConnected,
            lastUpdateTime: this.lastUpdateTime,
            updateThrottle: this.updateThrottle,
            connections: {
                kline: this.klineWS ? this.klineWS.readyState : 'Not initialized',
                ticker: this.tickerWS ? this.tickerWS.readyState : 'Not initialized'
            }
        };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebSocketManager;
} else {
    window.WebSocketManager = WebSocketManager;
}