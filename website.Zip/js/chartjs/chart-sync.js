/**
 * Chart Synchronization Manager (기존 코드 + Crosshair 동기화 추가)
 * Handles synchronization between multiple chart panels
 */

class ChartSyncManager {
    constructor() {
        this.charts = [];
        this.syncState = {
            isTimeScaleUpdating: false,
            isDragging: false,
            isWheelSyncing: false,
            activeMaster: null,
            isCrosshairSyncing: false // 🆕 Crosshair 동기화 상태
        };
        this.syncMonitor = null;
        this.isInitialized = false;
        
        // 🆕 Crosshair 동기화용 데이터
        this.crosshairCharts = new Map(); // chartName -> {chart, series}
    }
    
    /**
     * Initialize chart synchronization system
     * @param {Array} chartConfigs - Array of {chart, container, name} objects
     */
    initialize(chartConfigs) {
        if (this.isInitialized) {
            console.warn('ChartSyncManager already initialized');
            return;
        }
        
        this.charts = chartConfigs;
        console.log('🔄 Chart synchronization initialized for:', this.charts.map(c => c.name));
        
        this.setupMouseEventSync();
        this.setupTimeScaleSync();
        this.setupMasterSlaveSystem();
        this.setupVolumeSync();
        
        // 🆕 Crosshair 동기화 초기화 (나중에 series 등록 후 활성화)
        this.setupCrosshairSync();
        
        this.isInitialized = true;
        console.log('✅ Chart synchronization setup complete');
    }
    
    /**
     * 🆕 Crosshair 동기화 설정 - TradingView 공식 API 사용
     */
    setupCrosshairSync() {
        // chartConfigs를 crosshairCharts Map으로 변환
        this.charts.forEach(chartConfig => {
            if (chartConfig.chart) {
                this.crosshairCharts.set(chartConfig.name, {
                    chart: chartConfig.chart,
                    series: null // 나중에 registerSeries로 등록
                });
            }
        });
        
        console.log('🎯 Crosshair sync structure prepared');
    }
    
    /**
     * 🆕 시리즈 등록 (ChartManager에서 호출)
     * @param {string} chartName - 차트 이름 (main, volume, rsi, macd)
     * @param {Object} series - TradingView 시리즈 객체
     */
    registerSeries(chartName, series) {
        if (this.crosshairCharts.has(chartName)) {
            const chartData = this.crosshairCharts.get(chartName);
            chartData.series = series;
            
            // Crosshair 이벤트 등록
            this.attachCrosshairEvents(chartName, chartData);
            
            console.log(`✅ Series registered for ${chartName} chart`);
        }
    }
    
    /**
     * 🆕 Crosshair 이벤트 연결 - TradingView 공식 API
     * @param {string} chartName - 차트 이름
     * @param {Object} chartData - {chart, series} 객체
     */
    attachCrosshairEvents(chartName, chartData) {
        const { chart, series } = chartData;
        
        if (!chart || !series) {
            console.warn(`⚠️ Missing chart or series for ${chartName}`);
            return;
        }
        
        try {
            chart.subscribeCrosshairMove(param => {
                if (this.syncState.isCrosshairSyncing) return;
                
                this.syncState.isCrosshairSyncing = true;
                
                try {
                    const dataPoint = this.getCrosshairDataPoint(series, param);
                    
                    // 다른 모든 차트에 crosshair 동기화
                    for (const [otherChartName, otherChartData] of this.crosshairCharts) {
                        if (otherChartName !== chartName && otherChartData.series) {
                            this.syncCrosshair(otherChartData.chart, otherChartData.series, dataPoint);
                        }
                    }
                } catch (error) {
                    console.warn(`⚠️ Crosshair sync error from ${chartName}:`, error);
                } finally {
                    setTimeout(() => {
                        this.syncState.isCrosshairSyncing = false;
                    }, 10);
                }
            });
            
            console.log(`🎯 Crosshair events attached for ${chartName}`);
        } catch (error) {
            console.error(`❌ Failed to attach crosshair events for ${chartName}:`, error);
        }
    }
    
    /**
     * 🆕 Crosshair 데이터 포인트 추출 (TradingView 공식 방법)
     * @param {Object} series - 시리즈 객체
     * @param {Object} param - Crosshair move 파라미터
     * @returns {Object|null} 데이터 포인트 또는 null
     */
    getCrosshairDataPoint(series, param) {
        if (!param.time) {
            return null;
        }
        
        const dataPoint = param.seriesData.get(series);
        return dataPoint || null;
    }
    
    /**
     * 🆕 Crosshair 위치 동기화 (TradingView 공식 API)
     * @param {Object} chart - 타겟 차트
     * @param {Object} series - 타겟 시리즈  
     * @param {Object|null} dataPoint - 데이터 포인트
     */
    syncCrosshair(chart, series, dataPoint) {
        try {
            if (dataPoint && dataPoint.value !== undefined && dataPoint.time !== undefined) {
                chart.setCrosshairPosition(dataPoint.value, dataPoint.time, series);
            } else {
                chart.clearCrosshairPosition();
            }
        } catch (error) {
            // 조용히 무시 (에러가 발생해도 차트 작동에는 지장 없음)
        }
    }
    
    /**
     * Setup mouse event synchronization (drag and wheel)
     */
    setupMouseEventSync() {
        this.charts.forEach((chartData, masterIndex) => {
            const container = chartData.container;
            let isDragging = false;
            let dragStartX = 0;
            
            // Mouse drag synchronization
            container.addEventListener('mousedown', (e) => {
                if (e.button === 0) {
                    isDragging = true;
                    dragStartX = e.clientX;
                    this.syncState.isDragging = true;
                    this.syncState.activeMaster = masterIndex;
                    container.classList.add('chart-dragging');
                }
            });
            
            container.addEventListener('mousemove', (e) => {
                if (isDragging && this.syncState.activeMaster === masterIndex) {
                    const deltaX = e.clientX - dragStartX;
                    if (Math.abs(deltaX) > 1) {
                        this.syncDragMovement(masterIndex);
                        dragStartX = e.clientX;
                    }
                }
            });
            
            container.addEventListener('mouseup', () => {
                if (isDragging) {
                    isDragging = false;
                    this.syncState.isDragging = false;
                    this.syncState.activeMaster = null;
                    container.classList.remove('chart-dragging');
                }
            });
            
            // Wheel synchronization
            container.addEventListener('wheel', (e) => {
                e.preventDefault();
                if (!this.syncState.isWheelSyncing) {
                    this.syncState.isWheelSyncing = true;
                    this.syncWheelMovement(masterIndex);
                    setTimeout(() => {
                        this.syncState.isWheelSyncing = false;
                    }, 50);
                }
            }, { passive: false });
        });
        
        // Global mouse up event
        document.addEventListener('mouseup', () => {
            this.syncState.isDragging = false;
            this.syncState.activeMaster = null;
            this.charts.forEach(chartData => {
                chartData.container.classList.remove('chart-dragging');
            });
        });
    }
    
    /**
     * Synchronize drag movement across charts
     * @param {number} masterIndex - Index of the master chart
     */
    syncDragMovement(masterIndex) {
        if (this.syncState.isTimeScaleUpdating) return;
        this.syncState.isTimeScaleUpdating = true;
        
        try {
            const masterChart = this.charts[masterIndex].chart;
            const currentRange = masterChart.timeScale().getVisibleRange();
            
            if (currentRange && this.isValidTimeRange(currentRange)) {
                this.charts.forEach((chartData, index) => {
                    if (index !== masterIndex) {
                        try {
                            chartData.chart.timeScale().setVisibleRange(currentRange);
                        } catch (error) {
                            console.warn(`⚠️ Chart ${index} drag sync failed:`, error);
                        }
                    }
                });
            }
        } catch (error) {
            console.warn('⚠️ Drag synchronization error:', error);
        } finally {
            setTimeout(() => {
                this.syncState.isTimeScaleUpdating = false;
            }, 10);
        }
    }
    
    /**
     * Synchronize wheel movement across charts
     * @param {number} masterIndex - Index of the master chart
     */
    syncWheelMovement(masterIndex) {
        try {
            const masterChart = this.charts[masterIndex].chart;
            
            // Wait a bit for the wheel action to complete
            setTimeout(() => {
                const currentRange = masterChart.timeScale().getVisibleRange();
                
                if (currentRange && this.isValidTimeRange(currentRange)) {
                    this.charts.forEach((chartData, index) => {
                        if (index !== masterIndex) {
                            try {
                                chartData.chart.timeScale().setVisibleRange(currentRange);
                            } catch (error) {
                                console.warn(`⚠️ Chart ${index} wheel sync failed:`, error);
                            }
                        }
                    });
                }
            }, 10);
        } catch (error) {
            console.warn('⚠️ Wheel synchronization error:', error);
        }
    }
    
    /**
     * Setup time scale synchronization
     */
    setupTimeScaleSync() {
        this.charts.forEach((chartData, masterIndex) => {
            const chart = chartData.chart;
            
            chart.timeScale().subscribeVisibleTimeRangeChange((timeRange) => {
                if (this.syncState.isTimeScaleUpdating || 
                    this.syncState.isDragging || 
                    this.syncState.isWheelSyncing) {
                    return;
                }
                
                if (!timeRange || !this.isValidTimeRange(timeRange)) {
                    return;
                }
                
                this.syncState.isTimeScaleUpdating = true;
                
                try {
                    this.charts.forEach((otherChartData, index) => {
                        if (index !== masterIndex) {
                            try {
                                otherChartData.chart.timeScale().setVisibleRange(timeRange);
                            } catch (error) {
                                console.warn(`⚠️ Chart ${index} time scale sync failed:`, error);
                            }
                        }
                    });
                } catch (error) {
                    console.warn('⚠️ Time scale synchronization error:', error);
                } finally {
                    setTimeout(() => {
                        this.syncState.isTimeScaleUpdating = false;
                    }, 10);
                }
            });
        });
    }
    
    /**
     * Setup master-slave system for chart management
     */
    setupMasterSlaveSystem() {
        // Monitor to reset sync state
        this.syncMonitor = setInterval(() => {
            if (this.syncState.isTimeScaleUpdating) {
                this.syncState.isTimeScaleUpdating = false;
            }
            if (this.syncState.isWheelSyncing) {
                this.syncState.isWheelSyncing = false;
            }
            if (this.syncState.isCrosshairSyncing) {
                this.syncState.isCrosshairSyncing = false;
            }
        }, 2000);
        
        // Focus event to force sync
        window.addEventListener('focus', () => {
            setTimeout(() => {
                this.forceSyncAllCharts();
            }, 100);
        });
    }
    
    /**
     * Setup enhanced volume chart synchronization
     */
    setupVolumeSync() {
        if (this.charts.length < 2) return;
        
        const mainChart = this.charts.find(c => c.name === 'main')?.chart;
        const volumeChart = this.charts.find(c => c.name === 'volume')?.chart;
        
        if (!mainChart || !volumeChart) {
            console.warn('⚠️ Main or volume chart not found for enhanced sync');
            return;
        }
        
        console.log('📊 Setting up enhanced volume chart synchronization...');
        
        // Main chart controls volume chart time scale
        mainChart.timeScale().subscribeVisibleTimeRangeChange((timeRange) => {
            if (!this.syncState.isTimeScaleUpdating && 
                timeRange && 
                this.isValidTimeRange(timeRange)) {
                try {
                    volumeChart.timeScale().setVisibleRange(timeRange);
                } catch (error) {
                    console.warn('⚠️ Volume chart sync failed:', error);
                }
            }
        });
        
        // Initial sync
        setTimeout(() => {
            try {
                const mainRange = mainChart.timeScale().getVisibleRange();
                if (mainRange && this.isValidTimeRange(mainRange)) {
                    volumeChart.timeScale().setVisibleRange(mainRange);
                    console.log('✅ Initial volume chart sync completed');
                }
            } catch (error) {
                console.warn('⚠️ Initial volume sync failed:', error);
            }
        }, 500);
    }
    
    /**
     * Force synchronization of all charts to the master (first) chart
     */
    forceSyncAllCharts() {
        if (this.charts.length < 2) return;
        
        this.syncState.isTimeScaleUpdating = true;
        
        try {
            const masterChart = this.charts[0].chart;
            const masterRange = masterChart.timeScale().getVisibleRange();
            
            if (masterRange && this.isValidTimeRange(masterRange)) {
                this.charts.slice(1).forEach((chartData, index) => {
                    try {
                        chartData.chart.timeScale().setVisibleRange(masterRange);
                    } catch (error) {
                        console.warn(`⚠️ Force sync failed for chart ${index + 1}:`, error);
                    }
                });
                console.log('🔄 Force sync completed');
            }
        } catch (error) {
            console.warn('⚠️ Master chart range retrieval failed:', error);
        } finally {
            setTimeout(() => {
                this.syncState.isTimeScaleUpdating = false;
            }, 100);
        }
    }
    
    /**
     * Validate time range for synchronization
     * @param {Object} timeRange - Time range object with from and to properties
     * @returns {boolean} - Whether the time range is valid
     */
    isValidTimeRange(timeRange) {
        if (!timeRange) return false;
        if (typeof timeRange.from !== 'number' || typeof timeRange.to !== 'number') return false;
        if (timeRange.from >= timeRange.to) return false;
        if (!isFinite(timeRange.from) || !isFinite(timeRange.to)) return false;
        
        const duration = timeRange.to - timeRange.from;
        if (duration < 1 || duration > 365 * 24 * 60 * 60) return false;
        
        return true;
    }
    
    /**
     * Add visual feedback for chart synchronization
     * @param {number} chartIndex - Index of the chart to highlight
     */
    addSyncVisualFeedback(chartIndex) {
        if (this.charts[chartIndex]) {
            const container = this.charts[chartIndex].container;
            container.classList.add('chart-syncing');
            
            setTimeout(() => {
                container.classList.remove('chart-syncing');
            }, 200);
        }
    }
    
    /**
     * Handle window resize and maintain synchronization
     */
    handleResize() {
        this.charts.forEach((chartData, index) => {
            if (chartData.chart && chartData.container) {
                try {
                    chartData.chart.applyOptions({
                        width: chartData.container.clientWidth,
                        height: chartData.container.clientHeight
                    });
                } catch (error) {
                    console.warn(`⚠️ Chart ${index} resize failed:`, error);
                }
            }
        });
        
        // Force sync after resize
        setTimeout(() => {
            this.forceSyncAllCharts();
        }, 100);
    }
    
    /**
     * Cleanup synchronization resources
     */
    cleanup() {
        if (this.syncMonitor) {
            clearInterval(this.syncMonitor);
            this.syncMonitor = null;
        }
        
        // 🆕 Crosshair 동기화 정리
        this.crosshairCharts.clear();
        
        this.charts = [];
        this.syncState = {
            isTimeScaleUpdating: false,
            isDragging: false,
            isWheelSyncing: false,
            activeMaster: null,
            isCrosshairSyncing: false
        };
        
        this.isInitialized = false;
        console.log('🧹 Chart synchronization cleaned up');
    }
    
    /**
     * Get synchronization status
     * @returns {Object} - Current sync state and statistics
     */
    getSyncStatus() {
        return {
            isInitialized: this.isInitialized,
            chartCount: this.charts.length,
            crosshairChartsCount: this.crosshairCharts.size,
            syncState: { ...this.syncState },
            chartNames: this.charts.map(c => c.name),
            crosshairChartNames: Array.from(this.crosshairCharts.keys())
        };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChartSyncManager;
} else {
    window.ChartSyncManager = ChartSyncManager;
}