/**
 * Settings Modal Manager
 * Handles chart settings, indicators configuration, and presets
 */

class SettingsModalManager {
    constructor() {
        this.modal = null;
        this.currentChartType = null;
        this.currentSettings = {};
        this.presets = this.getDefaultPresets();
        this.isInitialized = false;
        
        // Callbacks
        this.onSettingsApply = null;
        this.onPresetLoad = null;
        this.onPresetSave = null;
    }
    
    /**
     * Initialize the settings modal system
     * @param {Object} callbacks - Callback functions for settings events
     */
    initialize(callbacks = {}) {
        if (this.isInitialized) {
            console.warn('SettingsModalManager already initialized');
            return;
        }
        
        this.onSettingsApply = callbacks.onSettingsApply || null;
        this.onPresetLoad = callbacks.onPresetLoad || null;
        this.onPresetSave = callbacks.onPresetSave || null;
        
        this.modal = document.getElementById('settings-modal');
        if (!this.modal) {
            console.error('❌ Settings modal not found');
            return false;
        }
        
        this.setupEventListeners();
        this.loadPresetsFromStorage();
        
        this.isInitialized = true;
        console.log('✅ SettingsModalManager initialized');
        return true;
    }
    
    /**
     * Get default presets
     * @returns {Object} Default preset configurations
     */
    getDefaultPresets() {
        return {
            default: {
                name: '기본값',
                rsi: { period: 14, upperLevel: 70, lowerLevel: 30 },
                macd: { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
                bb: { period: 20, stdDev: 2 },
                ma: { period: 20, type: 'SMA' }
            },
            trading: {
                name: '트레이딩',
                rsi: { period: 9, upperLevel: 80, lowerLevel: 20 },
                macd: { fastPeriod: 8, slowPeriod: 21, signalPeriod: 5 },
                bb: { period: 15, stdDev: 1.8 },
                ma: { period: 10, type: 'EMA' }
            },
            analysis: {
                name: '분석용',
                rsi: { period: 21, upperLevel: 75, lowerLevel: 25 },
                macd: { fastPeriod: 15, slowPeriod: 30, signalPeriod: 12 },
                bb: { period: 25, stdDev: 2.2 },
                ma: { period: 50, type: 'SMA' }
            }
        };
    }
    
    /**
     * Setup event listeners for modal interactions
     */
    setupEventListeners() {
        // Close button
        const closeBtn = document.getElementById('close-settings');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }
        
        // Click outside to close
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.closeModal();
            }
        });
        
        // Tab system
        this.setupTabSystem();
        
        // Range inputs real-time update
        this.setupRangeInputs();
        
        // Checkbox handlers
        this.setupCheckboxHandlers();
        
        // Action buttons
        this.setupActionButtons();
        
        // Preset management
        this.setupPresetHandlers();
        
        console.log('✅ Settings modal event listeners setup complete');
    }
    
    /**
     * Setup tab system for settings categories
     */
    setupTabSystem() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');
        
        tabBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const targetTab = e.target.dataset.tab;
                this.switchTab(targetTab);
            });
        });
    }
    
    /**
     * Switch between tabs
     * @param {string} targetTab - Target tab ID
     */
    switchTab(targetTab) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${targetTab}"]`).classList.add('active');
        
        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${targetTab}-tab`).classList.add('active');
        
        console.log(`📑 Switched to tab: ${targetTab}`);
    }
    
    /**
     * Setup range input handlers for real-time value display
     */
    setupRangeInputs() {
        const lineWidthInput = document.getElementById('line-width-input');
        const opacityInput = document.getElementById('opacity-input');
        
        if (lineWidthInput) {
            lineWidthInput.addEventListener('input', (e) => {
                const valueDisplay = document.getElementById('line-width-value');
                if (valueDisplay) {
                    valueDisplay.textContent = e.target.value;
                }
            });
        }
        
        if (opacityInput) {
            opacityInput.addEventListener('input', (e) => {
                const valueDisplay = document.getElementById('opacity-value');
                if (valueDisplay) {
                    valueDisplay.textContent = e.target.value + '%';
                }
            });
        }
    }
    
    /**
     * Setup checkbox handlers
     */
    setupCheckboxHandlers() {
        const showLevelsCheckbox = document.getElementById('show-levels');
        if (showLevelsCheckbox) {
            showLevelsCheckbox.addEventListener('change', (e) => {
                const levelsSettings = document.getElementById('levels-settings');
                if (levelsSettings) {
                    levelsSettings.style.display = e.target.checked ? 'block' : 'none';
                }
            });
        }
    }
    
    /**
     * Setup action buttons (Apply, Preview, Reset)
     */
    setupActionButtons() {
        const applyBtn = document.getElementById('apply-settings');
        const previewBtn = document.getElementById('preview-settings');
        const resetBtn = document.getElementById('reset-to-default');
        
        if (applyBtn) {
            applyBtn.addEventListener('click', () => this.applySettings());
        }
        
        if (previewBtn) {
            previewBtn.addEventListener('click', () => this.previewSettings());
        }
        
        if (resetBtn) {
            resetBtn.addEventListener('click', () => this.resetToDefault());
        }
    }
    
    /**
     * Setup preset management handlers
     */
    setupPresetHandlers() {
        // Preset item clicks
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('preset-item')) {
                const presetName = e.target.dataset.preset;
                if (presetName) {
                    this.loadPreset(presetName);
                }
            }
        });
        
        // Save new preset button (if exists)
        const savePresetBtn = document.getElementById('save-new-preset');
        if (savePresetBtn) {
            savePresetBtn.addEventListener('click', () => this.saveNewPreset());
        }
    }
    
    /**
     * Open settings modal for specific chart type
     * @param {string} chartType - Type of chart ('main', 'rsi', 'macd', 'volume')
     * @param {Object} currentSettings - Current settings for the chart type
     */
    openModal(chartType, currentSettings = {}) {
        if (!this.isInitialized) {
            console.error('❌ SettingsModalManager not initialized');
            return;
        }
        
        this.currentChartType = chartType;
        this.currentSettings = { ...currentSettings };
        
        // Update modal title
        this.updateModalTitle(chartType);
        
        // Populate settings fields
        this.populateSettings(chartType, currentSettings);
        
        // Show modal
        this.modal.classList.add('show');
        
        console.log(`⚙️ Settings modal opened for: ${chartType}`);
    }
    
    /**
     * Close settings modal
     */
    closeModal() {
        if (this.modal) {
            this.modal.classList.remove('show');
            this.currentChartType = null;
            this.currentSettings = {};
        }
    }
    
    /**
     * Update modal title based on chart type
     * @param {string} chartType - Chart type
     */
    updateModalTitle(chartType) {
        const titleElement = document.getElementById('settings-title');
        if (!titleElement) return;
        
        const titles = {
            main: '📊 메인 차트 설정',
            volume: '📊 볼륨 차트 설정',
            rsi: '📈 RSI 지표 설정',
            macd: '📉 MACD 지표 설정',
            bb: '🎯 볼린저밴드 설정',
            ma: '📉 이동평균 설정'
        };
        
        titleElement.textContent = titles[chartType] || '⚙️ 차트 설정';
    }
    
    /**
     * Populate settings fields with current values
     * @param {string} chartType - Chart type
     * @param {Object} settings - Current settings
     */
    populateSettings(chartType, settings) {
        // Clear indicator-specific settings
        const specificContainer = document.getElementById('indicator-specific-settings');
        if (specificContainer) {
            specificContainer.innerHTML = '';
        }
        
        switch (chartType) {
            case 'rsi':
                this.populateRSISettings(settings);
                break;
            case 'macd':
                this.populateMACDSettings(settings);
                break;
            case 'bb':
                this.populateBBSettings(settings);
                break;
            case 'ma':
                this.populateMASettings(settings);
                break;
            case 'main':
                this.populateMainSettings(settings);
                break;
            default:
                this.populateGenericSettings(settings);
        }
    }
    
    /**
     * Populate RSI settings
     * @param {Object} settings - RSI settings
     */
    populateRSISettings(settings) {
        this.setInputValue('period-input', settings.period || 14);
        this.setInputValue('source-input', settings.source || 'close');
        this.setInputValue('color-input', settings.color || '#2962ff');
        this.setInputValue('line-width-input', settings.lineWidth || 2);
        this.setInputValue('upper-level', settings.upperLevel || 70);
        this.setInputValue('lower-level', settings.lowerLevel || 30);
        
        const showLevelsCheckbox = document.getElementById('show-levels');
        if (showLevelsCheckbox) {
            showLevelsCheckbox.checked = settings.showLevels !== false;
            
            const levelsSettings = document.getElementById('levels-settings');
            if (levelsSettings) {
                levelsSettings.style.display = showLevelsCheckbox.checked ? 'block' : 'none';
            }
        }
        
        this.updateRangeDisplay('line-width-input', 'line-width-value');
    }
    
    /**
     * Populate MACD settings
     * @param {Object} settings - MACD settings
     */
    populateMACDSettings(settings) {
        this.setInputValue('period-input', settings.signalPeriod || 9);
        this.setInputValue('source-input', settings.source || 'close');
        this.setInputValue('color-input', settings.macdColor || '#2962ff');
        
        // Add MACD-specific settings
        const specificContainer = document.getElementById('indicator-specific-settings');
        if (specificContainer) {
            specificContainer.innerHTML = `
                <div class="setting-group">
                    <label class="setting-label">빠른선 (Fast Period)</label>
                    <input type="number" class="setting-input" id="fast-period" value="${settings.fastPeriod || 12}" min="1" max="50">
                </div>
                <div class="setting-group">
                    <label class="setting-label">느린선 (Slow Period)</label>
                    <input type="number" class="setting-input" id="slow-period" value="${settings.slowPeriod || 26}" min="1" max="100">
                </div>
                <div class="setting-group">
                    <label class="setting-label">신호선 색상</label>
                    <input type="color" class="color-input" id="signal-color" value="${settings.signalColor || '#ff6b35'}">
                </div>
            `;
        }
    }
    
    /**
     * Populate Bollinger Bands settings
     * @param {Object} settings - BB settings
     */
    populateBBSettings(settings) {
        this.setInputValue('period-input', settings.period || 20);
        this.setInputValue('source-input', settings.source || 'close');
        this.setInputValue('color-input', settings.upperColor?.replace('80', '') || '#9c27b0');
        
        // Add BB-specific settings
        const specificContainer = document.getElementById('indicator-specific-settings');
        if (specificContainer) {
            specificContainer.innerHTML = `
                <div class="setting-group">
                    <label class="setting-label">표준편차 (Standard Deviation)</label>
                    <input type="number" class="setting-input" id="bb-stddev" value="${settings.stdDev || 2}" min="0.5" max="5" step="0.1">
                </div>
                <div class="setting-group">
                    <label class="setting-label">밴드 색상</label>
                    <div class="setting-row">
                        <input type="color" class="color-input" id="bb-upper-color" value="${settings.upperColor?.replace('80', '') || '#9c27b0'}" title="상단 밴드">
                        <input type="color" class="color-input" id="bb-middle-color" value="${settings.middleColor || '#9c27b0'}" title="중간선">
                        <input type="color" class="color-input" id="bb-lower-color" value="${settings.lowerColor?.replace('80', '') || '#9c27b0'}" title="하단 밴드">
                    </div>
                </div>
            `;
        }
    }
    
    /**
     * Populate Moving Average settings
     * @param {Object} settings - MA settings
     */
    populateMASettings(settings) {
        this.setInputValue('period-input', settings.period || 20);
        this.setInputValue('source-input', settings.source || 'close');
        this.setInputValue('color-input', settings.color || '#26a69a');
        this.setInputValue('line-width-input', settings.lineWidth || 2);
        
        // Add MA-specific settings
        const specificContainer = document.getElementById('indicator-specific-settings');
        if (specificContainer) {
            specificContainer.innerHTML = `
                <div class="setting-group">
                    <label class="setting-label">이동평균 타입</label>
                    <select class="setting-input" id="ma-type">
                        <option value="SMA" ${settings.type === 'SMA' ? 'selected' : ''}>Simple MA (SMA)</option>
                        <option value="EMA" ${settings.type === 'EMA' ? 'selected' : ''}>Exponential MA (EMA)</option>
                        <option value="WMA" ${settings.type === 'WMA' ? 'selected' : ''}>Weighted MA (WMA)</option>
                    </select>
                </div>
                <div class="setting-group">
                    <label class="setting-label">선 스타일</label>
                    <select class="setting-input" id="line-style">
                        <option value="solid">실선 (Solid)</option>
                        <option value="dashed">점선 (Dashed)</option>
                        <option value="dotted">대시선 (Dotted)</option>
                    </select>
                </div>
            `;
        }
        
        this.updateRangeDisplay('line-width-input', 'line-width-value');
    }
    
    /**
     * Populate main chart settings
     * @param {Object} settings - Main chart settings
     */
    populateMainSettings(settings) {
        // This could include multiple indicators
        this.populateGenericSettings(settings);
    }
    
    /**
     * Populate generic settings
     * @param {Object} settings - Generic settings
     */
    populateGenericSettings(settings) {
        this.setInputValue('period-input', settings.period || 14);
        this.setInputValue('source-input', settings.source || 'close');
        this.setInputValue('color-input', settings.color || '#2962ff');
        this.setInputValue('line-width-input', settings.lineWidth || 2);
        this.setInputValue('opacity-input', settings.opacity || 100);
        
        this.updateRangeDisplay('line-width-input', 'line-width-value');
        this.updateRangeDisplay('opacity-input', 'opacity-value', '%');
    }
    
    /**
     * Set input value if element exists
     * @param {string} id - Element ID
     * @param {*} value - Value to set
     */
    setInputValue(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.value = value;
        }
    }
    
    /**
     * Update range input display
     * @param {string} inputId - Range input ID
     * @param {string} displayId - Display element ID
     * @param {string} suffix - Optional suffix for display
     */
    updateRangeDisplay(inputId, displayId, suffix = '') {
        const input = document.getElementById(inputId);
        const display = document.getElementById(displayId);
        
        if (input && display) {
            display.textContent = input.value + suffix;
        }
    }
    
    /**
     * Apply current settings
     */
    applySettings() {
        const settings = this.collectSettings();
        
        if (this.onSettingsApply) {
            this.onSettingsApply(this.currentChartType, settings);
        }
        
        this.closeModal();
        console.log('✅ Settings applied:', settings);
    }
    
    /**
     * Preview settings without applying
     */
    previewSettings() {
        const settings = this.collectSettings();
        
        if (this.onSettingsApply) {
            this.onSettingsApply(this.currentChartType, settings, true); // true = preview mode
        }
        
        console.log('👁️ Settings preview:', settings);
    }
    
    /**
     * Reset to default settings
     */
    resetToDefault() {
        const defaultPreset = this.presets.default;
        
        if (this.currentChartType && defaultPreset[this.currentChartType]) {
            this.populateSettings(this.currentChartType, defaultPreset[this.currentChartType]);
        } else {
            // Generic reset
            this.setInputValue('period-input', 14);
            this.setInputValue('source-input', 'close');
            this.setInputValue('color-input', '#2962ff');
            this.setInputValue('line-width-input', 2);
            this.setInputValue('opacity-input', 100);
            
            this.updateRangeDisplay('line-width-input', 'line-width-value');
            this.updateRangeDisplay('opacity-input', 'opacity-value', '%');
        }
        
        console.log('🔄 Settings reset to default');
    }
    
    /**
     * Collect current settings from form
     * @returns {Object} Collected settings
     */
    collectSettings() {
        const settings = {
            period: parseInt(document.getElementById('period-input')?.value || 14),
            source: document.getElementById('source-input')?.value || 'close',
            color: document.getElementById('color-input')?.value || '#2962ff',
            lineWidth: parseInt(document.getElementById('line-width-input')?.value || 2),
            opacity: parseInt(document.getElementById('opacity-input')?.value || 100)
        };
        
        // Collect chart-specific settings
        switch (this.currentChartType) {
            case 'rsi':
                settings.upperLevel = parseInt(document.getElementById('upper-level')?.value || 70);
                settings.lowerLevel = parseInt(document.getElementById('lower-level')?.value || 30);
                settings.showLevels = document.getElementById('show-levels')?.checked;
                break;
                
            case 'macd':
                settings.fastPeriod = parseInt(document.getElementById('fast-period')?.value || 12);
                settings.slowPeriod = parseInt(document.getElementById('slow-period')?.value || 26);
                settings.signalPeriod = settings.period;
                settings.signalColor = document.getElementById('signal-color')?.value || '#ff6b35';
                break;
                
            case 'bb':
                settings.stdDev = parseFloat(document.getElementById('bb-stddev')?.value || 2);
                settings.upperColor = document.getElementById('bb-upper-color')?.value || '#9c27b0';
                settings.middleColor = document.getElementById('bb-middle-color')?.value || '#9c27b0';
                settings.lowerColor = document.getElementById('bb-lower-color')?.value || '#9c27b0';
                break;
                
            case 'ma':
                settings.type = document.getElementById('ma-type')?.value || 'SMA';
                settings.lineStyle = document.getElementById('line-style')?.value || 'solid';
                break;
        }
        
        return settings;
    }
    
    /**
     * Load preset
     * @param {string} presetName - Name of preset to load
     */
    loadPreset(presetName) {
        const preset = this.presets[presetName];
        if (!preset) {
            console.warn(`⚠️ Preset not found: ${presetName}`);
            return;
        }
        
        // Update active preset UI
        document.querySelectorAll('.preset-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const presetElement = document.querySelector(`[data-preset="${presetName}"]`);
        if (presetElement) {
            presetElement.classList.add('active');
        }
        
        // Load preset settings for current chart type
        if (this.currentChartType && preset[this.currentChartType]) {
            this.populateSettings(this.currentChartType, preset[this.currentChartType]);
        }
        
        if (this.onPresetLoad) {
            this.onPresetLoad(presetName, preset);
        }
        
        console.log(`📋 Preset loaded: ${presetName}`);
    }
    
    /**
     * Save new preset
     */
    saveNewPreset() {
        const nameInput = document.getElementById('new-preset-name');
        if (!nameInput || !nameInput.value.trim()) {
            alert('프리셋 이름을 입력해주세요.');
            return;
        }
        
        const presetName = nameInput.value.trim();
        const settings = this.collectSettings();
        
        // Save to presets
        if (!this.presets[presetName]) {
            this.presets[presetName] = { name: presetName };
        }
        
        this.presets[presetName][this.currentChartType] = settings;
        
        // Save to localStorage
        this.savePresetsToStorage();
        
        // Update UI
        this.updatePresetsList();
        
        if (this.onPresetSave) {
            this.onPresetSave(presetName, settings);
        }
        
        nameInput.value = '';
        console.log(`💾 Preset saved: ${presetName}`);
    }
    
    /**
     * Update presets list in UI
     */
    updatePresetsList() {
        const presetsList = document.getElementById('preset-list');
        if (!presetsList) return;
        
        presetsList.innerHTML = '';
        
        Object.keys(this.presets).forEach(presetName => {
            const preset = this.presets[presetName];
            const presetElement = document.createElement('div');
            presetElement.className = 'preset-item';
            presetElement.dataset.preset = presetName;
            presetElement.textContent = preset.name || presetName;
            presetsList.appendChild(presetElement);
        });
    }
    
    /**
     * Save presets to localStorage
     */
    savePresetsToStorage() {
        try {
            localStorage.setItem('chartPresets', JSON.stringify(this.presets));
        } catch (error) {
            console.warn('⚠️ Failed to save presets to localStorage:', error);
        }
    }
    
    /**
     * Load presets from localStorage
     */
    loadPresetsFromStorage() {
        try {
            const stored = localStorage.getItem('chartPresets');
            if (stored) {
                const loadedPresets = JSON.parse(stored);
                this.presets = { ...this.presets, ...loadedPresets };
                this.updatePresetsList();
                console.log('✅ Presets loaded from storage');
            }
        } catch (error) {
            console.warn('⚠️ Failed to load presets from localStorage:', error);
        }
    }
    
    /**
     * Get current presets
     * @returns {Object} Current presets
     */
    getPresets() {
        return { ...this.presets };
    }
    
    /**
     * Set presets (useful for importing)
     * @param {Object} presets - Presets to set
     */
    setPresets(presets) {
        this.presets = { ...presets };
        this.updatePresetsList();
        this.savePresetsToStorage();
    }
    
    /**
     * Export presets as JSON
     * @returns {string} JSON string of presets
     */
    exportPresets() {
        return JSON.stringify(this.presets, null, 2);
    }
    
    /**
     * Import presets from JSON
     * @param {string} jsonString - JSON string of presets
     * @returns {boolean} Success status
     */
    importPresets(jsonString) {
        try {
            const importedPresets = JSON.parse(jsonString);
            this.setPresets(importedPresets);
            console.log('✅ Presets imported successfully');
            return true;
        } catch (error) {
            console.error('❌ Failed to import presets:', error);
            return false;
        }
    }
    
    /**
     * Get modal status
     * @returns {Object} Status information
     */
    getStatus() {
        return {
            isInitialized: this.isInitialized,
            isOpen: this.modal?.classList.contains('show') || false,
            currentChartType: this.currentChartType,
            presetCount: Object.keys(this.presets).length
        };
    }
    
    /**
     * Cleanup resources
     */
    cleanup() {
        this.closeModal();
        this.modal = null;
        this.currentChartType = null;
        this.currentSettings = {};
        this.onSettingsApply = null;
        this.onPresetLoad = null;
        this.onPresetSave = null;
        this.isInitialized = false;
        
        console.log('🧹 SettingsModalManager cleaned up');
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SettingsModalManager;
} else {
    window.SettingsModalManager = SettingsModalManager;
}