/**
 * Technical Indicators Calculator
 * RSI, MACD, Bollinger Bands, Moving Averages, etc.
 */

class TechnicalIndicators {
    
    /**
     * Calculate RSI (Relative Strength Index)
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for RSI calculation (default: 14)
     * @returns {Array} RSI data points
     */
    static calculateRSI(data, period = 14) {
        const rsiData = [];
        
        if (data.length < period + 1) return rsiData;
        
        let gains = 0;
        let losses = 0;
        
        // Calculate initial average gain and loss
        for (let i = 1; i <= period; i++) {
            const change = data[i].close - data[i - 1].close;
            if (change > 0) {
                gains += change;
            } else {
                losses -= change;
            }
        }
        
        let avgGain = gains / period;
        let avgLoss = losses / period;
        
        if (avgLoss !== 0) {
            const rs = avgGain / avgLoss;
            const rsi = 100 - (100 / (1 + rs));
            rsiData.push({
                time: data[period].time,
                value: rsi
            });
        }
        
        // Calculate RSI for remaining data
        for (let i = period + 1; i < data.length; i++) {
            const change = data[i].close - data[i - 1].close;
            let currentGain = 0;
            let currentLoss = 0;
            
            if (change > 0) {
                currentGain = change;
            } else {
                currentLoss = -change;
            }
            
            avgGain = (avgGain * (period - 1) + currentGain) / period;
            avgLoss = (avgLoss * (period - 1) + currentLoss) / period;
            
            if (avgLoss !== 0) {
                const rs = avgGain / avgLoss;
                const rsi = 100 - (100 / (1 + rs));
                rsiData.push({
                    time: data[i].time,
                    value: rsi
                });
            }
        }
        
        return rsiData;
    }
    
    /**
     * Calculate MACD (Moving Average Convergence Divergence)
     * @param {Array} data - OHLCV data
     * @param {number} fast - Fast period (default: 12)
     * @param {number} slow - Slow period (default: 26)
     * @param {number} signal - Signal period (default: 9)
     * @returns {Object} MACD, signal, and histogram data
     */
    static calculateMACD(data, fast = 12, slow = 26, signal = 9) {
        const result = { macd: [], signal: [], histogram: [] };
        
        if (data.length < slow + signal) return result;
        
        const calculateEMA = (values, period) => {
            const ema = [];
            const multiplier = 2 / (period + 1);
            
            let sum = 0;
            for (let i = 0; i < period; i++) {
                sum += values[i];
            }
            ema[period - 1] = sum / period;
            
            for (let i = period; i < values.length; i++) {
                ema[i] = (values[i] - ema[i - 1]) * multiplier + ema[i - 1];
            }
            
            return ema;
        };
        
        const closePrices = data.map(d => d.close);
        const fastEMA = calculateEMA(closePrices, fast);
        const slowEMA = calculateEMA(closePrices, slow);
        
        const macdLine = [];
        for (let i = slow - 1; i < fastEMA.length; i++) {
            if (fastEMA[i] !== undefined && slowEMA[i] !== undefined) {
                macdLine.push(fastEMA[i] - slowEMA[i]);
            }
        }
        
        const signalLine = calculateEMA(macdLine, signal);
        
        for (let i = 0; i < macdLine.length; i++) {
            const dataIndex = i + slow - 1;
            if (dataIndex < data.length && macdLine[i] !== undefined) {
                result.macd.push({
                    time: data[dataIndex].time,
                    value: macdLine[i]
                });
                
                if (signalLine[i] !== undefined) {
                    result.signal.push({
                        time: data[dataIndex].time,
                        value: signalLine[i]
                    });
                    
                    result.histogram.push({
                        time: data[dataIndex].time,
                        value: macdLine[i] - signalLine[i],
                        color: macdLine[i] > signalLine[i] ? '#26a69a80' : '#ef535080'
                    });
                }
            }
        }
        
        return result;
    }
    
    /**
     * Calculate Simple Moving Average (SMA)
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for MA calculation
     * @returns {Array} MA data points
     */
    static calculateMA(data, period) {
        const maData = [];
        
        for (let i = period - 1; i < data.length; i++) {
            let sum = 0;
            for (let j = 0; j < period; j++) {
                sum += data[i - j].close;
            }
            
            maData.push({
                time: data[i].time,
                value: sum / period
            });
        }
        
        return maData;
    }
    
    /**
     * Calculate Exponential Moving Average (EMA)
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for EMA calculation
     * @returns {Array} EMA data points
     */
    static calculateEMA(data, period) {
        const emaData = [];
        const multiplier = 2 / (period + 1);
        
        // First value is SMA
        let sum = 0;
        for (let i = 0; i < period; i++) {
            sum += data[i].close;
        }
        
        let ema = sum / period;
        emaData.push({
            time: data[period - 1].time,
            value: ema
        });
        
        // Calculate EMA for remaining data
        for (let i = period; i < data.length; i++) {
            ema = (data[i].close - ema) * multiplier + ema;
            emaData.push({
                time: data[i].time,
                value: ema
            });
        }
        
        return emaData;
    }
    
    /**
     * Calculate Volume Weighted Moving Average (VWMA)
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for VWMA calculation
     * @returns {Array} VWMA data points
     */
    static calculateVWMA(data, period) {
        const vwmaData = [];
        
        for (let i = period - 1; i < data.length; i++) {
            let priceVolumeSum = 0;
            let volumeSum = 0;
            
            for (let j = 0; j < period; j++) {
                const candle = data[i - j];
                priceVolumeSum += candle.close * candle.volume;
                volumeSum += candle.volume;
            }
            
            const vwma = volumeSum > 0 ? priceVolumeSum / volumeSum : 0;
            
            vwmaData.push({
                time: data[i].time,
                value: vwma
            });
        }
        
        return vwmaData;
    }
    
    /**
     * Calculate Bollinger Bands
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for calculation (default: 20)
     * @param {number} multiplier - Standard deviation multiplier (default: 2)
     * @returns {Object} Upper, middle, and lower band data
     */
    static calculateBollingerBands(data, period, multiplier) {
        const result = { upper: [], middle: [], lower: [] };
        
        for (let i = period - 1; i < data.length; i++) {
            let sum = 0;
            for (let j = 0; j < period; j++) {
                sum += data[i - j].close;
            }
            const ma = sum / period;
            
            let variance = 0;
            for (let j = 0; j < period; j++) {
                variance += Math.pow(data[i - j].close - ma, 2);
            }
            const stdDev = Math.sqrt(variance / period);
            
            result.middle.push({ time: data[i].time, value: ma });
            result.upper.push({ time: data[i].time, value: ma + (stdDev * multiplier) });
            result.lower.push({ time: data[i].time, value: ma - (stdDev * multiplier) });
        }
        
        return result;
    }
    
    /**
     * Calculate Weighted Moving Average (WMA)
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for WMA calculation
     * @returns {Array} WMA data points
     */
    static calculateWMA(data, period) {
        const wmaData = [];
        const weight = period * (period + 1) / 2;
        
        for (let i = period - 1; i < data.length; i++) {
            let sum = 0;
            for (let j = 0; j < period; j++) {
                sum += data[i - j].close * (period - j);
            }
            
            wmaData.push({
                time: data[i].time,
                value: sum / weight
            });
        }
        
        return wmaData;
    }
    
    /**
     * Calculate Stochastic Oscillator
     * @param {Array} data - OHLCV data
     * @param {number} kPeriod - %K period
     * @param {number} dPeriod - %D period
     * @returns {Object} %K and %D values
     */
    static calculateStochastic(data, kPeriod = 14, dPeriod = 3) {
        const result = { k: [], d: [] };
        
        for (let i = kPeriod - 1; i < data.length; i++) {
            let highest = data[i - kPeriod + 1].high;
            let lowest = data[i - kPeriod + 1].low;
            
            for (let j = i - kPeriod + 2; j <= i; j++) {
                if (data[j].high > highest) highest = data[j].high;
                if (data[j].low < lowest) lowest = data[j].low;
            }
            
            const k = ((data[i].close - lowest) / (highest - lowest)) * 100;
            result.k.push({
                time: data[i].time,
                value: k
            });
        }
        
        // Calculate %D (SMA of %K)
        for (let i = dPeriod - 1; i < result.k.length; i++) {
            let sum = 0;
            for (let j = 0; j < dPeriod; j++) {
                sum += result.k[i - j].value;
            }
            
            result.d.push({
                time: result.k[i].time,
                value: sum / dPeriod
            });
        }
        
        return result;
    }
    
    /**
     * Calculate Williams %R
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for calculation
     * @returns {Array} Williams %R data points
     */
    static calculateWilliamsR(data, period = 14) {
        const williamsRData = [];
        
        for (let i = period - 1; i < data.length; i++) {
            let highest = data[i - period + 1].high;
            let lowest = data[i - period + 1].low;
            
            for (let j = i - period + 2; j <= i; j++) {
                if (data[j].high > highest) highest = data[j].high;
                if (data[j].low < lowest) lowest = data[j].low;
            }
            
            const williamsR = ((highest - data[i].close) / (highest - lowest)) * -100;
            
            williamsRData.push({
                time: data[i].time,
                value: williamsR
            });
        }
        
        return williamsRData;
    }
    
    /**
     * Calculate Commodity Channel Index (CCI)
     * @param {Array} data - OHLCV data
     * @param {number} period - Period for calculation
     * @returns {Array} CCI data points
     */
    static calculateCCI(data, period = 20) {
        const cciData = [];
        const constant = 0.015;
        
        for (let i = period - 1; i < data.length; i++) {
            let tpSum = 0;
            const typicalPrices = [];
            
            // Calculate typical prices for the period
            for (let j = 0; j < period; j++) {
                const candle = data[i - j];
                const tp = (candle.high + candle.low + candle.close) / 3;
                typicalPrices.push(tp);
                tpSum += tp;
            }
            
            const smaTP = tpSum / period;
            const currentTP = (data[i].high + data[i].low + data[i].close) / 3;
            
            // Calculate mean deviation
            let meanDeviation = 0;
            for (let j = 0; j < period; j++) {
                meanDeviation += Math.abs(typicalPrices[j] - smaTP);
            }
            meanDeviation /= period;
            
            const cci = (currentTP - smaTP) / (constant * meanDeviation);
            
            cciData.push({
                time: data[i].time,
                value: cci
            });
        }
        
        return cciData;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TechnicalIndicators;
} else {
    window.TechnicalIndicators = TechnicalIndicators;
}