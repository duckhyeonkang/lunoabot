/**
 * Main Application Entry Point
 * Orchestrates all modules and manages the overall application lifecycle
 */

class EnhancedTradingChart {
    constructor() {
        console.log('⚡ Enhanced Trading Chart initializing...');
        
        // Core managers
        this.chartManager = null;
        this.websocketManager = null;
        this.chartSyncManager = null;
        this.settingsModal = null;
        this.uiHandlers = null;
        
        // Application state
        this.currentSymbol = 'BTCUSDT';
        this.currentTimeframe = '1h';
        this.isInitialized = false;
        this.isConnected = false;
        
        // Memory management
        this.memoryCleanupInterval = null;
        this.dataRetentionLimit = 1000; // Keep last 1000 candles
        
        // Bind methods to maintain context
        this.handleKlineUpdate = this.handleKlineUpdate.bind(this);
        this.handleTickerUpdate = this.handleTickerUpdate.bind(this);
        this.handleConnectionChange = this.handleConnectionChange.bind(this);
        this.handleWebSocketError = this.handleWebSocketError.bind(this);
        this.handleSymbolChange = this.handleSymbolChange.bind(this);
        this.handleTimeframeChange = this.handleTimeframeChange.bind(this);
        this.handleIndicatorToggle = this.handleIndicatorToggle.bind(this);
        this.handleRealtimeModeChange = this.handleRealtimeModeChange.bind(this);
        this.handleSettingsApply = this.handleSettingsApply.bind(this);
    }
    
    /**
     * Initialize the entire application
     */
    async init() {
        try {
            console.log('🚀 Starting Enhanced Trading Chart initialization...');
            
            // Check dependencies
            if (!this.checkDependencies()) {
                throw new Error('Required dependencies not loaded');
            }
            
            // Initialize core managers
            await this.initializeManagers();
            
            // Setup manager interactions
            this.setupManagerInteractions();
            
            // Load initial data
            await this.loadInitialData();
            
            // Start real-time connections
            this.startRealTimeUpdates();
            
            // Setup cleanup handlers
            this.setupCleanupHandlers();

            // 메모리 관리 시작 (5분마다 정리)
            this.startMemoryManagement();
            
            this.isInitialized = true;
            console.log('✅ Enhanced Trading Chart initialization complete!');

            // 로딩 화면 페이드 아웃 애니메이션
            this.hideLoadingWithAnimation();
            
        } catch (error) {
            console.error('❌ Application initialization failed:', error);
            this.showError('Application initialization failed: ' + error.message);
        }
    }
    
    /**
     * 🆕 Start memory management
     */
    startMemoryManagement() {
        // Clear previous interval if exists
        if (this.memoryCleanupInterval) {
            clearInterval(this.memoryCleanupInterval);
        }
        
        // Run memory cleanup every 5 minutes
        this.memoryCleanupInterval = setInterval(() => {
            this.performMemoryCleanup();
        }, 5 * 60 * 1000);
        
        console.log('🧹 Memory management started (5-minute interval)');
    }
    
    /**
     * 🆕 Perform memory cleanup
     */
    performMemoryCleanup() {
        try {
            console.log('🧹 Performing memory cleanup...');
            
            // Cleanup chart data
            if (this.chartManager && this.chartManager.cachedChartData) {
                const dataLength = this.chartManager.cachedChartData.length;
                if (dataLength > this.dataRetentionLimit) {
                    const excessData = dataLength - this.dataRetentionLimit;
                    this.chartManager.cachedChartData = 
                        this.chartManager.cachedChartData.slice(excessData);
                    console.log(`📊 Removed ${excessData} old candles from cache`);
                }
            }
            
            // Cleanup WebSocket message queue if implemented
            if (this.websocketManager && this.websocketManager.messageQueue) {
                const oldQueueLength = this.websocketManager.messageQueue.length;
                this.websocketManager.messageQueue = 
                    this.websocketManager.messageQueue.slice(-100); // Keep last 100 messages
                const removed = oldQueueLength - this.websocketManager.messageQueue.length;
                if (removed > 0) {
                    console.log(`📨 Removed ${removed} old messages from queue`);
                }
            }
            
            // Force garbage collection if available (Chrome DevTools)
            if (window.gc) {
                window.gc();
                console.log('♻️ Forced garbage collection');
            }
            
            console.log('✅ Memory cleanup completed');
            
        } catch (error) {
            console.error('❌ Memory cleanup error:', error);
        }
    }
    
    /**
     * 🆕 Hide loading screen with fade animation
     */
    hideLoadingWithAnimation() {
        const loading = document.getElementById('loading');
        if (loading) {
            // Add fade out animation
            loading.style.transition = 'opacity 0.5s ease-out';
            loading.style.opacity = '0';
            
            // Remove from DOM after animation
            setTimeout(() => {
                loading.style.display = 'none';
                console.log('✅ Loading screen hidden with animation');
            }, 500);
        }
    }
    
    /**
     * Check if all required dependencies are loaded
     */
    checkDependencies() {
        const requiredGlobals = [
            'LightweightCharts',
            'TechnicalIndicators',
            'ChartSyncManager',
            'WebSocketManager',
            'ChartManager',
            'SettingsModalManager',
            'UIHandlers'
        ];
        
        for (const global of requiredGlobals) {
            if (typeof window[global] === 'undefined') {
                console.error(`❌ Required dependency not found: ${global}`);
                return false;
            }
        }
        
        console.log('✅ All dependencies loaded successfully');
        return true;
    }
    
    /**
     * Initialize all manager instances
     */
    async initializeManagers() {
        console.log('📦 Initializing managers...');
        
        // Initialize Chart Manager
        this.chartManager = new ChartManager();
        window.chartManager = this.chartManager; // 전역 변수로 등록
        
        const chartInitSuccess = await this.chartManager.initialize();
        if (!chartInitSuccess) {
            throw new Error('Chart Manager initialization failed');
        }
        
        // Initialize WebSocket Manager
        this.websocketManager = new WebSocketManager();
        this.websocketManager.setEventHandlers({
            onKlineUpdate: this.handleKlineUpdate,
            onTickerUpdate: this.handleTickerUpdate,
            onConnectionChange: this.handleConnectionChange,
            onError: this.handleWebSocketError
        });
        
        // Initialize Chart Sync Manager
        this.chartSyncManager = new ChartSyncManager();
        const chartConfigs = this.chartManager.getChartConfigs();
        this.chartSyncManager.initialize(chartConfigs);

        // Crosshair 동기화를 위한 시리즈 등록
        setTimeout(() => {
            if (this.chartManager.candleSeries) {
                this.chartSyncManager.registerSeries('main', this.chartManager.candleSeries);
            }
            if (this.chartManager.volumeSeries) {
                this.chartSyncManager.registerSeries('volume', this.chartManager.volumeSeries);
            }
            if (this.chartManager.rsiSeries) {
                this.chartSyncManager.registerSeries('rsi', this.chartManager.rsiSeries);
            }
            if (this.chartManager.macdSeries) {
                this.chartSyncManager.registerSeries('macd', this.chartManager.macdSeries);
            }
            console.log('✅ Crosshair sync series registered');
        }, 500);
        
        // Initialize Settings Modal
        this.settingsModal = new SettingsModalManager();
        this.settingsModal.initialize({
            onSettingsApply: this.handleSettingsApply,
            onPresetLoad: this.handlePresetLoad.bind(this),
            onPresetSave: this.handlePresetSave.bind(this)
        });
        
        // Initialize UI Handlers
        this.uiHandlers = new UIHandlers();
        this.uiHandlers.initialize({
            chartManager: this.chartManager,
            websocketManager: this.websocketManager,
            settingsModal: this.settingsModal,
            dataLoader: this
        }, {
            onSymbolChange: this.handleSymbolChange,
            onTimeframeChange: this.handleTimeframeChange,
            onIndicatorToggle: this.handleIndicatorToggle,
            onRealtimeModeChange: this.handleRealtimeModeChange
        });
        
        console.log('✅ All managers initialized successfully');
        console.log('📊 Manager status:', {
            chartManager: !!this.chartManager,
            websocketManager: !!this.websocketManager,
            chartSyncManager: !!this.chartSyncManager,
            settingsModal: !!this.settingsModal,
            uiHandlers: !!this.uiHandlers,
            windowChartManager: !!window.chartManager
        });
    }
    
    /**
     * Setup interactions between managers
     */
    setupManagerInteractions() {
        console.log('🔗 Setting up manager interactions...');
        
        // Window resize handler
        window.addEventListener('resize', () => {
            if (this.chartSyncManager) {
                this.chartSyncManager.handleResize();
            }
        });
        
        console.log('✅ Manager interactions configured');
    }
    
    /**
     * Load initial market data
     */
    async loadInitialData() {
        try {
            console.log(`📊 Loading initial data for ${this.currentSymbol} ${this.currentTimeframe}...`);
            
            const intervalMap = {
                '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m',
                '1h': '1h', '4h': '4h', '1d': '1d'
            };
            
            const interval = intervalMap[this.currentTimeframe] || '1h';
            
            const response = await fetch(
                `https://api.binance.com/api/v3/klines?symbol=${this.currentSymbol}&interval=${interval}&limit=500`
            );
            
            if (!response.ok) {
                throw new Error(`API Error: ${response.status} ${response.statusText}`);
            }
            
            const rawData = await response.json();
            
            const chartData = rawData.map(item => {
                const [timestamp, open, high, low, close, volume] = item;
                
                return {
                    time: Math.floor(timestamp / 1000),
                    open: parseFloat(open),
                    high: parseFloat(high),
                    low: parseFloat(low),
                    close: parseFloat(close),
                    volume: parseFloat(volume)
                };
            });
            
            // Set chart data
            this.chartManager.setChartData(chartData);
            
            // Update price display with latest candle
            if (chartData.length > 0 && this.uiHandlers) {
                const lastCandle = chartData[chartData.length - 1];
                this.uiHandlers.updatePriceDisplay(lastCandle);
            }
            
            // Force chart synchronization
            setTimeout(() => {
                if (this.chartSyncManager) {
                    this.chartSyncManager.forceSyncAllCharts();
                }
            }, 300);
            
            console.log(`✅ Initial data loaded: ${chartData.length} candles`);
            
        } catch (error) {
            console.error('❌ Failed to load initial data:', error);
            this.showError('Failed to load market data: ' + error.message);
        }
    }
    
    /**
     * Start real-time data updates
     */
    startRealTimeUpdates() {
        console.log('📡 Starting real-time updates...');
        
        if (this.websocketManager) {
            this.websocketManager.connect(this.currentSymbol, this.currentTimeframe);
        }
    }
    
    /**
     * Handle real-time kline updates
     */
    handleKlineUpdate(candleData) {
        try {
            // Update chart data
            if (this.chartManager) {
                this.chartManager.updateCandle(candleData);
            }
            
            // Update price display
            if (this.uiHandlers) {
                this.uiHandlers.updatePriceDisplay(candleData);
                this.uiHandlers.updateStats();
            }
            
            // Occasional chart sync (every 10 updates)
            if (this.uiHandlers && this.uiHandlers.updateCount % 10 === 0) {
                setTimeout(() => {
                    if (this.chartSyncManager) {
                        this.chartSyncManager.forceSyncAllCharts();
                    }
                }, 100);
            }
            
        } catch (error) {
            console.error('❌ Kline update error:', error);
        }
    }
    
    /**
     * Handle ticker price updates
     */
    handleTickerUpdate(tickerData) {
        try {
            if (this.uiHandlers) {
                this.uiHandlers.updateTickerPrice(tickerData);
            }
        } catch (error) {
            console.error('❌ Ticker update error:', error);
        }
    }
    
    /**
     * Handle connection status changes
     */
    handleConnectionChange(connected) {
        this.isConnected = connected;
        
        if (this.uiHandlers) {
            this.uiHandlers.updateConnectionStatus(connected);
        }
        
        console.log(`📡 Connection status: ${connected ? 'Connected' : 'Disconnected'}`);
    }
    
    /**
     * Handle WebSocket errors
     */
    handleWebSocketError(type, error) {
        console.error(`❌ WebSocket error (${type}):`, error);
        
        // Could show user notification here
        if (type === 'kline' && !this.isConnected) {
            this.showError('Real-time data connection lost. Attempting to reconnect...');
        }
    }
    
    /**
     * Handle symbol changes
     */
    async handleSymbolChange(newSymbol) {
        try {
            console.log(`💱 Changing symbol to: ${newSymbol}`);
            
            this.currentSymbol = newSymbol;
            
            // Update chart watermark
            if (this.chartManager) {
                this.chartManager.updateWatermarks(newSymbol);
            }
            
            // Disconnect and reconnect WebSocket
            if (this.websocketManager) {
                this.websocketManager.changeSymbol(newSymbol);
            }
            
            // Reload data
            await this.loadInitialData();
            
            // Update UI
            if (this.uiHandlers) {
                this.uiHandlers.updateChartTitle();
            }
            
            console.log(`✅ Symbol changed to: ${newSymbol}`);
            
        } catch (error) {
            console.error('❌ Symbol change error:', error);
            this.showError('Failed to change symbol: ' + error.message);
        }
    }
    
    /**
     * Handle timeframe changes
     */
    async handleTimeframeChange(newTimeframe) {
        try {
            console.log(`⏱️ Changing timeframe to: ${newTimeframe}`);
            
            this.currentTimeframe = newTimeframe;
            
            // Disconnect and reconnect WebSocket
            if (this.websocketManager) {
                this.websocketManager.changeTimeframe(newTimeframe);
            }
            
            // Reload data
            await this.loadInitialData();
            
            // Update UI
            if (this.uiHandlers) {
                this.uiHandlers.updateChartTitle();
            }
            
            console.log(`✅ Timeframe changed to: ${newTimeframe}`);
            
        } catch (error) {
            console.error('❌ Timeframe change error:', error);
            this.showError('Failed to change timeframe: ' + error.message);
        }
    }
    
    /**
     * Handle indicator toggle
     */
    handleIndicatorToggle(indicator, enabled) {
        try {
            console.log(`📊 Toggling indicator ${indicator}: ${enabled ? 'ON' : 'OFF'}`);
            
            if (this.chartManager) {
                switch(indicator) {
                    case 'bb':
                        // 볼린저밴드는 chartManager의 toggle 함수 사용
                        // UI에서 이미 처리됨
                        break;
                    case 'ma':
                        // 이동평균선도 chartManager의 toggle 함수 사용
                        // UI에서 이미 처리됨
                        break;
                    case 'vwma':
                    case 'ema':
                        if (enabled) {
                            this.addIndicator(indicator);
                        } else {
                            this.removeIndicator(indicator);
                        }
                        break;
                }
            }
            
        } catch (error) {
            console.error('❌ Indicator toggle error:', error);
        }
    }
    
    /**
     * Handle real-time mode changes
     */
    handleRealtimeModeChange(mode, throttle) {
        console.log(`⚡ Real-time mode changed: ${mode} (${throttle}ms)`);
        
        if (this.websocketManager) {
            this.websocketManager.setUpdateThrottle(throttle);
        }
    }
    
    /**
     * Handle settings apply - 수정된 버전
     */
    handleSettingsApply(chartType, settings, isPreview = false) {
        try {
            console.log(`⚙️ Applying settings for ${chartType}:`, settings);
            
            if (this.chartManager) {
                // Update indicator settings
                this.chartManager.indicatorSettings[chartType] = {
                    ...this.chartManager.indicatorSettings[chartType],
                    ...settings
                };
                
                // Recalculate indicators
                this.chartManager.updateAllIndicators();
                
                // Update chart titles
                this.updateChartTitles();
                
                // 설정이 적용되었음을 알림
                console.log(`✅ Settings applied for ${chartType}`, this.chartManager.indicatorSettings[chartType]);
            }
            
            if (!isPreview) {
                console.log(`✅ Settings saved for ${chartType}`);
            }
            
        } catch (error) {
            console.error('❌ Settings apply error:', error);
        }
    }
    
    /**
     * Handle preset load
     */
    handlePresetLoad(presetName, preset) {
        console.log(`📋 Loading preset: ${presetName}`);
        
        if (this.chartManager) {
            // Apply preset settings to chart manager
            Object.keys(preset).forEach(key => {
                if (key !== 'name' && this.chartManager.indicatorSettings[key]) {
                    this.chartManager.indicatorSettings[key] = {
                        ...this.chartManager.indicatorSettings[key],
                        ...preset[key]
                    };
                }
            });
            
            // Recalculate indicators
            this.chartManager.updateAllIndicators();
            this.updateChartTitles();
        }
    }
    
    /**
     * Handle preset save
     */
    handlePresetSave(presetName, settings) {
        console.log(`💾 Saving preset: ${presetName}`, settings);
        // Preset saving is handled by the settings modal manager
    }
    
    /**
     * Add indicator to chart
     */
    addIndicator(indicator) {
        if (!this.chartManager) return;
        
        const settings = this.chartManager.indicatorSettings[indicator];
        
        switch(indicator) {
            case 'vwma':
                this.chartManager.indicators.vwma = this.chartManager.mainChart.addSeries(LightweightCharts.LineSeries, {
                    color: settings.color,
                    lineWidth: settings.lineWidth,
                });
                this.chartManager.indicatorVisible.vwma = true;
                break;
                
            case 'ema':
                this.chartManager.indicators.ema = this.chartManager.mainChart.addSeries(LightweightCharts.LineSeries, {
                    color: settings.color,
                    lineWidth: settings.lineWidth,
                });
                this.chartManager.indicatorVisible.ema = true;
                break;
        }
        
        // Calculate and display indicator data
        this.calculateAndDisplayIndicator(indicator);
    }
    
    /**
     * Remove indicator from chart
     */
    removeIndicator(indicator) {
        if (!this.chartManager) return;
        
        if (this.chartManager.indicators[indicator]) {
            this.chartManager.indicators[indicator].setData([]);
            this.chartManager.indicatorVisible[indicator] = false;
        }
    }
    
    /**
     * Calculate and display specific indicator
     */
    calculateAndDisplayIndicator(indicator) {
        if (!this.chartManager || !this.chartManager.cachedChartData.length) return;
        
        const data = this.chartManager.cachedChartData;
        const settings = this.chartManager.indicatorSettings[indicator];
        
        switch(indicator) {
            case 'vwma':
                if (this.chartManager.indicators.vwma) {
                    const vwmaData = TechnicalIndicators.calculateVWMA(data, settings.period);
                    this.chartManager.indicators.vwma.setData(vwmaData);
                }
                break;
                
            case 'ema':
                if (this.chartManager.indicators.ema) {
                    const emaData = TechnicalIndicators.calculateEMA(data, settings.period);
                    this.chartManager.indicators.ema.setData(emaData);
                }
                break;
        }
    }
    
    /**
     * Update chart titles with current settings
     */
    updateChartTitles() {
        const titles = {
            main: `📊 ${this.currentSymbol} - ${this.currentTimeframe.toUpperCase()}`,
            rsi: `📈 RSI (${this.chartManager.indicatorSettings.rsi.period})`,
            macd: `📉 MACD (${this.chartManager.indicatorSettings.macd.fastPeriod},${this.chartManager.indicatorSettings.macd.slowPeriod},${this.chartManager.indicatorSettings.macd.signalPeriod})`
        };
        
        Object.keys(titles).forEach(key => {
            const element = document.querySelector(`.${key}-chart .chart-title`);
            if (element) {
                element.textContent = titles[key];
            }
        });
    }
    
    /**
     * Show error message to user
     */
    showError(message) {
        console.error('🚨 Error:', message);
        
        // Update loading element to show error
        const loadingElement = document.getElementById('loading');
        if (loadingElement) {
            loadingElement.innerHTML = `<p style="color: #ef5350;">❌ ${message}</p>`;
        }
        
        // Could also show a toast notification here
    }
    
    /**
     * Setup cleanup handlers for page unload
     */
    setupCleanupHandlers() {
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });
        
        // Handle page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                // Page is hidden, might want to pause updates
                console.log('📱 Page hidden, maintaining connections');
            } else {
                // Page is visible again, ensure everything is synced
                console.log('📱 Page visible, resyncing charts');
                setTimeout(() => {
                    if (this.chartSyncManager) {
                        this.chartSyncManager.forceSyncAllCharts();
                    }
                }, 100);
            }
        });
    }
    
    /**
     * Clean up all resources
     */
    cleanup() {
        console.log('🧹 Cleaning up Enhanced Trading Chart...');
        
        // Stop memory management
        if (this.memoryCleanupInterval) {
            clearInterval(this.memoryCleanupInterval);
            this.memoryCleanupInterval = null;
        }
        
        // Disconnect WebSocket
        if (this.websocketManager) {
            this.websocketManager.disconnect();
        }
        
        // Cleanup managers
        if (this.chartSyncManager) {
            this.chartSyncManager.cleanup();
        }
        
        if (this.chartManager) {
            this.chartManager.cleanup();
        }
        
        if (this.settingsModal) {
            this.settingsModal.cleanup();
        }
        
        if (this.uiHandlers) {
            this.uiHandlers.cleanup();
        }
        
        this.isInitialized = false;
        console.log('✅ Cleanup complete');
    }
    
    /**
     * Get application status
     */
    getStatus() {
        return {
            isInitialized: this.isInitialized,
            isConnected: this.isConnected,
            currentSymbol: this.currentSymbol,
            currentTimeframe: this.currentTimeframe,
            dataRetentionLimit: this.dataRetentionLimit,
            cachedDataSize: this.chartManager?.cachedChartData?.length || 0,
            managers: {
                chartManager: !!this.chartManager,
                websocketManager: !!this.websocketManager,
                chartSyncManager: !!this.chartSyncManager,
                settingsModal: !!this.settingsModal,
                uiHandlers: !!this.uiHandlers
            }
        };
    }
    
    /**
     * Export current configuration
     */
    exportConfig() {
        return {
            symbol: this.currentSymbol,
            timeframe: this.currentTimeframe,
            indicatorSettings: this.chartManager?.indicatorSettings || {},
            presets: this.settingsModal?.getPresets() || {}
        };
    }
    
    /**
     * Import configuration
     */
    async importConfig(config) {
        try {
            if (config.symbol && config.symbol !== this.currentSymbol) {
                await this.handleSymbolChange(config.symbol);
            }
            
            if (config.timeframe && config.timeframe !== this.currentTimeframe) {
                await this.handleTimeframeChange(config.timeframe);
            }
            
            if (config.indicatorSettings && this.chartManager) {
                this.chartManager.indicatorSettings = {
                    ...this.chartManager.indicatorSettings,
                    ...config.indicatorSettings
                };
                this.chartManager.updateAllIndicators();
            }
            
            if (config.presets && this.settingsModal) {
                this.settingsModal.setPresets(config.presets);
            }
            
            console.log('✅ Configuration imported successfully');
            return true;
            
        } catch (error) {
            console.error('❌ Configuration import failed:', error);
            return false;
        }
    }
}

// Initialize application when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 DOM loaded, initializing Enhanced Trading Chart...');
    
    // Small delay to ensure all scripts are loaded
    setTimeout(() => {
        const enhancedChart = new EnhancedTradingChart();
        
        // Make it globally accessible for debugging
        window.enhancedChart = enhancedChart;
        
        // Initialize the application
        enhancedChart.init().catch(error => {
            console.error('❌ Failed to initialize application:', error);
        });
    }, 100);
});

// Handle any global errors
window.addEventListener('error', (event) => {
    // ResizeObserver 에러는 무시 (차트 라이브러리에서 발생하는 무해한 에러)
    if (event.message && event.message.includes('ResizeObserver')) {
        event.preventDefault();
        return;
    }
    console.error('🚨 Global error:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('🚨 Unhandled promise rejection:', event.reason);
});